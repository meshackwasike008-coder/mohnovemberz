<?php
/**
 * PP-SDOMS: Project Performance, Service Delivery & Operational Management System
 * Ministry of Health — State Department for Medical Services
 * 
 * Entry bootstrap file: sets up error handling, base URLs, security headers, and loads helpers.
 */
declare(strict_types=1);

// Error reporting & diagnostics
$isDebug = isset($_GET['debug']) || (getenv('APP_DEBUG') !== false && getenv('APP_DEBUG') === 'true');
ini_set('display_errors', $isDebug ? '1' : '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// Graceful Uncaught Exception Handler
set_exception_handler(function (Throwable $e) use ($isDebug): void {
    error_log(sprintf("PP-SDOMS Fatal [%s]: %s in %s on line %d", get_class($e), $e->getMessage(), $e->getFile(), $e->getLine()));
    
    // Clean any partial output buffer so error screen is pristine
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    
    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        || (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json'));

    if ($isAjax) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'success' => false,
            'error' => $isDebug 
                ? ($e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')')
                : 'Server error: ' . $e->getMessage()
        ]);
        exit;
    }

    if (!headers_sent()) {
        http_response_code(500);
    }
    
    if ($isDebug) {
        echo "<div style='font-family:sans-serif;background:#fff5f5;border:2px solid #e53e3e;padding:24px;margin:20px;border-radius:8px;'>";
        echo "<h2 style='color:#c53030;margin-top:0;'>PP-SDOMS Diagnostic Error (" . htmlspecialchars(get_class($e)) . ")</h2>";
        echo "<p style='font-size:1.1rem;font-weight:bold;color:#2d3748;'>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p style='color:#718096;'>File: <code>" . htmlspecialchars($e->getFile()) . "</code> on line <strong>" . $e->getLine() . "</strong></p>";
        echo "<details style='margin-top:16px;'><summary style='cursor:pointer;font-weight:bold;'>Stack Trace</summary>";
        echo "<pre style='background:#edf2f7;padding:12px;border-radius:6px;overflow-x:auto;font-size:0.85rem;'>" . htmlspecialchars($e->getTraceAsString()) . "</pre></details>";
        echo "</div>";
        exit;
    }

    echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>System Error | SDMS</title>";
    echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'></head>";
    echo "<body class='bg-light d-flex align-items-center justify-content-center' style='min-height:100vh;'>";
    echo "<div class='card shadow-sm p-4 text-center' style='max-width:500px;'>";
    echo "<div class='text-danger mb-3'><svg width='48' height='48' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><circle cx='12' cy='12' r='10'></circle><line x1='12' y1='8' x2='12' y2='12'></line><line x1='12' y1='16' x2='12.01' y2='16'></line></svg></div>";
    echo "<h4 class='fw-bold text-dark'>Service Temporarily Unavailable</h4>";
    echo "<p class='text-muted small'>An internal system error occurred. Details have been logged to the server error log.</p>";
    echo "<p class='small text-muted'>To view diagnostics on cPanel, append <code>?debug=1</code> to your URL.</p>";
    echo "<div class='mt-3'><a href='../dashboard.php' class='btn btn-primary btn-sm px-4'>Return to Dashboard</a></div>";
    echo "</div></body></html>";
    exit;
});

// Base application paths
define('APP_ROOT', __DIR__);
define('CONFIG_DIR', APP_ROOT . '/config');
define('INCLUDES_DIR', APP_ROOT . '/includes');
define('UPLOADS_DIR', APP_ROOT . '/uploads');
define('BACKUPS_DIR', APP_ROOT . '/backups');

// Ensure storage directories exist with write access
foreach ([UPLOADS_DIR, UPLOADS_DIR . '/reports', BACKUPS_DIR] as $dirPath) {
    if (!is_dir($dirPath)) {
        @mkdir($dirPath, 0775, true);
    }
}

// Calculate relative BASE_URL dynamically for cPanel subdirectories, root domains, LiteSpeed, Apache, Nginx
$rawScript = $_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '';
$scriptPath = '/' . ltrim(str_replace('\\', '/', $rawScript), '/');
$dir = dirname($scriptPath);
$base = rtrim($dir, '/');
// Strip off standard application subdirectories to reach the application root
$base = preg_replace('#/(modules|admin|includes|config)(/.*)?$#i', '', $base);
$base = rtrim($base, '/') . '/';
if ($base === '//') {
    $base = '/';
}
define('BASE_URL', $base);

// Security Headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Load core database and function libraries
require_once CONFIG_DIR . '/database.php';
require_once INCLUDES_DIR . '/functions.php';
require_once INCLUDES_DIR . '/layout.php';
require_once INCLUDES_DIR . '/module_helpers.php';
