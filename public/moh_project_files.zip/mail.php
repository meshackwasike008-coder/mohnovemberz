<?php
/**
 * Root Bridge: Mail Register
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/mail.php';
