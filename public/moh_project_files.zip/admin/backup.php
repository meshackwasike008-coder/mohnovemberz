<?php
/**
 * Module 12: cPanel & Backup Management
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();
require_permission('is_admin');

$db = db();
$user = current_user();

// Handle direct download actions
if (isset($_GET['download']) && $_GET['download'] === 'schema') {
    $file = ROOT_PATH . '/database/schema.sql';
    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="moh_database_schema_and_demo.sql"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
}

if (isset($_GET['download']) && in_array($_GET['download'], ['zip', 'project_archive'], true)) {
    $file = ROOT_PATH . '/moh_project_files.zip';
    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="moh_project_files.zip"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
}

if (isset($_GET['download']) && $_GET['download'] === 'live_dump') {
    // Generate live SQL dump from DB tables
    $tables = [
        'roles', 'users', 'directorates', 'sagas', 'flagships',
        'projects', 'project_financiers', 'kpis', 'performance_contracts',
        'action_points', 'events', 'meetings', 'reports', 'diary',
        'mail', 'visitors', 'system_records', 'audit_logs'
    ];

    $dump = "-- MOH PP-SDOMS Automated Database Backup\n";
    $dump .= "-- Generated on: " . date('Y-m-d H:i:s') . "\n";
    $dump .= "-- Server: " . ($_SERVER['SERVER_NAME'] ?? 'localhost') . "\n\n";
    $dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

    foreach ($tables as $t) {
        try {
            $rows = $db->query("SELECT * FROM `{$t}`")->fetchAll(PDO::FETCH_ASSOC);
            $dump .= "-- Data for table `{$t}` (" . count($rows) . " rows)\n";
            if (!empty($rows)) {
                $cols = array_keys($rows[0]);
                $colList = implode('`, `', $cols);
                foreach ($rows as $r) {
                    $vals = array_map(function($v) use ($db) {
                        return $v === null ? 'NULL' : $db->quote((string)$v);
                    }, array_values($r));
                    $valList = implode(', ', $vals);
                    $dump .= "INSERT INTO `{$t}` (`{$colList}`) VALUES ({$valList});\n";
                }
            }
            $dump .= "\n";
        } catch (Throwable $e) {
            // table may not exist yet
        }
    }
    $dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

    log_activity('backup_database', $user['id'], 'Generated and downloaded live MySQL dump', null, 'admin');

    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="moh_live_backup_' . date('Ymd_His') . '.sql"');
    echo $dump;
    exit;
}

// System checks
$checks = [
    'PHP Version' => [phpversion(), version_compare(phpversion(), '8.1.0', '>=')],
    'PDO MySQL Extension' => [extension_loaded('pdo_mysql') ? 'Installed' : 'Missing', extension_loaded('pdo_mysql')],
    'cURL Extension' => [extension_loaded('curl') ? 'Installed' : 'Missing', extension_loaded('curl')],
    'JSON Extension' => [extension_loaded('json') ? 'Installed' : 'Missing', extension_loaded('json')],
    'Uploads Directory Writable' => [is_writable(UPLOADS_DIR) ? 'Writable' : 'Not Writable', is_writable(UPLOADS_DIR)],
    'Backups Directory Writable' => [is_writable(ROOT_PATH . '/backups') ? 'Writable' : 'Not Writable', is_writable(ROOT_PATH . '/backups')],
    'Max Upload Size' => [ini_get('upload_max_filesize'), true],
    'Memory Limit' => [ini_get('memory_limit'), true],
];

$renderContent = function() use ($checks) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-server text-primary"></i> cPanel &amp; System Backup Manager
            </h4>
            <span class="small text-muted">Complete Database &amp; System Snapshot Tools for cPanel Hosting</span>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>admin/backup.php?download=schema" class="btn btn-outline-primary btn-sm fw-bold">
                <i class="fa-solid fa-file-code me-1"></i> Download Schema &amp; Demo SQL
            </a>
            <a href="<?= BASE_URL ?>admin/backup.php?download=live_dump" class="btn btn-success btn-sm fw-bold">
                <i class="fa-solid fa-download me-1"></i> Download Live Database Backup
            </a>
        </div>
    </div>

    <!-- System Diagnostic Cards -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm bg-white h-100">
                <div class="card-header bg-primary text-white py-2 px-3 fw-bold small">
                    <i class="fa-solid fa-heart-pulse me-2"></i> Server Environment Diagnostics
                </div>
                <div class="card-body p-0">
                    <table class="table table-sm table-striped mb-0 align-middle" style="font-size: 0.82rem;">
                        <tbody>
                            <?php foreach ($checks as $item => $data): ?>
                                <tr>
                                    <td class="fw-semibold ps-3"><?= e($item) ?></td>
                                    <td><?= e((string)$data[0]) ?></td>
                                    <td class="text-end pe-3">
                                        <?php if ($data[1]): ?>
                                            <span class="badge bg-success"><i class="fa-solid fa-check"></i> Passed</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><i class="fa-solid fa-triangle-exclamation"></i> Warning</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm bg-white h-100">
                <div class="card-header bg-dark text-white py-2 px-3 fw-bold small">
                    <i class="fa-solid fa-terminal me-2"></i> cPanel Quick Setup Overview
                </div>
                <div class="card-body p-3 font-monospace small">
                    <ol class="mb-0 ps-3">
                        <li class="mb-2"><strong>Database Creation:</strong> Create MySQL DB in cPanel (e.g. <code>username_mohsdms</code>) and user with ALL PRIVILEGES.</li>
                        <li class="mb-2"><strong>Import SQL:</strong> Open phpMyAdmin &rarr; Select Database &rarr; Click <strong>Import</strong> &rarr; Choose <code>database/schema.sql</code>.</li>
                        <li class="mb-2"><strong>File Upload:</strong> Upload project files to <code>public_html/</code> (or subdomain folder).</li>
                        <li class="mb-2"><strong>Environment:</strong> Copy <code>.env.example</code> to <code>.env</code> and fill DB credentials.</li>
                        <li class="mb-0"><strong>Default Admin:</strong> Log in with <code>admin@health.go.ke</code> / <code>ChangeMe@2026</code>.</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Documentation Quick Links -->
    <div class="card border-0 shadow-sm bg-white p-4">
        <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-book me-2 text-primary"></i> Included Documentation Guides</h5>
        <div class="row g-3">
            <div class="col-md-6">
                <div class="p-3 border rounded bg-light">
                    <h6 class="fw-bold text-primary mb-1"><i class="fa-solid fa-file-lines me-1"></i> cPanel Install Guide</h6>
                    <p class="small text-muted mb-2">Step-by-step instructions for cPanel file manager, MySQL wizard, phpMyAdmin import, PHP 8.x configuration, and SSL certificates.</p>
                    <a href="<?= BASE_URL ?>docs/CPANEL_INSTALL_GUIDE.md" target="_blank" class="btn btn-sm btn-outline-primary">View cPanel Guide</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="p-3 border rounded bg-light">
                    <h6 class="fw-bold text-primary mb-1"><i class="fa-solid fa-sitemap me-1"></i> System Architecture &amp; User Manual</h6>
                    <p class="small text-muted mb-2">Complete functional manual covering all 12 modules, RBAC permissions, audit trail mechanisms, security specs, and schema entity relations.</p>
                    <a href="<?= BASE_URL ?>docs/SYSTEM_DOCUMENTATION.md" target="_blank" class="btn btn-sm btn-outline-primary">View System Manual</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('cPanel & Backup Management', $renderContent, ['active' => 'backup']);
