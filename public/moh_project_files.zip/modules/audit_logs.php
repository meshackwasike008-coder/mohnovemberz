<?php
/**
 * Module: System Audit Logs
 * Restricted to System Administrator (is_admin = 1)
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();
require_permission('is_admin');

$db = db();
$user = current_user();

// Handle export if requested
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $stmt = $db->query("SELECT a.id, a.action, a.module as module_name, a.entity_id as record_id, a.description as details, a.ip_address, a.created_at, COALESCE(u.full_name, a.username, 'System') as user_name, COALESCE(u.email, 'system@health.go.ke') as email FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.id DESC");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="moh_audit_logs_' . date('Ymd_His') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Log ID', 'Timestamp', 'User Name', 'User Email', 'Action', 'Module', 'Record ID', 'Details', 'IP Address']);
    foreach ($logs as $row) {
        fputcsv($output, [
            $row['id'],
            $row['created_at'],
            $row['user_name'] ?? 'System',
            $row['email'] ?? 'system@health.go.ke',
            $row['action'],
            $row['module_name'],
            $row['record_id'],
            $row['details'],
            $row['ip_address']
        ]);
    }
    fclose($output);
    exit;
}

// Filters
$actionFilter = trim($_GET['action_type'] ?? '');
$moduleFilter = trim($_GET['module'] ?? '');
$userFilter = trim($_GET['user'] ?? '');
$search = trim($_GET['search'] ?? '');

$sql = "SELECT a.id, a.action, a.module as module_name, a.entity_id as record_id, a.description as details, a.ip_address, a.created_at, COALESCE(u.full_name, a.username, 'System') as user_name, COALESCE(u.email, 'system@health.go.ke') as email, u.directorate 
        FROM audit_logs a 
        LEFT JOIN users u ON a.user_id = u.id 
        WHERE 1=1";
$params = [];

if ($actionFilter !== '') {
    $sql .= " AND a.action = ?";
    $params[] = $actionFilter;
}

if ($moduleFilter !== '') {
    $sql .= " AND a.module = ?";
    $params[] = $moduleFilter;
}

if ($userFilter !== '') {
    $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR a.username LIKE ?)";
    $params[] = "%{$userFilter}%";
    $params[] = "%{$userFilter}%";
    $params[] = "%{$userFilter}%";
}

if ($search !== '') {
    $sql .= " AND (a.description LIKE ? OR a.ip_address LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY a.id DESC LIMIT 250";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

// Unique actions and modules for filters
$modules = $db->query("SELECT DISTINCT module FROM audit_logs WHERE module IS NOT NULL AND module != '' ORDER BY module ASC")->fetchAll(PDO::FETCH_COLUMN);
$actions = $db->query("SELECT DISTINCT action FROM audit_logs WHERE action IS NOT NULL AND action != '' ORDER BY action ASC")->fetchAll(PDO::FETCH_COLUMN);

$renderContent = function() use ($logs, $modules, $actions, $actionFilter, $moduleFilter, $userFilter, $search) {
?>
<div class="container-fluid px-0">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div>
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-shield-halved text-danger"></i> System Audit Logs
            </h4>
            <span class="small text-muted">Immutable forensic audit trail of all administrative and user operations</span>
        </div>
        <a href="<?= BASE_URL ?>modules/audit_logs.php?export=csv" class="btn btn-outline-success btn-sm fw-bold">
            <i class="fa-solid fa-file-csv me-1"></i> Export Logs to CSV
        </a>
    </div>

    <!-- Filter Form -->
    <div class="card border-0 shadow-sm bg-white p-3 mb-3">
        <form method="GET" action="<?= BASE_URL ?>modules/audit_logs.php" class="row g-2 align-items-center">
            <div class="col-12 col-md-4">
                <input type="text" name="search" value="<?= e($search) ?>" class="form-control form-control-sm" placeholder="Search activity description or IP...">
            </div>
            <div class="col-6 col-md-3">
                <select name="action_type" class="form-select form-select-sm">
                    <option value="">-- All Action Types --</option>
                    <?php foreach ($actions as $act): ?>
                        <option value="<?= e($act) ?>" <?= ($actionFilter === $act) ? 'selected' : '' ?>><?= ucfirst(e($act)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-6 col-md-3">
                <select name="module" class="form-select form-select-sm">
                    <option value="">-- All Modules --</option>
                    <?php foreach ($modules as $m): ?>
                        <option value="<?= e($m) ?>" <?= ($moduleFilter === $m) ? 'selected' : '' ?>><?= ucfirst(e($m)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">
                    <i class="fa-solid fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>

    <!-- Audit Logs Table -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-dark text-white py-2 px-3 fw-bold small d-flex justify-content-between align-items-center">
            <span><i class="fa-solid fa-fingerprint me-2"></i> Security Event Records (<?= count($logs) ?> shown)</span>
            <span class="badge bg-danger">Admin Only</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 140px;">Timestamp</th>
                            <th style="width: 180px;">User</th>
                            <th style="width: 110px;">Action</th>
                            <th style="width: 120px;">Module</th>
                            <th>Activity Details</th>
                            <th style="width: 130px;">IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted">No audit logs matching search filters.</td></tr>
                        <?php else: ?>
                            <?php foreach ($logs as $l): ?>
                                <tr>
                                    <td class="font-monospace text-muted small whitespace-nowrap">
                                        <?= date('d M Y H:i:s', strtotime($l['created_at'])) ?>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= e($l['user_name'] ?? 'System Process') ?></div>
                                        <div class="text-muted font-monospace small"><?= e($l['email'] ?? 'system@health.go.ke') ?></div>
                                    </td>
                                    <td>
                                        <?php 
                                            $act = strtolower($l['action']);
                                            $badgeClass = 'bg-secondary';
                                            if (str_contains($act, 'create') || str_contains($act, 'insert')) $badgeClass = 'bg-success';
                                            elseif (str_contains($act, 'update') || str_contains($act, 'edit')) $badgeClass = 'bg-primary';
                                            elseif (str_contains($act, 'delete')) $badgeClass = 'bg-danger';
                                            elseif (str_contains($act, 'login') || str_contains($act, 'auth')) $badgeClass = 'bg-info text-dark';
                                            elseif (str_contains($act, 'approve')) $badgeClass = 'bg-warning text-dark';
                                            elseif (str_contains($act, 'backup')) $badgeClass = 'bg-dark';
                                        ?>
                                        <span class="badge <?= $badgeClass ?> font-monospace text-uppercase"><?= e($l['action']) ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= e($l['module_name'] ?: 'System') ?></span>
                                    </td>
                                    <td>
                                        <div class="text-dark"><?= e($l['details']) ?></div>
                                        <?php if (!empty($l['record_id'])): ?>
                                            <span class="badge bg-light text-secondary border font-monospace mt-1">Record ID: #<?= e((string)$l['record_id']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="font-monospace text-muted small">
                                        <i class="fa-solid fa-network-wired me-1"></i><?= e($l['ip_address'] ?: '127.0.0.1') ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('System Audit Logs', $renderContent, ['active' => 'audit_logs']);
