<?php
/**
 * Module 6: Reports & System Data
 * Matching Screenshot page 12
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canUpload = $user['role']['can_upload'] ?? true;
$canEdit = $user['role']['can_edit'] ?? false;
$canApprove = $user['role']['can_approve_tasks'] ?? false;
$isAdmin = $user['role']['is_admin'] ?? false;

// Handle download action
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['action']) && $_GET['action'] === 'download') {
    $repId = (int)($_GET['id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM reports WHERE id = ?");
    $stmt->execute([$repId]);
    $r = $stmt->fetch();
    if (!$r) {
        http_response_code(404);
        die('Report record not found.');
    }

    $rawPath = ltrim((string)$r['file_path'], '/');
    $possiblePaths = [
        APP_ROOT . '/uploads/' . $rawPath,
        APP_ROOT . '/uploads/reports/' . basename($rawPath),
        APP_ROOT . '/uploads/' . basename($rawPath)
    ];

    $foundPath = null;
    foreach ($possiblePaths as $p) {
        if (file_exists($p) && is_file($p)) {
            $foundPath = $p;
            break;
        }
    }

    $downloadName = $r['file_name'] ?: basename($rawPath ?: 'report_document.pdf');

    if ($foundPath) {
        $mime = mime_content_type($foundPath) ?: 'application/octet-stream';
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename="' . addslashes($downloadName) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($foundPath));
        readfile($foundPath);
        exit;
    } else {
        // If file doesn't physically exist yet on this installation, provide sample content
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . addslashes(pathinfo($downloadName, PATHINFO_FILENAME) . '.txt') . '"');
        echo "MINISTRY OF HEALTH - STATE DEPARTMENT FOR MEDICAL SERVICES\n";
        echo "REPORT DOSSIER: " . $r['title'] . " (" . $r['report_code'] . ")\n";
        echo "Module: " . $r['module'] . "\n";
        echo "Report Date: " . $r['report_date'] . "\n";
        echo "Status: " . $r['status'] . "\n\n";
        echo "Summary / Findings:\n" . ($r['description'] ?: 'No notes provided.') . "\n\n";
        echo "Server Document Path: /uploads/" . $r['file_path'] . "\n";
        exit;
    }
}

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'upload') {
        if (!$canUpload) json_response(['error' => 'Permission denied: Upload capability required.'], 403);
        $title = trim($input['title'] ?? '');
        $module = trim($input['module'] ?? 'Projects & Programmes');
        $projectId = !empty($input['project_id']) ? (int)$input['project_id'] : null;
        $desc = trim($input['description'] ?? '');
        $date = !empty($input['report_date']) ? trim($input['report_date']) : date('Y-m-d');
        $vis = $isAdmin ? ($input['visibility'] ?? 'Restricted') : 'Restricted';
        $reportCode = 'REP-' . date('Ymd') . '-' . rand(1000, 9999);

        if ($title === '') json_response(['error' => 'Report title is required.'], 422);

        // Upload directory in uploads/reports/
        $uploadDir = APP_ROOT . '/uploads/reports';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0775, true);
        }

        $fileName = 'Report_Document.pdf';
        $filePath = 'reports/Report_Document.pdf';
        $fileSizeKb = 512;

        if (!empty($_FILES['report_file']) && $_FILES['report_file']['error'] === UPLOAD_ERR_OK) {
            $tmpPath = $_FILES['report_file']['tmp_name'];
            $origName = basename($_FILES['report_file']['name']);
            $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

            $allowed = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx', 'zip', 'png', 'jpg', 'jpeg'];
            if (!in_array($ext, $allowed, true)) {
                json_response(['error' => 'File type .' . $ext . ' is not permitted. Please upload PDF, Word, Excel, CSV, or image files.'], 422);
            }

            if ($_FILES['report_file']['size'] > 25 * 1024 * 1024) {
                json_response(['error' => 'File size exceeds maximum allowable limit of 25MB.'], 422);
            }

            $cleanBase = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', pathinfo($origName, PATHINFO_FILENAME));
            $savedName = 'rep_' . date('Ymd_His') . '_' . substr(bin2hex(random_bytes(4)), 0, 6) . '_' . substr($cleanBase, 0, 30) . '.' . $ext;
            $destPath = $uploadDir . '/' . $savedName;

            if (move_uploaded_file($tmpPath, $destPath)) {
                @chmod($destPath, 0664);
                $fileName = $origName;
                $filePath = 'reports/' . $savedName;
                $fileSizeKb = (int)round(filesize($destPath) / 1024);
            } else {
                json_response(['error' => 'Server could not write file to /uploads/reports/. Please verify directory permissions.'], 500);
            }
        } elseif (!empty($_FILES['report_file']) && $_FILES['report_file']['error'] !== UPLOAD_ERR_NO_FILE) {
            $err = $_FILES['report_file']['error'];
            json_response(['error' => 'Upload failed with PHP code: ' . $err], 422);
        } else {
            // Check if fallback manual name was provided
            if (!empty($input['file_name'])) {
                $fileName = trim($input['file_name']);
                $filePath = 'reports/' . $fileName;
            }
        }

        try {
            $stmt = $db->prepare("INSERT INTO reports (report_code, title, module, project_id, description, report_date, file_path, file_name, file_size_kb, visibility, status, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");
            $stmt->execute([$reportCode, $title, $module, $projectId, $desc, $date, $filePath, $fileName, $fileSizeKb, $vis, (int)($user['id'] ?? 1)]);
            $id = (int)$db->lastInsertId();

            log_activity('upload', (int)($user['id'] ?? 1), "Uploaded report: {$title} ({$reportCode})", $id, 'reports');
            json_response(['success' => true, 'message' => "Report {$reportCode} uploaded successfully to /uploads/{$filePath}."]);
        } catch (Throwable $e) {
            error_log('Report save error: ' . $e->getMessage());
            json_response(['error' => 'Database error saving report: ' . $e->getMessage()], 500);
        }
    }

    if ($action === 'approve') {
        if (!$canApprove) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $comment = trim($input['review_comment'] ?? 'Approved by executive reviewer.');
        try {
            $stmt = $db->prepare("UPDATE reports SET status='Approved', reviewed_by=?, review_comment=?, reviewed_at=NOW() WHERE id=?");
            $stmt->execute([(int)($user['id'] ?? 1), $comment, $id]);
            log_activity('approve', (int)($user['id'] ?? 1), "Approved report #{$id}", $id, 'reports');
            json_response(['success' => true, 'message' => 'Report approved.']);
        } catch (Throwable $e) {
            json_response(['error' => 'Error approving report: ' . $e->getMessage()], 500);
        }
    }

    if ($action === 'reject') {
        if (!$canApprove) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $comment = trim($input['review_comment'] ?? 'Rejected: please update requested indicators.');
        try {
            $stmt = $db->prepare("UPDATE reports SET status='Rejected', reviewed_by=?, review_comment=?, reviewed_at=NOW() WHERE id=?");
            $stmt->execute([(int)($user['id'] ?? 1), $comment, $id]);
            log_activity('reject', (int)($user['id'] ?? 1), "Rejected report #{$id}", $id, 'reports');
            json_response(['success' => true, 'message' => 'Report rejected with comments.']);
        } catch (Throwable $e) {
            json_response(['error' => 'Error rejecting report: ' . $e->getMessage()], 500);
        }
    }

    if ($action === 'delete') {
        if (!$isAdmin) json_response(['error' => 'Permission denied: Only Administrators can delete reports.'], 403);
        $id = (int)($input['id'] ?? 0);
        try {
            $db->prepare("DELETE FROM reports WHERE id=?")->execute([$id]);
            log_activity('delete', (int)($user['id'] ?? 1), "Deleted report ID: {$id}", $id, 'reports');
            json_response(['success' => true, 'message' => 'Report deleted.']);
        } catch (Throwable $e) {
            json_response(['error' => 'Error deleting report: ' . $e->getMessage()], 500);
        }
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Filters
$search = trim($_GET['search'] ?? '');
$filterProj = !empty($_GET['project_id']) ? (int)$_GET['project_id'] : null;
$filterDate = $_GET['date'] ?? '';

$sql = "SELECT r.*, p.title as project_title, p.project_code, u.full_name as uploader_name FROM reports r LEFT JOIN projects p ON r.project_id = p.id LEFT JOIN users u ON r.uploaded_by = u.id WHERE 1=1";
$params = [];

// Role visibility restrictions
if (!$isAdmin && !($user['role']['can_approve_tasks'] ?? false)) {
    $sql .= " AND r.visibility IN ('Public', 'Restricted')";
}

if ($search !== '') {
    $sql .= " AND (r.title LIKE ? OR r.report_code LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($filterProj) {
    $sql .= " AND r.project_id = ?";
    $params[] = $filterProj;
}

if ($filterDate !== '') {
    $sql .= " AND r.report_date = ?";
    $params[] = $filterDate;
}

$sql .= " ORDER BY r.id DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// Projects dropdown
$allProjects = $db->query("SELECT id, title, project_code FROM projects ORDER BY title")->fetchAll();

function upload_report_form(array $projects, bool $isAdmin): string {
    $projOpts = ['' => '-- Select Project (Optional) --'];
    foreach ($projects as $p) {
        $code = $p['project_code'] ? "[{$p['project_code']}] " : '';
        $projOpts[$p['id']] = $code . $p['title'];
    }

    $fields = [
        ['name' => 'title', 'label' => 'Report Title', 'required' => true, 'full' => true],
        ['name' => 'module', 'label' => 'Module / Category', 'type' => 'select', 'value' => 'Projects & Programmes', 'options' => [
            'Projects & Programmes' => 'Projects & Programmes',
            'Priority Flagships' => 'Priority Flagships',
            'Finance & Grants' => 'Finance & Grants',
            'Directorates' => 'Directorates',
            'Executive Policy' => 'Executive Policy'
        ]],
        ['name' => 'project_id', 'label' => 'Attached Project', 'type' => 'select', 'options' => $projOpts],
        ['name' => 'report_date', 'label' => 'Report Date', 'type' => 'date', 'value' => date('Y-m-d')],
        [
            'name' => 'report_file',
            'label' => 'Attach Document (.pdf, .xlsx, .docx, .csv)',
            'type' => 'file',
            'required' => true,
            'accept' => '.pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.zip,.png,.jpg,.jpeg',
            'hint' => 'Allowed formats: PDF, Word, Excel, CSV, PPT, Images. Files are stored in /uploads/reports/.',
            'full' => true
        ],
    ];

    if ($isAdmin) {
        $fields[] = [
            'name' => 'visibility',
            'label' => 'Visibility Level (Admin Only)',
            'type' => 'select',
            'value' => 'Restricted',
            'options' => [
                'Public' => 'Public (All Staff)',
                'Restricted' => 'Restricted (Authorized Roles)',
                'Confidential' => 'Confidential (Admin & PS Only)'
            ]
        ];
    }

    $fields[] = [
        'name' => 'description',
        'label' => 'Executive Summary & Key Findings',
        'type' => 'textarea',
        'full' => true
    ];

    $form = modal_form('', $fields, 'Submit to Approval Pipeline');
    return str_replace('value="save"', 'value="upload"', $form);
}

$renderContent = function() use ($reports, $allProjects, $search, $filterProj, $filterDate, $canUpload, $canApprove, $isAdmin) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-folder-open text-primary"></i> Reports Management
        </h4>
        <?php if ($canUpload): ?>
            <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Upload Report Document', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(upload_report_form($allProjects, $isAdmin), ENT_QUOTES, 'UTF-8') ?>">
                <i class="fa-solid fa-cloud-arrow-up me-1"></i> Upload Report
            </button>
        <?php endif; ?>
    </div>

    <!-- Storage Location Advisory -->
    <div class="alert alert-info py-2 px-3 small d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3 border-0 shadow-sm" style="background-color: #e8f4fd; color: #0d47a1;">
        <div class="d-flex align-items-center gap-2">
            <i class="fa-solid fa-circle-info text-primary fs-5"></i>
            <span>All uploaded departmental reports, workplans, and dossiers are securely archived in the server repository at <strong><code>uploads/reports/</code></strong>.</span>
        </div>
        <span class="badge bg-primary px-3 py-1 font-monospace">Folder: /uploads/reports/</span>
    </div>

    <!-- Filter Bar (Matching screenshot page 12) -->
    <div class="card border-0 shadow-sm bg-white p-3 mb-3">
        <form method="GET" action="<?= BASE_URL ?>modules/reports.php" class="row g-2 align-items-center">
            <div class="col-12 col-md-4">
                <input type="text" name="search" value="<?= e($search) ?>" class="form-control form-control-sm" placeholder="Search Report Name or ID...">
            </div>
            <div class="col-12 col-md-4">
                <select name="project_id" class="form-select form-select-sm">
                    <option value="">-- Filter by Project --</option>
                    <?php foreach ($allProjects as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= ($filterProj === (int)$p['id']) ? 'selected' : '' ?>>
                            <?= e($p['project_code'] ? "[{$p['project_code']}] " : '') ?><?= e($p['title']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <input type="date" name="date" value="<?= e($filterDate) ?>" class="form-control form-control-sm">
            </div>
            <div class="col-6 col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold"><i class="fa-solid fa-filter me-1"></i> Filter</button>
            </div>
        </form>
    </div>

    <!-- Document List (Matching screenshot page 12) -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small d-flex justify-content-between align-items-center">
            <span><i class="fa-solid fa-list-check me-2"></i> Document List</span>
            <span class="badge bg-light text-primary"><?= count($reports) ?> Reports</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th>Report Details</th>
                            <th>Project</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Uploaded By</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted">No reports found matching query.</td></tr>
                        <?php else: ?>
                            <?php foreach ($reports as $r): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?= e($r['title']) ?></div>
                                        <div class="small text-primary font-monospace fw-semibold"><?= e($r['report_code']) ?></div>
                                        <div class="small text-muted text-truncate" style="max-width: 250px;"><?= e($r['description']) ?></div>
                                    </td>
                                    <td>
                                        <?php if (!empty($r['project_title'])): ?>
                                            <div class="fw-semibold text-truncate" style="max-width: 220px;"><?= e($r['project_title']) ?></div>
                                            <div class="small text-muted font-monospace"><?= e($r['project_code']) ?></div>
                                        <?php else: ?>
                                            <span class="text-muted small">Departmental General</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="small text-muted"><i class="fa-regular fa-calendar-check me-1"></i> Report: <?= format_date($r['report_date']) ?></div>
                                        <div class="small text-muted"><i class="fa-solid fa-arrow-up-from-bracket me-1"></i> Up: <?= date('d M Y', strtotime($r['created_at'])) ?></div>
                                    </td>
                                    <td>
                                        <?php if ($r['status'] === 'Approved'): ?>
                                            <span class="badge bg-success">Approved</span>
                                        <?php elseif ($r['status'] === 'Rejected'): ?>
                                            <span class="badge bg-danger">Rejected</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        <?php endif; ?>
                                        <?php if ($isAdmin): ?>
                                            <div class="mt-1"><span class="badge bg-light text-secondary border" style="font-size: 0.65rem;"><?= e($r['visibility']) ?></span></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <i class="fa-solid fa-user small me-1 text-muted"></i> <?= e($r['uploader_name'] ?? 'System Administrator') ?>
                                    </td>
                                    <td class="text-end text-nowrap">
                                        <?php if ($canApprove && $r['status'] === 'Pending'): ?>
                                            <button type="button" class="btn btn-sm btn-success py-0 px-2 me-1" title="Approve Report" onclick="if(confirm('Approve report <?= e($r['report_code']) ?>?')){ const fd=new FormData(); fd.append('action','approve'); fd.append('id','<?= (int)$r['id'] ?>'); fd.append('csrf_token', window.PPSDOMS.csrf()); fetch('<?= BASE_URL ?>modules/reports.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>location.reload()); }"><i class="fa-solid fa-check"></i></button>
                                            <button type="button" class="btn btn-sm btn-danger py-0 px-2 me-1" title="Reject Report" onclick="const rsn = prompt('Enter rejection reason:'); if(rsn){ const fd=new FormData(); fd.append('action','reject'); fd.append('id','<?= (int)$r['id'] ?>'); fd.append('review_comment', rsn); fd.append('csrf_token', window.PPSDOMS.csrf()); fetch('<?= BASE_URL ?>modules/reports.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>location.reload()); }"><i class="fa-solid fa-xmark"></i></button>
                                        <?php endif; ?>
                                        <a href="<?= BASE_URL ?>modules/reports.php?action=download&id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary py-0 px-2 me-1" title="Download Document (<?= e($r['file_name']) ?>)" target="_blank"><i class="fa-solid fa-download"></i></a>
                                        <?php if ($isAdmin): ?>
                                            <?= delete_btn(BASE_URL . 'modules/reports.php', (int)$r['id']) ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('Reports Management', $renderContent, ['active' => 'reports']);
