<?php
/**
 * Module 5: Meeting Minutes (Local & Foreign Financiers)
 * Matching Screenshot page 6
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $date = $input['date'] ?? date('Y-m-d');
        $title = trim($input['title'] ?? '');
        $desc = trim($input['description'] ?? '');
        $financier = trim($input['financier'] ?? 'Local & Foreign Financiers');
        $venue = trim($input['venue'] ?? 'Afya House');
        $attendees = trim($input['attendees'] ?? '');
        $agenda = trim($input['agenda'] ?? '');
        $decisions = trim($input['decisions'] ?? '');
        $document = trim($input['document'] ?? 'meeting_minutes.pdf');

        if ($title === '') json_response(['error' => 'Meeting title is required.'], 422);

        if ($id > 0) {
            $stmt = $db->prepare("UPDATE meetings SET date=?, title=?, description=?, financier=?, venue=?, attendees=?, agenda=?, decisions=?, document=? WHERE id=?");
            $stmt->execute([$date, $title, $desc, $financier, $venue, $attendees, $agenda, $decisions, $document, $id]);
            log_activity('update', $user['id'], "Updated Meeting Minutes: {$title}", $id, 'minutes');
        } else {
            $stmt = $db->prepare("INSERT INTO meetings (date, title, description, financier, venue, attendees, agenda, decisions, document, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$date, $title, $desc, $financier, $venue, $attendees, $agenda, $decisions, $document, $user['id']]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Created Meeting Minutes: {$title}", $id, 'minutes');
        }
        json_response(['success' => true, 'message' => 'Meeting minutes saved successfully.']);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM meetings WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted Meeting Minutes ID: {$id}", $id, 'minutes');
        json_response(['success' => true, 'message' => 'Meeting minutes deleted.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Fetch meetings
$meetings = $db->query("SELECT * FROM meetings ORDER BY date DESC, id DESC")->fetchAll();

function meeting_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'date', 'label' => 'Meeting Date', 'type' => 'date', 'required' => true, 'value' => $r['date'] ?? date('Y-m-d')],
        ['name' => 'title', 'label' => 'Meeting Title', 'required' => true, 'value' => $r['title'] ?? ''],
        ['name' => 'financier', 'label' => 'Financier / Donor (Local or Foreign)', 'value' => $r['financier'] ?? 'Local Exchequer & Donors', 'full' => true],
        ['name' => 'venue', 'label' => 'Venue', 'value' => $r['venue'] ?? 'Afya House Boardroom'],
        ['name' => 'document', 'label' => 'Document Attachment File', 'value' => $r['document'] ?? 'meeting_minutes_annual_2025.pdf'],
        ['name' => 'attendees', 'label' => 'Attendees', 'value' => $r['attendees'] ?? '', 'full' => true],
        ['name' => 'agenda', 'label' => 'Meeting Agenda', 'type' => 'textarea', 'value' => $r['agenda'] ?? '', 'full' => true],
        ['name' => 'description', 'label' => 'Description / Executive Summary', 'type' => 'textarea', 'required' => true, 'value' => $r['description'] ?? '', 'full' => true],
        ['name' => 'decisions', 'label' => 'Key Decisions Made & Action Items', 'type' => 'textarea', 'value' => $r['decisions'] ?? '', 'full' => true],
    ], 'Save Meeting Record', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($meetings, $canEdit) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-file-contract text-primary"></i> Meeting Minutes
        </h4>
        <?php if ($canEdit): ?>
            <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Add Meeting Minutes', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(meeting_form(), ENT_QUOTES, 'UTF-8') ?>">
                <i class="fa-solid fa-plus me-1"></i> Add New Entry
            </button>
        <?php endif; ?>
    </div>

    <!-- Meeting Minutes Table (Matching screenshot page 6) -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small">
            <i class="fa-solid fa-list me-2"></i> Meeting Minutes Entries
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 120px;">Date</th>
                            <th style="width: 250px;">Meeting Title</th>
                            <th>Description/Notes</th>
                            <th style="width: 130px;">Document</th>
                            <th class="text-end" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($meetings as $m): ?>
                            <tr>
                                <td class="fw-semibold text-secondary"><?= format_date($m['date']) ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?= e($m['title']) ?></div>
                                    <div class="small text-muted"><i class="fa-solid fa-hand-holding-dollar me-1"></i> <?= e($m['financier'] ?? 'Local & Foreign') ?></div>
                                </td>
                                <td>
                                    <div class="text-muted" style="max-width: 500px;"><?= e($m['description']) ?></div>
                                </td>
                                <td>
                                    <?php if (!empty($m['document'])): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size: 0.75rem;" onclick="window.PPSDOMS.openModal('Attached Minutes Document: <?= e($m['title']) ?>', '<div class=\'text-center p-4\'><i class=\'fa-solid fa-file-pdf text-danger fs-1 mb-3\'></i><h6><?= e($m['document']) ?></h6><p class=\'small text-muted\'>Official Ministerial Signed Minutes Document</p><a href=\'#\' class=\'btn btn-primary btn-sm mt-2\' onclick=\'alert(\'Simulated Document Download Successful\')\'><i class=\'fa-solid fa-download me-1\'></i> Download PDF File</a></div>')">
                                            <i class="fa-solid fa-file-lines me-1"></i> View Doc
                                        </button>
                                    <?php else: ?>
                                        <span class="text-muted small">No File</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end text-nowrap">
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit Minutes', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(meeting_form($m), ENT_QUOTES, 'UTF-8') ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>
                                        <?= delete_btn(BASE_URL . 'modules/minutes.php', (int)$m['id']) ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('Meeting Minutes', $renderContent, ['active' => 'minutes']);
