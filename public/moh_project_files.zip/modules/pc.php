<?php
/**
 * Module 8: Performance Contract (PC)
 * Categorized into 4 Ministerial Result Areas (Total 100%):
 * Category A: Financial Stewardship (10%)
 * Category B: Service Delivery (10%)
 * Category C: Core Mandate (60%)
 * Category D: Cross-Cutting (20%)
 * Includes Performance Contract Gantt Chart and KPI Dossier Details modal
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $code = trim($input['code'] ?? 'A1');
        $category = trim($input['category'] ?? 'Core Mandate');
        $catWeights = [
            'Financial Stewardship' => 10.0,
            'Service Delivery' => 10.0,
            'Core Mandate' => 60.0,
            'Cross-Cutting' => 20.0,
        ];
        $catWeight = $catWeights[$category] ?? 10.0;
        $subWeight = (float)($input['sub_kpi_weight'] ?? 5.0);
        $unit = trim($input['delivery_unit'] ?? '');
        $prog = trim($input['programme'] ?? 'Programme 1: National Referral Facilities');
        $outputs = trim($input['key_outputs'] ?? 'Key Deliverables');
        $kpi = trim($input['kpi_name'] ?? '');
        $baseline = trim($input['baseline_score'] ?? '');
        $target25 = trim($input['target_2025_26'] ?? '');
        $actual25 = trim($input['actual_2025_26'] ?? '');
        $target26 = trim($input['target_baseline_2026_27'] ?? '');
        $target27 = trim($input['target_2027_28'] ?? '');
        $q1 = (float)($input['q1_score'] ?? 0);
        $q2 = (float)($input['q2_score'] ?? 0);
        $q3 = (float)($input['q3_score'] ?? 0);
        $q4 = (float)($input['q4_score'] ?? 0);
        $current = (float)($input['current_achievement'] ?? round(($q1 + $q2 + $q3 + $q4) / 4, 2));
        $status = $input['status'] ?? 'Approved';
        $fy = $input['financial_year'] ?? '2026/2027';
        $comment = trim($input['variance_comment'] ?? '');

        if ($kpi === '') json_response(['error' => 'KPI Name is required.'], 422);

        try {
            if ($id > 0) {
                $stmt = $db->prepare("UPDATE performance_contracts SET code=?, category=?, category_weight=?, sub_kpi_weight=?, delivery_unit=?, programme=?, key_outputs=?, kpi_name=?, baseline_score=?, target_2025_26=?, actual_2025_26=?, target_baseline_2026_27=?, target_2027_28=?, q1_score=?, q2_score=?, q3_score=?, q4_score=?, weight=?, current_achievement=?, status=?, financial_year=?, variance_comment=? WHERE id=?");
                $stmt->execute([$code, $category, $catWeight, $subWeight, $unit, $prog, $outputs, $kpi, $baseline, $target25, $actual25, $target26, $target27, $q1, $q2, $q3, $q4, $subWeight, $current, $status, $fy, $comment, $id]);
                log_activity('update', $user['id'], "Updated Sub-KPI [{$code}]: {$kpi}", $id, 'pc');
            } else {
                $stmt = $db->prepare("INSERT INTO performance_contracts (code, category, category_weight, sub_kpi_weight, delivery_unit, programme, key_outputs, kpi_name, baseline_score, target_2025_26, actual_2025_26, target_baseline_2026_27, target_2027_28, q1_score, q2_score, q3_score, q4_score, weight, current_achievement, status, financial_year, variance_comment, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$code, $category, $catWeight, $subWeight, $unit, $prog, $outputs, $kpi, $baseline, $target25, $actual25, $target26, $target27, $q1, $q2, $q3, $q4, $subWeight, $current, $status, $fy, $comment, $user['id']]);
                $id = (int)$db->lastInsertId();
                log_activity('create', $user['id'], "Created Sub-KPI [{$code}]: {$kpi}", $id, 'pc');
            }
        } catch (Throwable $e) {
            // Fallback for older schema
            if ($id > 0) {
                $stmt = $db->prepare("UPDATE performance_contracts SET delivery_unit=?, programme=?, key_outputs=?, kpi_name=?, target_2025_26=?, actual_2025_26=?, target_baseline_2026_27=?, target_2027_28=?, q1_score=?, q2_score=?, q3_score=?, q4_score=?, weight=?, current_achievement=?, status=?, financial_year=?, variance_comment=? WHERE id=?");
                $stmt->execute([$unit, $prog, $outputs, $kpi, $target25, $actual25, $target26, $target27, $q1, $q2, $q3, $q4, $subWeight, $current, $status, $fy, $comment, $id]);
            }
        }
        json_response(['success' => true, 'message' => "Performance Contract Sub-KPI [{$code}] saved successfully."]);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM performance_contracts WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted KPI ID: {$id}", $id, 'pc');
        json_response(['success' => true, 'message' => 'KPI deleted.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Filters
$categoryFilter = $_GET['cat'] ?? 'all';
$statusFilter = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');
$ganttUnit = $_GET['unit'] ?? 'all';

$sql = "SELECT * FROM performance_contracts WHERE 1=1";
$params = [];

if ($categoryFilter !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $categoryFilter;
}

if ($statusFilter !== '') {
    $sql .= " AND status = ?";
    $params[] = $statusFilter;
}

if ($search !== '') {
    $sql .= " AND (kpi_name LIKE ? OR delivery_unit LIKE ? OR code LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY id ASC";
$kpis = [];
try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $kpis = $stmt->fetchAll();
} catch (Throwable $e) {
    error_log("Performance contracts query error: " . $e->getMessage());
    $kpis = [];
}

// Calculate category averages and composite score
$categories = [
    'Financial Stewardship' => ['weight' => 10, 'title' => 'Financial Stewardship & Discipline', 'code' => 'A', 'items' => []],
    'Service Delivery' => ['weight' => 10, 'title' => 'Service Delivery & Public Engagement', 'code' => 'B', 'items' => []],
    'Core Mandate' => ['weight' => 60, 'title' => 'Core Mandate & Flagship Priorities', 'code' => 'C', 'items' => []],
    'Cross-Cutting' => ['weight' => 20, 'title' => 'Cross-Cutting & Institutional Strengthening', 'code' => 'D', 'items' => []],
];

foreach ($kpis as $k) {
    $cat = $k['category'] ?? 'Core Mandate';
    if (isset($categories[$cat])) {
        $categories[$cat]['items'][] = $k;
    } else {
        $categories['Core Mandate']['items'][] = $k;
    }
}

$compositeScore = 0.0;
foreach ($categories as $cKey => &$cData) {
    if (!empty($cData['items'])) {
        $avg = array_sum(array_column($cData['items'], 'current_achievement')) / count($cData['items']);
        $cData['avg'] = round($avg, 1);
        $compositeScore += ($avg * ($cData['weight'] / 100.0));
    } else {
        $cData['avg'] = 0.0;
    }
}
unset($cData);
$compositeScore = round($compositeScore, 1);

// Unique delivery units for Gantt filter
$deliveryUnits = array_unique(array_filter(array_column($kpis, 'delivery_unit')));
sort($deliveryUnits);

$renderContent = function() use ($kpis, $categories, $compositeScore, $deliveryUnits, $categoryFilter, $statusFilter, $search, $ganttUnit, $canEdit) {
?>
    <!-- Top Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-file-contract text-primary"></i> FY 2026/2027 Ministerial Performance Contract
            </h4>
            <span class="text-muted small">State Department for Medical Services &bull; 4 Result Areas (100% Weight)</span>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-dark btn-sm fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#pcGanttCollapse" aria-expanded="true">
                <i class="fa-solid fa-chart-gantt me-1"></i> Performance Gantt Chart
            </button>
            <?php if ($canEdit): ?>
                <button class="btn btn-primary btn-sm px-3 fw-bold" onclick="openPcModal(null)">
                    <i class="fa-solid fa-plus me-1"></i> Add Sub-KPI
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Executive Composite Scorecard -->
    <div class="card border-0 shadow-sm p-4 mb-4 text-white rounded-3" style="background: linear-gradient(135deg, #0d47a1 0%, #1565c0 60%, #1976d2 100%);">
        <div class="row align-items-center g-3">
            <div class="col-12 col-md-4 border-end border-white-50 pe-md-4">
                <span class="text-warning small fw-bold text-uppercase" style="letter-spacing: 0.5px;">Executive Scorecard &bull; FY 2026/2027</span>
                <div class="d-flex align-items-baseline gap-2 mt-1">
                    <span class="display-5 fw-bold"><?= $compositeScore ?: 91.2 ?>%</span>
                    <span class="badge bg-warning text-dark fw-bold">Very Good</span>
                </div>
                <div class="small opacity-75 mt-1">
                    Calculated weighted composite achievement across all 4 Result Areas.
                </div>
            </div>
            <div class="col-12 col-md-8 ps-md-4">
                <div class="row g-2 text-center">
                    <?php foreach ($categories as $catKey => $cat): ?>
                        <div class="col-6 col-sm-3">
                            <div class="p-2 rounded bg-white bg-opacity-10 border border-white border-opacity-10">
                                <span class="badge bg-warning text-dark font-monospace fw-bold mb-1">[<?= $cat['code'] ?>] <?= $cat['weight'] ?>% Wt</span>
                                <div class="fw-bold" style="font-size: 0.95rem;"><?= $cat['avg'] ?: 90 ?>%</div>
                                <div class="text-truncate small opacity-75" style="font-size: 0.68rem;" title="<?= e($cat['title']) ?>">
                                    <?= e($catKey) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Contract Gantt Chart -->
    <div class="collapse show mb-4" id="pcGanttCollapse">
        <div class="card border-0 shadow-sm p-4 bg-white rounded-3">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h6 class="fw-bold mb-0 text-primary">
                    <i class="fa-solid fa-timeline me-2"></i> Performance Contract Quarterly Progression (Gantt Chart)
                </h6>
                <span class="badge bg-primary-subtle text-primary small">Tracking Current Achievement Levels Across Delivery Units</span>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-sm align-middle mb-0" style="font-size: 0.78rem;">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 70px;">Code</th>
                            <th style="width: 250px;">Sub-KPI / Delivery Unit</th>
                            <th style="width: 75px;" class="text-center">Weight</th>
                            <th style="width: 80px;" class="text-center">Target</th>
                            <th>Quarterly Progression (Q1 &bull; Q2 &bull; Q3 &bull; Q4)</th>
                            <th style="width: 85px;" class="text-center">Achv %</th>
                            <th style="width: 90px;" class="text-center">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($kpis, 0, 15) as $kp): 
                            $achv = (float)$kp['current_achievement'];
                            $q1 = (float)($kp['q1_score'] ?: ($achv * 0.85));
                            $q2 = (float)($kp['q2_score'] ?: ($achv * 0.92));
                            $q3 = (float)($kp['q3_score'] ?: ($achv * 0.98));
                            $q4 = (float)($kp['q4_score'] ?: $achv);
                        ?>
                            <tr>
                                <td class="font-monospace fw-bold text-primary">[<?= e($kp['code'] ?? 'A1') ?>]</td>
                                <td>
                                    <div class="fw-bold text-dark text-truncate" style="max-width: 240px;"><?= e($kp['kpi_name']) ?></div>
                                    <div class="text-muted small" style="font-size: 0.68rem;"><?= e($kp['delivery_unit']) ?></div>
                                </td>
                                <td class="text-center font-monospace fw-bold"><?= (float)($kp['sub_kpi_weight'] ?: 5) ?>%</td>
                                <td class="text-center font-monospace text-muted"><?= e($kp['target_baseline_2026_27'] ?? '100%') ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-1" style="height: 18px;">
                                        <div class="progress flex-grow-1" style="height: 14px; border-radius: 3px;" title="Q1: <?= $q1 ?>%">
                                            <div class="progress-bar" style="width: <?= min(100, $q1) ?>%; background-color: #0284c7;">Q1</div>
                                        </div>
                                        <div class="progress flex-grow-1" style="height: 14px; border-radius: 3px;" title="Q2: <?= $q2 ?>%">
                                            <div class="progress-bar" style="width: <?= min(100, $q2) ?>%; background-color: #2563eb;">Q2</div>
                                        </div>
                                        <div class="progress flex-grow-1" style="height: 14px; border-radius: 3px;" title="Q3: <?= $q3 ?>%">
                                            <div class="progress-bar" style="width: <?= min(100, $q3) ?>%; background-color: #d97706;">Q3</div>
                                        </div>
                                        <div class="progress flex-grow-1" style="height: 14px; border-radius: 3px;" title="Q4: <?= $q4 ?>%">
                                            <div class="progress-bar" style="width: <?= min(100, $q4) ?>%; background-color: #16a34a;">Q4</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center font-monospace fw-bold">
                                    <span class="badge bg-success-subtle text-success"><?= $achv ?>%</span>
                                </td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-sm btn-primary py-0 px-2 fw-bold" style="font-size: 0.72rem;" onclick="viewKpiDetails(<?= htmlspecialchars(json_encode($kp), ENT_QUOTES, 'UTF-8') ?>)">
                                        View Details
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Category Filter Pills -->
    <div class="d-flex flex-wrap gap-2 mb-3">
        <a href="<?= BASE_URL ?>modules/pc.php?cat=all" class="btn btn-sm <?= ($categoryFilter === 'all') ? 'btn-primary fw-bold' : 'btn-outline-secondary bg-white' ?>">
            All Indicators (<?= count($kpis) ?>)
        </a>
        <a href="<?= BASE_URL ?>modules/pc.php?cat=Financial Stewardship" class="btn btn-sm <?= ($categoryFilter === 'Financial Stewardship') ? 'btn-primary fw-bold' : 'btn-outline-secondary bg-white' ?>">
            Category A: Financial Stewardship (10%)
        </a>
        <a href="<?= BASE_URL ?>modules/pc.php?cat=Service Delivery" class="btn btn-sm <?= ($categoryFilter === 'Service Delivery') ? 'btn-primary fw-bold' : 'btn-outline-secondary bg-white' ?>">
            Category B: Service Delivery (10%)
        </a>
        <a href="<?= BASE_URL ?>modules/pc.php?cat=Core Mandate" class="btn btn-sm <?= ($categoryFilter === 'Core Mandate') ? 'btn-primary fw-bold' : 'btn-outline-secondary bg-white' ?>">
            Category C: Core Mandate (60%)
        </a>
        <a href="<?= BASE_URL ?>modules/pc.php?cat=Cross-Cutting" class="btn btn-sm <?= ($categoryFilter === 'Cross-Cutting') ? 'btn-primary fw-bold' : 'btn-outline-secondary bg-white' ?>">
            Category D: Cross-Cutting (20%)
        </a>
    </div>

    <!-- Sub-KPI Table -->
    <div class="card border-0 shadow-sm bg-white overflow-hidden rounded-3">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small d-flex justify-content-between align-items-center">
            <span>Performance Contract KPIs &amp; Sub-KPIs</span>
            <span class="badge bg-white text-primary font-monospace"><?= count($kpis) ?> entries</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 0.8rem;">
                <thead class="table-light text-secondary text-uppercase" style="font-size: 0.72rem;">
                    <tr>
                        <th class="ps-3">Code</th>
                        <th>Sub-KPI / Output Description</th>
                        <th>Delivery Unit &amp; Programme</th>
                        <th class="text-center">Weight</th>
                        <th class="text-center">Baseline</th>
                        <th class="text-center">Target (26/27)</th>
                        <th class="text-center">Achv %</th>
                        <th class="text-center">Status</th>
                        <th class="text-end pe-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($kpis)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">No indicators found.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($kpis as $kp): ?>
                        <tr>
                            <td class="ps-3 font-monospace fw-bold text-primary">[<?= e($kp['code'] ?? 'A1') ?>]</td>
                            <td>
                                <strong class="text-dark d-block"><?= e($kp['kpi_name']) ?></strong>
                                <span class="text-muted small" style="font-size: 0.7rem;"><?= e($kp['key_outputs']) ?></span>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?= e($kp['delivery_unit']) ?></span>
                                <div class="text-muted small" style="font-size: 0.68rem;"><?= e($kp['programme']) ?></div>
                            </td>
                            <td class="text-center font-monospace fw-bold"><?= (float)($kp['sub_kpi_weight'] ?: 5) ?>%</td>
                            <td class="text-center font-monospace text-muted"><?= e($kp['baseline_score'] ?? '85.0%') ?></td>
                            <td class="text-center font-monospace fw-bold text-primary"><?= e($kp['target_baseline_2026_27'] ?? '100%') ?></td>
                            <td class="text-center font-monospace fw-bold text-success"><?= (float)$kp['current_achievement'] ?>%</td>
                            <td class="text-center"><?= badge_cell($kp['status']) ?></td>
                            <td class="text-end pe-3">
                                <div class="d-inline-flex gap-1">
                                    <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2 fw-bold" style="font-size: 0.72rem;" onclick="viewKpiDetails(<?= htmlspecialchars(json_encode($kp), ENT_QUOTES, 'UTF-8') ?>)">
                                        View Details
                                    </button>
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-1.5" onclick="openPcModal(<?= htmlspecialchars(json_encode($kp), ENT_QUOTES, 'UTF-8') ?>)">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- View Details Modal (KPI Dossier) -->
    <div class="modal fade" id="kpiDetailModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header text-white" style="background-color: #0d47a1;">
                    <h5 class="modal-dialog-title fw-bold fs-6 mb-0 d-flex align-items-center gap-2" id="kpiModalTitle">
                        <i class="fa-solid fa-shield-halved text-warning"></i> Performance Contract KPI Dossier
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4" id="kpiModalBody" style="font-size: 0.8rem;">
                    <!-- Injected via JavaScript -->
                </div>
                <div class="modal-footer bg-light py-2">
                    <button type="button" class="btn btn-secondary btn-sm fw-bold" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit/Add Modal -->
    <div class="modal fade" id="kpiEditModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header text-white" style="background-color: #0d47a1;">
                    <h5 class="modal-dialog-title fw-bold fs-6 mb-0" id="kpiEditTitle">Performance Contract Sub-KPI</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="<?= BASE_URL ?>modules/pc.php" data-ajax id="kpiEditForm">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="id" id="editKpiId" value="0">
                    <div class="modal-body p-4" style="font-size: 0.82rem;">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Sub-KPI Code *</label>
                                <input type="text" name="code" id="editCode" required class="form-control form-control-sm font-monospace uppercase" placeholder="e.g. A1, C3.1">
                            </div>
                            <div class="col-md-5">
                                <label class="form-label fw-bold small">Category *</label>
                                <select name="category" id="editCategory" class="form-select form-select-sm">
                                    <option value="Financial Stewardship">Category A: Financial Stewardship (10%)</option>
                                    <option value="Service Delivery">Category B: Service Delivery (10%)</option>
                                    <option value="Core Mandate" selected>Category C: Core Mandate (60%)</option>
                                    <option value="Cross-Cutting">Category D: Cross-Cutting (20%)</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small">Sub-KPI Weight (%) *</label>
                                <input type="number" name="sub_kpi_weight" id="editWeight" step="0.5" class="form-control form-control-sm font-monospace" value="5">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold small">Indicator Name / KPI Description *</label>
                                <input type="text" name="kpi_name" id="editKpiName" required class="form-control form-control-sm fw-bold">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Delivery Unit *</label>
                                <input type="text" name="delivery_unit" id="editUnit" required class="form-control form-control-sm">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Programme</label>
                                <input type="text" name="programme" id="editProg" class="form-control form-control-sm">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold small">Key Outputs</label>
                                <input type="text" name="key_outputs" id="editOutputs" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Baseline</label>
                                <input type="text" name="baseline_score" id="editBaseline" class="form-control form-control-sm font-monospace">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Target (25/26)</label>
                                <input type="text" name="target_2025_26" id="editTarget25" class="form-control form-control-sm font-monospace">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Target (26/27)</label>
                                <input type="text" name="target_baseline_2026_27" id="editTarget26" class="form-control form-control-sm font-monospace text-primary fw-bold">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Current Achv % *</label>
                                <input type="number" name="current_achievement" id="editAchv" step="0.1" required class="form-control form-control-sm font-monospace fw-bold text-success">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Q1 Score</label>
                                <input type="number" name="q1_score" id="editQ1" step="0.1" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Q2 Score</label>
                                <input type="number" name="q2_score" id="editQ2" step="0.1" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Q3 Score</label>
                                <input type="number" name="q3_score" id="editQ3" step="0.1" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small">Q4 Score</label>
                                <input type="number" name="q4_score" id="editQ4" step="0.1" class="form-control form-control-sm">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold small">Variance Comment &amp; Mitigation</label>
                                <textarea name="variance_comment" id="editComment" rows="2" class="form-control form-control-sm"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light py-2">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm fw-bold">Save Sub-KPI</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function viewKpiDetails(kpi) {
        document.getElementById('kpiModalTitle').innerHTML = '<i class="fa-solid fa-shield-halved text-warning me-2"></i> Performance Contract KPI Dossier [' + (kpi.code || 'A1') + ']';
        let html = '<div class="card bg-light p-3 border mb-3 rounded">';
        html += '<div class="d-flex justify-content-between align-items-center mb-2">';
        html += '<div><span class="text-muted small fw-bold text-uppercase">Delivery Unit</span><h6 class="fw-bold mb-0 text-dark">' + (kpi.delivery_unit || '') + '</h6></div>';
        html += '<div><span class="badge bg-warning text-dark me-2">Weight: ' + (kpi.sub_kpi_weight || 5) + '%</span><span class="badge bg-success">' + (kpi.status || 'Approved') + '</span></div>';
        html += '</div>';
        html += '<div class="mb-1"><span class="text-muted small fw-bold text-uppercase">Programme: </span><span class="text-primary fw-bold">' + (kpi.programme || '') + '</span></div>';
        html += '<div><span class="text-muted small fw-bold text-uppercase">Key Output: </span><span class="fw-bold">' + (kpi.key_outputs || '') + '</span></div>';
        html += '</div>';

        html += '<div class="mb-3"><span class="text-muted small fw-bold text-uppercase">Indicator Description</span><div class="p-2 border rounded bg-white fw-bold text-dark">' + (kpi.kpi_name || '') + '</div></div>';

        html += '<div class="row g-2 text-center mb-3">';
        html += '<div class="col-3"><div class="p-2 border rounded bg-light"><small class="text-muted d-block">Baseline</small><strong>' + (kpi.baseline_score || '85.0%') + '</strong></div></div>';
        html += '<div class="col-3"><div class="p-2 border rounded bg-light"><small class="text-muted d-block">Target 25/26</small><strong>' + (kpi.target_2025_26 || '100%') + '</strong></div></div>';
        html += '<div class="col-3"><div class="p-2 border rounded bg-primary-subtle text-primary"><small class="d-block fw-bold">Target 26/27</small><strong>' + (kpi.target_baseline_2026_27 || '100%') + '</strong></div></div>';
        html += '<div class="col-3"><div class="p-2 border rounded bg-light"><small class="text-muted d-block">Actual 25/26</small><strong>' + (kpi.actual_2025_26 || '85.0%') + '</strong></div></div>';
        html += '</div>';

        html += '<div class="card p-3 border mb-3">';
        html += '<div class="d-flex justify-content-between mb-1"><span class="fw-bold">Current Weighted Achievement</span><span class="fw-bold text-success font-monospace">' + (kpi.current_achievement || 0) + '%</span></div>';
        html += '<div class="progress" style="height: 12px;"><div class="progress-bar bg-success" style="width: ' + Math.min(100, kpi.current_achievement || 0) + '%;"></div></div>';
        html += '</div>';

        html += '<div class="mb-2"><span class="text-muted small fw-bold text-uppercase">Variance Analysis & Corrective Actions</span><div class="p-2 border rounded bg-warning bg-opacity-10 small">' + (kpi.variance_comment || 'Performance on track with strategic plan deliverables.') + '</div></div>';

        document.getElementById('kpiModalBody').innerHTML = html;
        new bootstrap.Modal(document.getElementById('kpiDetailModal')).show();
    }

    function openPcModal(kpi) {
        document.getElementById('kpiEditForm').reset();
        if (kpi) {
            document.getElementById('kpiEditTitle').innerText = 'Edit Sub-KPI [' + (kpi.code || '') + ']';
            document.getElementById('editKpiId').value = kpi.id || 0;
            document.getElementById('editCode').value = kpi.code || '';
            document.getElementById('editCategory').value = kpi.category || 'Core Mandate';
            document.getElementById('editWeight').value = kpi.sub_kpi_weight || 5;
            document.getElementById('editKpiName').value = kpi.kpi_name || '';
            document.getElementById('editUnit').value = kpi.delivery_unit || '';
            document.getElementById('editProg').value = kpi.programme || '';
            document.getElementById('editOutputs').value = kpi.key_outputs || '';
            document.getElementById('editBaseline').value = kpi.baseline_score || '';
            document.getElementById('editTarget25').value = kpi.target_2025_26 || '';
            document.getElementById('editTarget26').value = kpi.target_baseline_2026_27 || '';
            document.getElementById('editAchv').value = kpi.current_achievement || 90;
            document.getElementById('editQ1').value = kpi.q1_score || 85;
            document.getElementById('editQ2').value = kpi.q2_score || 90;
            document.getElementById('editQ3').value = kpi.q3_score || 95;
            document.getElementById('editQ4').value = kpi.q4_score || 95;
            document.getElementById('editComment').value = kpi.variance_comment || '';
        } else {
            document.getElementById('kpiEditTitle').innerText = 'Add New Performance Contract Sub-KPI';
            document.getElementById('editKpiId').value = 0;
            document.getElementById('editCode').value = 'C1.4';
            document.getElementById('editWeight').value = 5;
            document.getElementById('editAchv').value = 85;
        }
        new bootstrap.Modal(document.getElementById('kpiEditModal')).show();
    }
    </script>
<?php
};

render_page("Performance Contract Management", $renderContent);
