<?php
/**
 * Module 9: Visitors Management
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $name = trim($input['full_name'] ?? '');
        $idNo = trim($input['id_number'] ?? '');
        $phone = trim($input['phone'] ?? '');
        $org = trim($input['organization'] ?? '');
        $host = trim($input['host_officer'] ?? '');
        $office = trim($input['office_visited'] ?? '');
        $purpose = trim($input['purpose'] ?? '');
        $badge = trim($input['badge_no'] ?? '');
        $status = $input['status'] ?? 'Checked In';

        if ($name === '') json_response(['error' => 'Visitor name is required.'], 422);

        if ($badge === '') {
            $badge = 'VIS-' . rand(100, 999);
        }

        if ($id > 0) {
            $stmt = $db->prepare("UPDATE visitors SET full_name=?, id_number=?, phone=?, organization=?, host_officer=?, office_visited=?, purpose=?, badge_no=?, status=? WHERE id=?");
            $stmt->execute([$name, $idNo, $phone, $org, $host, $office, $purpose, $badge, $status, $id]);
            log_activity('update', $user['id'], "Updated visitor: {$name}", $id, 'visitors');
        } else {
            $stmt = $db->prepare("INSERT INTO visitors (badge_no, full_name, id_number, phone, organization, host_officer, office_visited, purpose, check_in_time, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)");
            $stmt->execute([$badge, $name, $idNo, $phone, $org, $host, $office, $purpose, $status, $user['id']]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Registered visitor: {$name} (Badge: {$badge})", $id, 'visitors');
        }
        json_response(['success' => true, 'message' => 'Visitor recorded successfully.']);
    }

    if ($action === 'checkout') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("UPDATE visitors SET status = 'Checked Out', check_out_time = NOW() WHERE id = ?")->execute([$id]);
        log_activity('checkout', $user['id'], "Visitor checked out ID: {$id}", $id, 'visitors');
        json_response(['success' => true, 'message' => 'Visitor successfully checked out.']);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM visitors WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted visitor record ID: {$id}", $id, 'visitors');
        json_response(['success' => true, 'message' => 'Visitor record deleted.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Filters
$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = "SELECT * FROM visitors WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (full_name LIKE ? OR badge_no LIKE ? OR id_number LIKE ? OR organization LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($statusFilter !== '') {
    $sql .= " AND status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY check_in_time DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$visitors = $stmt->fetchAll();

function visitor_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'full_name', 'label' => 'Visitor Full Name', 'required' => true, 'value' => $r['full_name'] ?? ''],
        ['name' => 'id_number', 'label' => 'National ID / Passport No', 'required' => true, 'value' => $r['id_number'] ?? ''],
        ['name' => 'phone', 'label' => 'Phone Number', 'value' => $r['phone'] ?? '+254 7'],
        ['name' => 'organization', 'label' => 'Organization / Affiliation', 'value' => $r['organization'] ?? ''],
        ['name' => 'host_officer', 'label' => 'Host Officer / Principal Secretary', 'required' => true, 'value' => $r['host_officer'] ?? 'Principal Secretary'],
        ['name' => 'office_visited', 'label' => 'Floor / Office Room', 'value' => $r['office_visited'] ?? '7th Floor, Executive Wing'],
        ['name' => 'badge_no', 'label' => 'Visitor Badge Number', 'value' => $r['badge_no'] ?? ('VIS-' . rand(100, 999))],
        ['name' => 'status', 'label' => 'Status', 'type' => 'select', 'value' => $r['status'] ?? 'Checked In', 'options' => [
            'Checked In' => 'Checked In',
            'Checked Out' => 'Checked Out',
            'Expected' => 'Expected'
        ]],
        ['name' => 'purpose', 'label' => 'Purpose of Visit', 'type' => 'textarea', 'value' => $r['purpose'] ?? '', 'full' => true],
    ], 'Save Visitor Record', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($visitors, $search, $statusFilter, $canEdit) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-id-card-clip text-primary"></i> Visitor Management
        </h4>
        <?php if ($canEdit): ?>
            <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Register New Visitor', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(visitor_form(), ENT_QUOTES, 'UTF-8') ?>">
                <i class="fa-solid fa-plus me-1"></i> Check-in Visitor
            </button>
        <?php endif; ?>
    </div>

    <!-- Filter Bar -->
    <div class="card border-0 shadow-sm bg-white p-3 mb-3">
        <form method="GET" action="<?= BASE_URL ?>modules/visitors.php" class="row g-2 align-items-center">
            <div class="col-12 col-md-6">
                <input type="text" name="search" value="<?= e($search) ?>" class="form-control form-control-sm" placeholder="Search by name, ID number, badge, or organization...">
            </div>
            <div class="col-6 col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">-- All Statuses --</option>
                    <option value="Checked In" <?= ($statusFilter === 'Checked In') ? 'selected' : '' ?>>Checked In</option>
                    <option value="Checked Out" <?= ($statusFilter === 'Checked Out') ? 'selected' : '' ?>>Checked Out</option>
                    <option value="Expected" <?= ($statusFilter === 'Expected') ? 'selected' : '' ?>>Expected</option>
                </select>
            </div>
            <div class="col-6 col-md-3">
                <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold"><i class="fa-solid fa-filter me-1"></i> Filter</button>
            </div>
        </form>
    </div>

    <!-- Visitors Table -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small">
            <i class="fa-solid fa-users me-2"></i> Visitors Registry
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th>Badge</th>
                            <th>Visitor Name &amp; ID</th>
                            <th>Organization</th>
                            <th>Host Officer / Office</th>
                            <th>Check-in Time</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($visitors)): ?>
                            <tr><td colspan="7" class="text-center py-4 text-muted">No visitor records found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($visitors as $v): ?>
                                <tr>
                                    <td class="font-monospace fw-bold text-primary"><?= e($v['badge_no']) ?></td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= e($v['full_name']) ?></div>
                                        <div class="small text-muted font-monospace">ID: <?= e($v['id_number']) ?> &bull; <?= e($v['phone']) ?></div>
                                    </td>
                                    <td><?= e($v['organization'] ?: 'Individual / Citizen') ?></td>
                                    <td>
                                        <div class="fw-semibold"><?= e($v['host_officer']) ?></div>
                                        <div class="small text-muted"><?= e($v['office_visited']) ?></div>
                                    </td>
                                    <td>
                                        <div><?= date('d M Y, H:i', strtotime($v['check_in_time'])) ?></div>
                                        <?php if (!empty($v['check_out_time'])): ?>
                                            <div class="small text-success">Out: <?= date('H:i', strtotime($v['check_out_time'])) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= badge_cell($v['status']) ?></td>
                                    <td class="text-end text-nowrap">
                                        <?php if ($canEdit && $v['status'] === 'Checked In'): ?>
                                            <button type="button" class="btn btn-sm btn-outline-warning py-0 px-2 me-1" title="Check Out" onclick="if(confirm('Check out visitor <?= e($v['full_name']) ?>?')){ const fd=new FormData(); fd.append('action','checkout'); fd.append('id','<?= (int)$v['id'] ?>'); fd.append('csrf_token', window.PPSDOMS.csrf()); fetch('<?= BASE_URL ?>modules/visitors.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>location.reload()); }">
                                                <i class="fa-solid fa-person-walking-arrow-right"></i> Out
                                            </button>
                                        <?php endif; ?>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit Visitor', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(visitor_form($v), ENT_QUOTES, 'UTF-8') ?>">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <?= delete_btn(BASE_URL . 'modules/visitors.php', (int)$v['id']) ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('Visitor Management', $renderContent, ['active' => 'visitors']);
