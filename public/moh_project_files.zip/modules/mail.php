<?php
/**
 * Module 10: Mail Management & Correspondence
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $refNo = trim($input['reference_no'] ?? '');
        $type = $input['mail_type'] ?? 'Inward';
        $sender = trim($input['sender_origin'] ?? '');
        $recipient = trim($input['recipient_destination'] ?? '');
        $subject = trim($input['subject'] ?? '');
        $date = $input['letter_date'] ?? date('Y-m-d');
        $urgency = $input['urgency'] ?? 'Routine';
        $status = $input['status'] ?? 'Received';
        $doc = trim($input['document_attachment'] ?? 'official_letter.pdf');
        $notes = trim($input['action_taken'] ?? '');

        if ($refNo === '') $refNo = 'MOH/ADM/' . date('Y') . '/' . rand(100, 999);
        if ($subject === '') json_response(['error' => 'Subject is required.'], 422);

        if ($id > 0) {
            $stmt = $db->prepare("UPDATE mail SET reference_no=?, mail_type=?, sender_origin=?, recipient_destination=?, subject=?, letter_date=?, urgency=?, status=?, document_attachment=?, action_taken=? WHERE id=?");
            $stmt->execute([$refNo, $type, $sender, $recipient, $subject, $date, $urgency, $status, $doc, $notes, $id]);
            log_activity('update', $user['id'], "Updated mail: {$refNo}", $id, 'mail');
        } else {
            $stmt = $db->prepare("INSERT INTO mail (reference_no, mail_type, sender_origin, recipient_destination, subject, letter_date, urgency, status, document_attachment, action_taken, received_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$refNo, $type, $sender, $recipient, $subject, $date, $urgency, $status, $doc, $notes, $user['id']]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Registered mail: {$refNo}", $id, 'mail');
        }
        json_response(['success' => true, 'message' => 'Correspondence record saved.']);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM mail WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted mail record ID: {$id}", $id, 'mail');
        json_response(['success' => true, 'message' => 'Mail record deleted.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Filter
$filterType = $_GET['type'] ?? '';
$search = trim($_GET['search'] ?? '');

$sql = "SELECT * FROM mail WHERE 1=1";
$params = [];

if ($filterType !== '') {
    $sql .= " AND mail_type = ?";
    $params[] = $filterType;
}

if ($search !== '') {
    $sql .= " AND (reference_no LIKE ? OR subject LIKE ? OR sender_origin LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY id DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$mails = $stmt->fetchAll();

function mail_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'reference_no', 'label' => 'Letter / Folio Reference Number', 'value' => $r['reference_no'] ?? ('MOH/ADM/' . date('Y') . '/' . rand(100, 999))],
        ['name' => 'mail_type', 'label' => 'Direction', 'type' => 'select', 'value' => $r['mail_type'] ?? 'Inward', 'options' => [
            'Inward' => 'Inward (Incoming Correspondence)',
            'Outward' => 'Outward (Outgoing Dispatch)'
        ]],
        ['name' => 'letter_date', 'label' => 'Letter / Dispatch Date', 'type' => 'date', 'value' => $r['letter_date'] ?? date('Y-m-d')],
        ['name' => 'urgency', 'label' => 'Urgency / Classification', 'type' => 'select', 'value' => $r['urgency'] ?? 'Routine', 'options' => [
            'Routine' => 'Routine',
            'Urgent' => 'Urgent',
            'Confidential' => 'Confidential',
            'Secret' => 'Secret'
        ]],
        ['name' => 'sender_origin', 'label' => 'Sender / Originating Institution', 'required' => true, 'value' => $r['sender_origin'] ?? ''],
        ['name' => 'recipient_destination', 'label' => 'Recipient / Action Officer', 'required' => true, 'value' => $r['recipient_destination'] ?? 'Principal Secretary, Medical Services'],
        ['name' => 'status', 'label' => 'Processing Status', 'type' => 'select', 'value' => $r['status'] ?? 'Received', 'options' => [
            'Received' => 'Received',
            'Forwarded' => 'Forwarded',
            'Actioned' => 'Actioned',
            'Dispatched' => 'Dispatched',
            'Archived' => 'Archived'
        ]],
        ['name' => 'document_attachment', 'label' => 'Scanned Document / Folio Attachment', 'value' => $r['document_attachment'] ?? 'official_letter_memo.pdf'],
        ['name' => 'subject', 'label' => 'Subject Matter', 'type' => 'textarea', 'required' => true, 'value' => $r['subject'] ?? '', 'full' => true],
        ['name' => 'action_taken', 'label' => 'Minute / Action Taken Notes', 'type' => 'textarea', 'value' => $r['action_taken'] ?? '', 'full' => true],
    ], 'Save Mail Record', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($mails, $filterType, $search, $canEdit) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-envelope-open-text text-primary"></i> Mail Management &amp; Registry
        </h4>
        <?php if ($canEdit): ?>
            <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Register Inward/Outward Mail', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(mail_form(), ENT_QUOTES, 'UTF-8') ?>">
                <i class="fa-solid fa-plus me-1"></i> Register Mail
            </button>
        <?php endif; ?>
    </div>

    <!-- Filter Bar -->
    <div class="card border-0 shadow-sm bg-white p-3 mb-3">
        <form method="GET" action="<?= BASE_URL ?>modules/mail.php" class="row g-2 align-items-center">
            <div class="col-12 col-md-6">
                <input type="text" name="search" value="<?= e($search) ?>" class="form-control form-control-sm" placeholder="Search reference number, sender, or subject...">
            </div>
            <div class="col-6 col-md-3">
                <select name="type" class="form-select form-select-sm">
                    <option value="">-- Inward &amp; Outward --</option>
                    <option value="Inward" <?= ($filterType === 'Inward') ? 'selected' : '' ?>>Inward Mail</option>
                    <option value="Outward" <?= ($filterType === 'Outward') ? 'selected' : '' ?>>Outward Mail</option>
                </select>
            </div>
            <div class="col-6 col-md-3">
                <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold"><i class="fa-solid fa-filter me-1"></i> Filter</button>
            </div>
        </form>
    </div>

    <!-- Mail Registry Table -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small">
            <i class="fa-solid fa-envelopes-bulk me-2"></i> Registry Folio Records
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th>Ref No</th>
                            <th>Direction</th>
                            <th>Sender &amp; Recipient</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($mails)): ?>
                            <tr><td colspan="7" class="text-center py-4 text-muted">No correspondence records found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($mails as $m): ?>
                                <tr>
                                    <td class="font-monospace fw-bold text-primary"><?= e($m['reference_no']) ?></td>
                                    <td>
                                        <span class="badge <?= ($m['mail_type'] === 'Inward') ? 'bg-info text-dark' : 'bg-primary text-white' ?>">
                                            <?= e($m['mail_type']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark">From: <?= e($m['sender_origin']) ?></div>
                                        <div class="small text-muted">To: <?= e($m['recipient_destination']) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-truncate" style="max-width: 280px;"><?= e($m['subject']) ?></div>
                                        <?php if (!empty($m['action_taken'])): ?>
                                            <div class="small text-success text-truncate" style="max-width: 280px;"><i class="fa-solid fa-comment-dots me-1"></i> <?= e($m['action_taken']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= format_date($m['letter_date']) ?></td>
                                    <td><?= badge_cell($m['status']) ?></td>
                                    <td class="text-end text-nowrap">
                                        <?php if (!empty($m['document_attachment'])): ?>
                                            <button type="button" class="btn btn-sm btn-outline-info py-0 px-2 me-1" title="View Document" onclick="alert('Viewing attached mail correspondence: <?= e($m['document_attachment']) ?>')"><i class="fa-solid fa-paperclip"></i></button>
                                        <?php endif; ?>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit Mail Record', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(mail_form($m), ENT_QUOTES, 'UTF-8') ?>">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <?= delete_btn(BASE_URL . 'modules/mail.php', (int)$m['id']) ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('Mail Management', $renderContent, ['active' => 'mail']);
