<?php
/**
 * Module 11: Users & RBAC Administration
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();
require_permission('is_admin');

$db = db();
$user = current_user();

// Handle POST
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        $id = (int)($input['id'] ?? 0);
        $name = trim($input['full_name'] ?? '');
        $email = trim($input['email'] ?? '');
        $phone = trim($input['phone'] ?? '');
        $directorate = trim($input['directorate'] ?? '');
        $roleId = (int)($input['role_id'] ?? 3);
        $isActive = isset($input['is_active']) ? 1 : 0;
        $password = trim($input['password'] ?? '');

        if ($name === '' || $email === '') json_response(['error' => 'Name and Email are required.'], 422);

        if ($id > 0) {
            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE users SET full_name=?, email=?, phone=?, directorate=?, role_id=?, is_active=?, password_hash=?, failed_login_attempts=0 WHERE id=?");
                $stmt->execute([$name, $email, $phone, $directorate, $roleId, $isActive, $hash, $id]);
            } else {
                $stmt = $db->prepare("UPDATE users SET full_name=?, email=?, phone=?, directorate=?, role_id=?, is_active=? WHERE id=?");
                $stmt->execute([$name, $email, $phone, $directorate, $roleId, $isActive, $id]);
            }
            log_activity('update', $user['id'], "Updated user account: {$email}", $id, 'users');
        } else {
            $passToUse = $password !== '' ? $password : 'ChangeMe@2026';
            $hash = password_hash($passToUse, PASSWORD_BCRYPT);
            $stmt = $db->prepare("INSERT INTO users (full_name, email, phone, directorate, role_id, is_active, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $phone, $directorate, $roleId, $isActive, $hash]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Created user account: {$email}", $id, 'users');
        }
        json_response(['success' => true, 'message' => 'User account saved.']);
    }

    if ($action === 'delete') {
        $id = (int)($input['id'] ?? 0);
        if ($id === (int)$user['id']) json_response(['error' => 'Cannot delete your own account.'], 422);
        $db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted user ID: {$id}", $id, 'users');
        json_response(['success' => true, 'message' => 'User deleted.']);
    }

    if ($action === 'unlock') {
        $id = (int)($input['id'] ?? 0);
        $db->prepare("UPDATE users SET failed_login_attempts = 0 WHERE id = ?")->execute([$id]);
        log_activity('unlock', $user['id'], "Unlocked user ID: {$id}", $id, 'users');
        json_response(['success' => true, 'message' => 'Account unlocked.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Fetch users with roles
$users = $db->query("SELECT u.*, r.name as role_name, r.can_upload, r.can_edit, r.can_approve_tasks, r.can_download, r.is_admin FROM users u LEFT JOIN roles r ON u.role_id = r.id ORDER BY u.id ASC")->fetchAll();
$roles = $db->query("SELECT id, name FROM roles ORDER BY id ASC")->fetchAll();

$roleOptions = [];
foreach ($roles as $ro) $roleOptions[$ro['id']] = $ro['name'];

function user_form(?array $r = null, array $roleOptions = []): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'full_name', 'label' => 'Full Official Name', 'required' => true, 'value' => $r['full_name'] ?? ''],
        ['name' => 'email', 'label' => 'Government Email Address', 'type' => 'email', 'required' => true, 'value' => $r['email'] ?? ''],
        ['name' => 'phone', 'label' => 'Phone Number', 'value' => $r['phone'] ?? '+254 7'],
        ['name' => 'directorate', 'label' => 'Directorate / Department', 'value' => $r['directorate'] ?? 'State Department for Medical Services'],
        ['name' => 'role_id', 'label' => 'Assigned Role', 'type' => 'select', 'value' => $r['role_id'] ?? 3, 'options' => $roleOptions],
        ['name' => 'password', 'label' => 'Password (Leave blank to keep current)', 'type' => 'password', 'value' => ''],
    ], 'Save User Account', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($users, $roleOptions, $user) {
?>
<div class="container-fluid px-0">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-users-gear text-primary"></i> User Management &amp; Access Control
            </h4>
            <span class="small text-muted">Role-Based Access Control (RBAC) &amp; Security Auditing</span>
        </div>
        <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Add New User', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(user_form(null, $roleOptions), ENT_QUOTES, 'UTF-8') ?>">
            <i class="fa-solid fa-user-plus me-1"></i> Add User
        </button>
    </div>

    <!-- Users Table -->
    <div class="card border-0 shadow-sm bg-white">
        <div class="card-header bg-primary text-white py-2 px-3 fw-bold small">
            <i class="fa-solid fa-user-shield me-2"></i> Authorized System Users
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th>User Name &amp; Email</th>
                            <th>Role</th>
                            <th>Permissions Matrix</th>
                            <th>Directorate</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?= e($u['full_name']) ?></div>
                                    <div class="small text-muted font-monospace"><?= e($u['email']) ?></div>
                                </td>
                                <td><span class="badge bg-primary text-uppercase"><?= e($u['role_name']) ?></span></td>
                                <td>
                                    <div class="d-flex gap-1 flex-wrap">
                                        <?php if ($u['is_admin']): ?><span class="badge bg-danger" title="Admin">Admin</span><?php endif; ?>
                                        <?php if ($u['can_upload']): ?><span class="badge bg-light text-dark border" title="Can Upload">Upload</span><?php endif; ?>
                                        <?php if ($u['can_edit']): ?><span class="badge bg-light text-dark border" title="Can Edit">Edit</span><?php endif; ?>
                                        <?php if ($u['can_approve_tasks']): ?><span class="badge bg-success" title="Approve Tasks">Approve</span><?php endif; ?>
                                        <?php if ($u['can_download']): ?><span class="badge bg-light text-dark border" title="Download">Download</span><?php endif; ?>
                                    </div>
                                </td>
                                <td><?= e($u['directorate']) ?></td>
                                <td>
                                    <?php if ($u['is_active']): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                    <?php if ($u['failed_login_attempts'] >= 5): ?>
                                        <span class="badge bg-danger ms-1">Locked</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $u['last_login'] ? date('d M Y, H:i', strtotime($u['last_login'])) : 'Never' ?></td>
                                <td class="text-end text-nowrap">
                                    <?php if ($u['failed_login_attempts'] >= 5): ?>
                                        <button type="button" class="btn btn-sm btn-outline-warning me-1" title="Unlock Account" onclick="const fd=new FormData(); fd.append('action','unlock'); fd.append('id','<?= (int)$u['id'] ?>'); fd.append('csrf_token', window.PPSDOMS.csrf()); fetch('<?= BASE_URL ?>modules/users.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>location.reload());"><i class="fa-solid fa-lock-open"></i></button>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit User', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(user_form($u, $roleOptions), ENT_QUOTES, 'UTF-8') ?>">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>
                                    <?php if ((int)$u['id'] !== (int)$user['id']): ?>
                                        <?= delete_btn(BASE_URL . 'modules/users.php', (int)$u['id']) ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('User Management', $renderContent, ['active' => 'users']);
