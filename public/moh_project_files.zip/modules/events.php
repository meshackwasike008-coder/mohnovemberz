<?php
/**
 * Module 3: Upcoming Key Activities & Events
 * Matching Screenshot page 3
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied: Edit capability required.'], 403);
        $id = (int)($input['id'] ?? 0);
        $title = trim($input['title'] ?? '');
        $desc = trim($input['description'] ?? '');
        $type = !empty($input['event_type']) ? trim((string)$input['event_type']) : 'Meeting';
        $date = !empty($input['event_date']) ? trim((string)$input['event_date']) : date('Y-m-d');
        $rawTime = !empty($input['event_time']) ? trim((string)$input['event_time']) : '09:00:00';
        $time = strlen($rawTime) === 5 ? ($rawTime . ':00') : $rawTime;
        $location = trim($input['location'] ?? 'Afya House, Nairobi');
        $host = trim($input['host'] ?? 'Principal Secretary');
        $attendees = trim($input['attendees'] ?? '');
        $status = !empty($input['status']) ? trim((string)$input['status']) : 'Upcoming';

        if ($title === '') json_response(['error' => 'Event title is required.'], 422);

        try {
            if ($id > 0) {
                $stmt = $db->prepare("UPDATE events SET title=?, description=?, event_type=?, event_date=?, event_time=?, location=?, host=?, attendees=?, status=? WHERE id=?");
                $stmt->execute([$title, $desc, $type, $date, $time, $location, $host, $attendees, $status, $id]);
                log_activity('update', (int)($user['id'] ?? 1), "Updated event: {$title}", $id, 'events');
            } else {
                $stmt = $db->prepare("INSERT INTO events (title, description, event_type, event_date, event_time, location, host, attendees, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $desc, $type, $date, $time, $location, $host, $attendees, $status, (int)($user['id'] ?? 1)]);
                $id = (int)$db->lastInsertId();
                log_activity('create', (int)($user['id'] ?? 1), "Created event: {$title}", $id, 'events');
            }
            json_response(['success' => true, 'message' => 'Event saved successfully.']);
        } catch (Throwable $e) {
            error_log('Event save error: ' . $e->getMessage());
            json_response(['error' => 'Database error saving event: ' . $e->getMessage()], 500);
        }
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        try {
            $db->prepare("DELETE FROM events WHERE id=?")->execute([$id]);
            log_activity('delete', (int)($user['id'] ?? 1), "Deleted event ID: {$id}", $id, 'events');
            json_response(['success' => true, 'message' => 'Event deleted.']);
        } catch (Throwable $e) {
            json_response(['error' => 'Error deleting event: ' . $e->getMessage()], 500);
        }
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Month & Year filter
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

$events = $db->query("SELECT * FROM events ORDER BY event_date ASC, event_time ASC")->fetchAll();

function event_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'title', 'label' => 'Event / Activity Title', 'required' => true, 'value' => $r['title'] ?? '', 'full' => true],
        ['name' => 'event_type', 'label' => 'Event Type', 'type' => 'select', 'value' => $r['event_type'] ?? 'Meeting', 'options' => [
            'Field Visit' => 'Field Visit',
            'Ministerial Event' => 'Ministerial Event',
            'Executive Inspection' => 'Executive Inspection',
            'Meeting' => 'Meeting',
            'Training' => 'Training',
            'Other' => 'Other'
        ]],
        ['name' => 'status', 'label' => 'Status', 'type' => 'select', 'value' => $r['status'] ?? 'Upcoming', 'options' => [
            'Upcoming' => 'Upcoming',
            'Ongoing' => 'Ongoing',
            'Completed' => 'Completed',
            'Cancelled' => 'Cancelled'
        ]],
        ['name' => 'event_date', 'label' => 'Date', 'type' => 'date', 'value' => $r['event_date'] ?? date('Y-m-d')],
        ['name' => 'event_time', 'label' => 'Time', 'type' => 'time', 'value' => $r['event_time'] ?? '09:00'],
        ['name' => 'location', 'label' => 'Location / Venue', 'value' => $r['location'] ?? 'Afya House, Nairobi', 'full' => true],
        ['name' => 'host', 'label' => 'Host / Chair', 'value' => $r['host'] ?? 'Principal Secretary'],
        ['name' => 'attendees', 'label' => 'Key Attendees / Delegation', 'value' => $r['attendees'] ?? ''],
        ['name' => 'description', 'label' => 'Description & Key Objectives', 'type' => 'textarea', 'value' => $r['description'] ?? '', 'full' => true],
    ], 'Save Event / Activity', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($events, $selectedMonth, $selectedYear, $canEdit) {
    $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];
?>
<div class="container-fluid px-0">
    <!-- Header Controls (Matching screenshot page 3) -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-0 text-primary d-flex align-items-center gap-2">
                <i class="fa-solid fa-calendar-days text-primary"></i> Activities &amp; Events
            </h4>
            <span class="small text-muted">Schedule for <strong><?= $months[$selectedMonth] ?? 'Current Month' ?> <?= $selectedYear ?></strong></span>
        </div>

        <div class="d-flex flex-wrap align-items-center gap-2">
            <form method="GET" class="d-flex align-items-center gap-2">
                <select name="month" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($months as $num => $mName): ?>
                        <option value="<?= $num ?>" <?= ($selectedMonth === $num) ? 'selected' : '' ?>><?= $mName ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php for ($y = 2024; $y <= 2028; $y++): ?>
                        <option value="<?= $y ?>" <?= ($selectedYear === $y) ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </form>

            <?php if ($canEdit): ?>
                <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Add New Activity / Event', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(event_form(), ENT_QUOTES, 'UTF-8') ?>">
                    <i class="fa-solid fa-plus me-1"></i> Add New
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- UPCOMING EVENTS (TOP 5) -->
    <div class="card border-0 shadow-sm bg-white mb-4">
        <div class="card-header bg-light py-2 px-3 d-flex justify-content-between align-items-center border-bottom">
            <span class="fw-bold small text-uppercase text-secondary">
                <i class="fa-solid fa-star text-warning me-1"></i> Upcoming Events (Top 5)
            </span>
            <span class="badge bg-primary rounded-pill"><?= count($events) ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                    <thead class="table-light">
                        <tr>
                            <th>Date &amp; Time</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Location</th>
                            <th>Host / Chair</th>
                            <th>Status</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($events)): ?>
                            <tr><td colspan="7" class="text-center py-3 text-muted">No events scheduled for this month.</td></tr>
                        <?php else: ?>
                            <?php foreach ($events as $ev): 
                                $rowBg = match($ev['status']) {
                                    'Completed' => 'table-light',
                                    'Cancelled' => 'table-danger',
                                    default => ''
                                };
                            ?>
                                <tr class="<?= $rowBg ?>">
                                    <td>
                                        <div class="fw-bold"><?= format_date($ev['event_date']) ?></div>
                                        <div class="small text-muted"><i class="fa-regular fa-clock me-1"></i> <?= substr((string)$ev['event_time'], 0, 5) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-primary"><?= e($ev['title']) ?></div>
                                        <div class="small text-muted text-truncate" style="max-width: 250px;"><?= e($ev['description']) ?></div>
                                    </td>
                                    <td><span class="badge bg-light text-dark border"><?= e($ev['event_type']) ?></span></td>
                                    <td><i class="fa-solid fa-location-dot text-danger me-1"></i> <?= e($ev['location']) ?></td>
                                    <td><?= e($ev['host']) ?></td>
                                    <td><?= badge_cell($ev['status']) ?></td>
                                    <td class="text-end text-nowrap">
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit Event', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(event_form($ev), ENT_QUOTES, 'UTF-8') ?>">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <?= delete_btn(BASE_URL . 'modules/events.php', (int)$ev['id']) ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
};

render_page('Activities & Events', $renderContent, ['active' => 'events']);
