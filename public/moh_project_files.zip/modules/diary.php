<?php
/**
 * Module 7: Diary & Project Planner Calendar
 * Matching Screenshot page 5
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied: Edit capability required.'], 403);
        $id = (int)($input['id'] ?? 0);
        $title = trim($input['title'] ?? '');
        $content = trim($input['content'] ?? '');
        $date = !empty($input['entry_date']) ? trim((string)$input['entry_date']) : date('Y-m-d');
        $rawTime = !empty($input['entry_time']) ? trim((string)$input['entry_time']) : '09:00:00';
        $time = strlen($rawTime) === 5 ? ($rawTime . ':00') : $rawTime;
        $cat = !empty($input['category']) ? trim((string)$input['category']) : 'General';
        $pri = !empty($input['priority']) ? trim((string)$input['priority']) : 'Medium';

        if ($title === '') json_response(['error' => 'Entry title is required.'], 422);

        try {
            if ($id > 0) {
                $stmt = $db->prepare("UPDATE diary SET title=?, content=?, entry_date=?, entry_time=?, category=?, priority=? WHERE id=?");
                $stmt->execute([$title, $content, $date, $time, $cat, $pri, $id]);
                log_activity('update', (int)($user['id'] ?? 1), "Updated diary entry: {$title}", $id, 'diary');
            } else {
                $stmt = $db->prepare("INSERT INTO diary (title, content, entry_date, entry_time, category, priority, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $content, $date, $time, $cat, $pri, (int)($user['id'] ?? 1)]);
                $id = (int)$db->lastInsertId();
                log_activity('create', (int)($user['id'] ?? 1), "Created diary entry: {$title}", $id, 'diary');
            }
            json_response(['success' => true, 'message' => 'Diary entry saved successfully.']);
        } catch (Throwable $e) {
            error_log('Diary save error: ' . $e->getMessage());
            json_response(['error' => 'Database error saving diary entry: ' . $e->getMessage()], 500);
        }
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        try {
            $db->prepare("DELETE FROM diary WHERE id=?")->execute([$id]);
            log_activity('delete', (int)($user['id'] ?? 1), "Deleted diary entry ID: {$id}", $id, 'diary');
            json_response(['success' => true, 'message' => 'Diary entry deleted.']);
        } catch (Throwable $e) {
            json_response(['error' => 'Error deleting diary entry: ' . $e->getMessage()], 500);
        }
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Current Year & Month from query or default
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');

$prevMonth = ($month === 1) ? 12 : $month - 1;
$prevYear = ($month === 1) ? $year - 1 : $year;
$nextMonth = ($month === 12) ? 1 : $month + 1;
$nextYear = ($month === 12) ? $year + 1 : $year;

// Load diary entries for this month
$startDate = sprintf('%04d-%02d-01', $year, $month);
$endDate = date('Y-m-t', strtotime($startDate));

$dStmt = $db->prepare("SELECT * FROM diary WHERE entry_date BETWEEN ? AND ?");
$dStmt->execute([$startDate, $endDate]);
$diaryEntries = $dStmt->fetchAll();

// Also load events and meetings for rich diary integration
$eStmt = $db->prepare("SELECT id, title, description, event_date as entry_date, event_time as entry_time, 'Event' as category, 'Medium' as priority FROM events WHERE event_date BETWEEN ? AND ?");
$eStmt->execute([$startDate, $endDate]);
$calendarEvents = $eStmt->fetchAll();

$mStmt = $db->prepare("SELECT id, title, description as content, date as entry_date, '10:00:00' as entry_time, 'Meeting' as category, 'High' as priority FROM meetings WHERE date BETWEEN ? AND ?");
$mStmt->execute([$startDate, $endDate]);
$calendarMeetings = $mStmt->fetchAll();

// Group all items by date
$itemsByDay = [];
foreach (array_merge($diaryEntries, $calendarEvents, $calendarMeetings) as $item) {
    $d = (int)date('j', strtotime($item['entry_date']));
    $itemsByDay[$d][] = $item;
}

function diary_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'title', 'label' => 'Entry Title', 'required' => true, 'value' => $r['title'] ?? '', 'full' => true],
        ['name' => 'entry_date', 'label' => 'Date', 'type' => 'date', 'value' => $r['entry_date'] ?? date('Y-m-d')],
        ['name' => 'entry_time', 'label' => 'Time', 'type' => 'time', 'value' => $r['entry_time'] ?? '09:00'],
        ['name' => 'category', 'label' => 'Category', 'type' => 'select', 'value' => $r['category'] ?? 'General', 'options' => [
            'Meeting' => 'Meeting',
            'Task' => 'Task',
            'Deadline' => 'Deadline',
            'Event' => 'Event',
            'General' => 'General'
        ]],
        ['name' => 'priority', 'label' => 'Priority', 'type' => 'select', 'value' => $r['priority'] ?? 'Medium', 'options' => [
            'Low' => 'Low',
            'Medium' => 'Medium',
            'High' => 'High',
            'Critical' => 'Critical'
        ]],
        ['name' => 'content', 'label' => 'Details & Notes', 'type' => 'textarea', 'value' => $r['content'] ?? '', 'full' => true],
    ], 'Save Diary Entry', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($year, $month, $prevMonth, $prevYear, $nextMonth, $nextYear, $itemsByDay, $canEdit) {
    $monthName = date('F', mktime(0, 0, 0, $month, 10));
    $daysInMonth = (int)date('t', strtotime("$year-$month-01"));
    $firstDayOfWeek = (int)date('w', strtotime("$year-$month-01")); // 0 = Sunday
?>
<div class="container-fluid px-0">
    <!-- Header with Planner controls matching screenshot page 5 -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-calendar-alt text-primary"></i> Project Planner
        </h4>

        <div class="d-flex align-items-center gap-2">
            <div class="btn-group shadow-sm">
                <a href="<?= BASE_URL ?>modules/diary.php?year=<?= $prevYear ?>&month=<?= $prevMonth ?>" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-chevron-left"></i></a>
                <span class="btn btn-primary btn-sm fw-bold px-4" style="background-color: #0d6efd; border-color: #0d6efd;">
                    <?= $monthName ?> <?= $year ?>
                </span>
                <a href="<?= BASE_URL ?>modules/diary.php?year=<?= $nextYear ?>&month=<?= $nextMonth ?>" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-chevron-right"></i></a>
            </div>

            <?php if ($canEdit): ?>
                <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('New Diary / Planner Entry', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(diary_form(), ENT_QUOTES, 'UTF-8') ?>">
                    <i class="fa-solid fa-plus me-1"></i> Add Entry
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Interactive Calendar Grid (Matching screenshot page 5) -->
    <div class="card border-0 shadow-sm bg-white overflow-hidden mb-4">
        <div class="table-responsive mb-0">
            <table class="table table-bordered mb-0" style="table-layout: fixed;">
                <thead style="background-color: #0d47a1; color: #ffffff;">
                    <tr class="text-center small font-monospace text-uppercase">
                        <th style="width: 14.28%;">Sunday</th>
                        <th style="width: 14.28%;">Monday</th>
                        <th style="width: 14.28%;">Tuesday</th>
                        <th style="width: 14.28%;">Wednesday</th>
                        <th style="width: 14.28%;">Thursday</th>
                        <th style="width: 14.28%;">Friday</th>
                        <th style="width: 14.28%;">Saturday</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $dayCount = 1;
                    $currentWeekDay = 0;
                    echo '<tr style="min-height: 100px;">';

                    // Empty cells before month starts
                    for ($i = 0; $i < $firstDayOfWeek; $i++) {
                        echo '<td class="bg-light" style="height: 110px;"></td>';
                        $currentWeekDay++;
                    }

                    // Days of month
                    while ($dayCount <= $daysInMonth) {
                        if ($currentWeekDay === 7) {
                            echo '</tr><tr style="min-height: 100px;">';
                            $currentWeekDay = 0;
                        }

                        $dayItems = $itemsByDay[$dayCount] ?? [];
                        echo '<td style="height: 110px; vertical-align: top; padding: 6px;" class="position-relative hover-bg-light">';
                        echo '<div class="fw-bold small text-secondary mb-1">' . $dayCount . '</div>';

                        if (!empty($dayItems)) {
                            foreach ($dayItems as $item) {
                                $cat = $item['category'] ?? 'General';
                                $bg = match($cat) {
                                    'Meeting' => 'bg-primary text-white',
                                    'Task' => 'bg-info text-dark',
                                    'Deadline' => 'bg-danger text-white',
                                    'Event' => 'bg-warning text-dark',
                                    default => 'bg-secondary text-white'
                                };
                                $timeStr = !empty($item['entry_time']) ? substr((string)$item['entry_time'], 0, 5) . ' ' : '';
                                $priority = $item['priority'] ?? 'Medium';
                                $itemJson = htmlspecialchars(json_encode($item, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8');
                                echo '<div class="badge ' . $bg . ' text-truncate d-block mb-1 text-start diary-event-badge" style="font-size: 0.68rem; cursor: pointer;" title="Click to view details" data-event="' . $itemJson . '" onclick="showDiaryEventDetails(this)">';
                                echo $timeStr . e($item['title']);
                                echo '</div>';
                            }
                        }

                        echo '</td>';
                        $dayCount++;
                        $currentWeekDay++;
                    }

                    // Remaining empty cells
                    while ($currentWeekDay < 7) {
                        echo '<td class="bg-light" style="height: 110px;"></td>';
                        $currentWeekDay++;
                    }
                    echo '</tr>';
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Selected Event Details Panel (Appears below calendar, above priority legends) -->
    <div id="diaryEventDetailsContainer" class="card border-0 shadow-sm bg-white rounded-3 mb-4 d-none border-top border-3 border-primary">
        <div class="card-header bg-light d-flex justify-content-between align-items-center py-2 px-3 border-bottom">
            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-primary px-2.5 py-1 text-uppercase" id="detailCategoryBadge">Meeting</span>
                <span class="badge bg-secondary px-2 py-1" id="detailPriorityBadge">Medium Priority</span>
                <span class="fw-bold text-dark small text-uppercase font-monospace ms-2"><i class="fa-solid fa-circle-info text-primary me-1"></i> Event / Schedule Details</span>
            </div>
            <button type="button" class="btn-close btn-sm" onclick="closeDiaryEventDetails()" title="Close Details"></button>
        </div>
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-12 col-lg-8">
                    <h5 class="fw-bold text-dark mb-2" id="detailTitle">-</h5>
                    <div class="d-flex flex-wrap gap-3 small text-muted mb-3 pb-2 border-bottom">
                        <span><i class="fa-regular fa-calendar text-primary me-1"></i> <strong id="detailDate">-</strong></span>
                        <span><i class="fa-regular fa-clock text-primary me-1"></i> <strong id="detailTime">-</strong></span>
                        <span id="detailLocationWrap" class="d-none"><i class="fa-solid fa-location-dot text-danger me-1"></i> <span id="detailLocation">-</span></span>
                        <span id="detailHostWrap" class="d-none"><i class="fa-solid fa-user-tie text-info me-1"></i> Host: <strong id="detailHost">-</strong></span>
                    </div>

                    <label class="form-label small fw-bold text-secondary text-uppercase mb-1">Description / Notes &amp; Objectives</label>
                    <div class="p-3 bg-light rounded-2 border text-dark small mb-3" style="min-height: 80px; white-space: pre-wrap;" id="detailContent">-</div>

                    <div id="detailAttendeesWrap" class="p-2.5 bg-light-subtle rounded border small text-muted d-none mb-2">
                        <strong class="text-secondary"><i class="fa-solid fa-users me-1"></i> Attendees / Delegation:</strong>
                        <div class="mt-1 text-dark" id="detailAttendees">-</div>
                    </div>
                </div>

                <div class="col-12 col-lg-4 d-flex flex-column justify-content-between border-start-lg ps-lg-4">
                    <div class="card bg-light border-0 p-3 rounded-3 mb-3">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="fa-solid fa-calendar-check text-success fs-5"></i>
                            <strong class="text-dark small">Integrated Operational Planner</strong>
                        </div>
                        <p class="text-muted small mb-0" style="font-size: 0.8rem;">
                            This engagement is registered in the Ministry of Health state department schedule. All updates propagate to executive diaries and review matrices.
                        </p>
                    </div>

                    <div class="d-flex flex-wrap gap-2 justify-content-end align-items-center pt-3 border-top" id="detailActions">
                        <button type="button" class="btn btn-sm btn-outline-secondary px-3" onclick="closeDiaryEventDetails()">Close Panel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Priority Legends (Matching screenshot page 5 bottom) -->
    <div class="d-flex flex-wrap align-items-center gap-2 p-3 bg-white border rounded shadow-sm">
        <span class="text-uppercase fw-bold small text-muted me-2">Priority Legends:</span>
        <span class="badge bg-primary px-3 py-1">Meeting</span>
        <span class="badge bg-info text-dark px-3 py-1">Task</span>
        <span class="badge bg-danger px-3 py-1">Deadline</span>
        <span class="badge bg-warning text-dark px-3 py-1">Event</span>
        <span class="badge bg-secondary px-3 py-1">General</span>
    </div>
</div>

<script>
function showDiaryEventDetails(el) {
    try {
        const raw = el.getAttribute('data-event');
        if (!raw) return;
        const ev = JSON.parse(raw);
        
        const container = document.getElementById('diaryEventDetailsContainer');
        if (!container) return;

        // Set Title
        document.getElementById('detailTitle').textContent = ev.title || 'Untitled Event';
        
        // Category Badge
        const cat = ev.category || 'General';
        const catBadge = document.getElementById('detailCategoryBadge');
        catBadge.textContent = cat;
        catBadge.className = 'badge px-2.5 py-1 text-uppercase ' + (
            cat === 'Meeting' ? 'bg-primary text-white' :
            cat === 'Task' ? 'bg-info text-dark' :
            cat === 'Deadline' ? 'bg-danger text-white' :
            cat === 'Event' ? 'bg-warning text-dark' : 'bg-secondary text-white'
        );

        // Priority Badge
        const pri = ev.priority || 'Medium';
        const priBadge = document.getElementById('detailPriorityBadge');
        priBadge.textContent = pri + ' Priority';
        priBadge.className = 'badge px-2 py-1 ' + (
            pri === 'Critical' ? 'bg-danger' :
            pri === 'High' ? 'bg-warning text-dark' :
            pri === 'Low' ? 'bg-light text-secondary border' : 'bg-secondary text-white'
        );

        // Date & Time
        document.getElementById('detailDate').textContent = ev.entry_date || '-';
        document.getElementById('detailTime').textContent = ev.entry_time ? String(ev.entry_time).substring(0, 5) : '09:00';

        // Content
        document.getElementById('detailContent').textContent = ev.content || ev.description || 'No detailed notes or description provided.';

        // Location (from events / meetings)
        const locWrap = document.getElementById('detailLocationWrap');
        if (ev.location || ev.venue) {
            document.getElementById('detailLocation').textContent = ev.location || ev.venue;
            locWrap.classList.remove('d-none');
        } else {
            locWrap.classList.add('d-none');
        }

        // Host
        const hostWrap = document.getElementById('detailHostWrap');
        if (ev.host) {
            document.getElementById('detailHost').textContent = ev.host;
            hostWrap.classList.remove('d-none');
        } else {
            hostWrap.classList.add('d-none');
        }

        // Attendees
        const attWrap = document.getElementById('detailAttendeesWrap');
        if (ev.attendees) {
            document.getElementById('detailAttendees').textContent = ev.attendees;
            attWrap.classList.remove('d-none');
        } else {
            attWrap.classList.add('d-none');
        }

        // Action Buttons
        const actionsDiv = document.getElementById('detailActions');
        actionsDiv.innerHTML = '<button type="button" class="btn btn-sm btn-outline-secondary px-3" onclick="closeDiaryEventDetails()">Close Panel</button>';
        
        <?php if ($canEdit): ?>
        if (ev.id && !ev.venue && !ev.location) {
            // It is an editable diary record
            const delBtn = document.createElement('button');
            delBtn.type = 'button';
            delBtn.className = 'btn btn-sm btn-outline-danger px-3';
            delBtn.innerHTML = '<i class="fa-solid fa-trash me-1"></i> Delete';
            delBtn.onclick = function() {
                if (confirm('Delete diary entry "' + (ev.title || '') + '"?')) {
                    const fd = new FormData();
                    fd.append('action', 'delete');
                    fd.append('id', ev.id);
                    fd.append('csrf_token', window.PPSDOMS.csrf());
                    fetch(window.location.href, { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(d => { if (d.success) location.reload(); else alert(d.error || 'Failed to delete'); });
                }
            };
            actionsDiv.appendChild(delBtn);
        }
        <?php endif; ?>

        // Show card and smooth scroll
        container.classList.remove('d-none');
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (e) {
        console.error('Error rendering diary event details:', e);
    }
}

function closeDiaryEventDetails() {
    const c = document.getElementById('diaryEventDetailsContainer');
    if (c) c.classList.add('d-none');
}
</script>
<?php
};

render_page('Diary & Project Planner', $renderContent, ['active' => 'diary']);
