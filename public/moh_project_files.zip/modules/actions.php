<?php
/**
 * Module 4: Action Points Tracker
 * Matching Screenshot page 1 and page 2
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;
$canApprove = $user['role']['can_approve_tasks'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $refNo = trim($input['ref_no'] ?? '');
        $date = $input['date'] ?? date('Y-m-d');
        $meeting = trim($input['meeting_title'] ?? '');
        $issue = trim($input['issue'] ?? '');
        $responsible = trim($input['person_responsible'] ?? '');
        $timeline = trim($input['timeline'] ?? '');
        $status = $input['status'] ?? 'NOT STARTED';
        $actionNotes = trim($input['action_notes'] ?? '');
        $resolution = trim($input['resolution_notes'] ?? '');

        if ($refNo === '') {
            $refNo = 'APT-' . date('Ymd') . '-' . rand(100, 999);
        }

        if ($issue === '') json_response(['error' => 'Issue description is required.'], 422);

        if ($id > 0) {
            $stmt = $db->prepare("UPDATE action_points SET ref_no=?, date=?, meeting_title=?, issue=?, person_responsible=?, timeline=?, status=?, action=?, resolution_notes=? WHERE id=?");
            $stmt->execute([$refNo, $date, $meeting, $issue, $responsible, $timeline, $status, $actionNotes, $resolution, $id]);
            log_activity('update', $user['id'], "Updated Action Point {$refNo}", $id, 'actions');
        } else {
            $stmt = $db->prepare("INSERT INTO action_points (ref_no, date, meeting_title, issue, person_responsible, timeline, status, action, resolution_notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$refNo, $date, $meeting, $issue, $responsible, $timeline, $status, $actionNotes, $resolution, $user['id']]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Created Action Point {$refNo}", $id, 'actions');
        }
        json_response(['success' => true, 'message' => 'Action point saved successfully.']);
    }

    if ($action === 'resolve') {
        if (!$canApprove) json_response(['error' => 'Permission denied: Requires task approval role.'], 403);
        $id = (int)($input['id'] ?? 0);
        $stmt = $db->prepare("UPDATE action_points SET status='COMPLETED', approved_by=?, approved_at=NOW() WHERE id=?");
        $stmt->execute([$user['id'], $id]);
        log_activity('approve', $user['id'], "Approved & Completed Action Point #{$id}", $id, 'actions');
        json_response(['success' => true, 'message' => 'Action point marked as COMPLETED.']);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM action_points WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted Action Point ID: {$id}", $id, 'actions');
        json_response(['success' => true, 'message' => 'Action point deleted.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Single Action Point Detail View check
$viewId = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$detailAction = null;
if ($viewId > 0) {
    $stmt = $db->prepare("SELECT * FROM action_points WHERE id = ?");
    $stmt->execute([$viewId]);
    $detailAction = $stmt->fetch();
}

// Fetch all action points
$actions = $db->query("SELECT * FROM action_points ORDER BY date DESC, id DESC")->fetchAll();

function action_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'ref_no', 'label' => 'Reference Number', 'value' => $r['ref_no'] ?? ('APT-' . date('Ymd') . '-' . rand(100, 999))],
        ['name' => 'date', 'label' => 'Date Raised', 'type' => 'date', 'value' => $r['date'] ?? date('Y-m-d')],
        ['name' => 'meeting_title', 'label' => 'Meeting / Event Title', 'required' => true, 'value' => $r['meeting_title'] ?? ''],
        ['name' => 'person_responsible', 'label' => 'Person Responsible', 'required' => true, 'value' => $r['person_responsible'] ?? ''],
        ['name' => 'timeline', 'label' => 'Timeline / Deadline', 'required' => true, 'value' => $r['timeline'] ?? '2 weeks'],
        ['name' => 'status', 'label' => 'Status', 'type' => 'select', 'value' => $r['status'] ?? 'NOT STARTED', 'options' => [
            'NOT STARTED' => 'NOT STARTED',
            'ON TRACK' => 'ON TRACK',
            'DELAYED' => 'DELAYED',
            'STALLED' => 'STALLED',
            'COMPLETED' => 'COMPLETED',
            'CANCELLED' => 'CANCELLED',
        ]],
        ['name' => 'issue', 'label' => 'The Issue / Background', 'type' => 'textarea', 'required' => true, 'value' => $r['issue'] ?? '', 'full' => true],
        ['name' => 'action_notes', 'label' => 'Action / Progress Made', 'type' => 'textarea', 'value' => $r['action'] ?? '', 'full' => true],
        ['name' => 'resolution_notes', 'label' => 'Resolution & Verification Notes', 'type' => 'textarea', 'value' => $r['resolution_notes'] ?? '', 'full' => true],
    ], 'Save Action Point', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($actions, $detailAction, $canEdit, $canApprove) {
    if ($detailAction):
        // Single Action Point Detail Page (Matching Screenshot page 1)
    ?>
        <div class="mb-3">
            <a href="<?= BASE_URL ?>modules/actions.php" class="btn btn-sm btn-outline-secondary">
                <i class="fa-solid fa-arrow-left me-1"></i> Back to Tracker
            </a>
        </div>

        <div class="card border-0 shadow-sm bg-white p-4 mb-4">
            <div class="d-flex justify-content-between align-items-start border-bottom pb-3 mb-4">
                <div>
                    <h4 class="fw-bold mb-1 text-primary">Action Point: <?= e($detailAction['ref_no']) ?></h4>
                    <div class="text-muted small">Meeting: <strong><?= e($detailAction['meeting_title']) ?></strong></div>
                </div>
                <div class="d-flex gap-2">
                    <?php if ($canApprove && $detailAction['status'] !== 'COMPLETED'): ?>
                        <button type="button" class="btn btn-sm btn-success fw-bold" onclick="if(confirm('Approve and mark this Action Point as COMPLETED?')){ const fd = new FormData(); fd.append('action', 'resolve'); fd.append('id', '<?= (int)$detailAction['id'] ?>'); fd.append('csrf_token', window.PPSDOMS.csrf()); fetch('<?= BASE_URL ?>modules/actions.php', {method:'POST', body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();}); }">
                            <i class="fa-solid fa-check-double me-1"></i> Approve &amp; Resolve
                        </button>
                    <?php endif; ?>

                    <?php if ($canEdit): ?>
                        <button type="button" class="btn btn-sm btn-primary" onclick="window.PPSDOMS.openModal('Edit Action Point', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(action_form($detailAction), ENT_QUOTES, 'UTF-8') ?>">
                            <i class="fa-solid fa-pen-to-square me-1"></i> Edit Details
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-6 border-end">
                    <h6 class="text-uppercase small fw-bold text-secondary mb-3">Timelines &amp; Responsibility</h6>
                    <div class="mb-2">
                        <span class="text-muted small">Date Raised:</span><br>
                        <strong><?= format_date($detailAction['date']) ?></strong>
                    </div>
                    <div class="mb-2">
                        <span class="text-muted small">Timeline / Deadline:</span><br>
                        <strong><i class="fa-regular fa-clock me-1"></i> <?= e($detailAction['timeline']) ?></strong>
                    </div>
                    <div>
                        <span class="text-muted small">Person Responsible:</span><br>
                        <strong><i class="fa-solid fa-user me-1 text-primary"></i> <?= e($detailAction['person_responsible']) ?></strong>
                    </div>
                </div>

                <div class="col-md-6">
                    <h6 class="text-uppercase small fw-bold text-secondary mb-3">Status Overview</h6>
                    <div class="mb-2">
                        <span class="text-muted small">Current Status:</span><br>
                        <div class="mt-1"><?= badge_cell($detailAction['status']) ?></div>
                    </div>
                    <div class="mt-3">
                        <span class="text-muted small">Last Updated:</span><br>
                        <span class="small text-secondary"><?= date('d M Y, H:i', strtotime($detailAction['updated_at'])) ?></span>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="rounded-circle d-inline-block" style="width: 10px; height: 10px; background-color: #f59e0b;"></span>
                    <strong class="text-dark small">The Issue</strong>
                </div>
                <div class="p-3 bg-light rounded border text-secondary">
                    <?= nl2br(e($detailAction['issue'])) ?>
                </div>
            </div>

            <div>
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="rounded-circle d-inline-block" style="width: 10px; height: 10px; background-color: #10b981;"></span>
                    <strong class="text-dark small">Action / Progress</strong>
                </div>
                <div class="p-3 bg-light rounded border text-secondary">
                    <?= nl2br(e($detailAction['action'] ?: 'No progress notes logged yet.')) ?>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- Action Points Table (Matching Screenshot page 2) -->
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-clipboard-check text-primary"></i> Action Points Tracker
            </h4>
            <div class="d-flex gap-2">
                <?php if ($canEdit): ?>
                    <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('Create Action Point', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(action_form(), ENT_QUOTES, 'UTF-8') ?>">
                        <i class="fa-solid fa-circle-plus me-1"></i> Create New
                    </button>
                <?php endif; ?>
                <button class="btn btn-danger btn-sm" onclick="window.print()"><i class="fa-solid fa-file-pdf me-1"></i> PDF</button>
                <button class="btn btn-success btn-sm" onclick="exportTableToCSV('tbl-action-points', 'action_points_tracker.csv')"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
            </div>
        </div>

        <div class="card border-0 shadow-sm bg-white">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tbl-action-points" style="font-size: 0.8rem;">
                        <thead class="table-light">
                            <tr>
                                <th>Ref No</th>
                                <th>Date</th>
                                <th>Meeting</th>
                                <th>Issue</th>
                                <th>Responsible</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($actions as $a): 
                                $rowBg = match($a['status']) {
                                    'COMPLETED' => 'table-light',
                                    'STALLED' => 'table-danger',
                                    'DELAYED' => 'table-warning',
                                    default => ''
                                };
                            ?>
                                <tr class="<?= $rowBg ?>">
                                    <td class="fw-bold text-primary font-monospace"><?= e($a['ref_no']) ?></td>
                                    <td><?= format_date($a['date']) ?></td>
                                    <td class="fw-semibold"><?= e($a['meeting_title']) ?></td>
                                    <td class="text-truncate" style="max-width: 250px;" title="<?= e($a['issue']) ?>">
                                        <?= e($a['issue']) ?>
                                    </td>
                                    <td>
                                        <i class="fa-solid fa-user small me-1 text-muted"></i> <?= e($a['person_responsible']) ?>
                                    </td>
                                    <td><?= badge_cell($a['status']) ?></td>
                                    <td class="text-end text-nowrap">
                                        <a href="<?= BASE_URL ?>modules/actions.php?view=<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="View Details">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary me-1" title="Edit" onclick="window.PPSDOMS.openModal('Edit Action Point', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(action_form($a), ENT_QUOTES, 'UTF-8') ?>">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <?= delete_btn(BASE_URL . 'modules/actions.php', (int)$a['id']) ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script>
        function exportTableToCSV(tableId, filename) {
            let csv = [];
            const rows = document.querySelectorAll('#' + tableId + ' tr');
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll('td, th');
                for (let j = 0; j < cols.length - 1; j++) {
                    let data = cols[j].innerText.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
                csv.push(row.join(','));
            }
            const csvFile = new Blob([csv.join('\n')], {type: 'text/csv'});
            const downloadLink = document.createElement('a');
            downloadLink.download = filename;
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = 'none';
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
        </script>
    <?php endif; ?>
</div>
<?php
};

render_page('Action Points Tracker', $renderContent, ['active' => 'actions']);
