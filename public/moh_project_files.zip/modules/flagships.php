<?php
/**
 * Module 1: Priority Flagships
 * Matching Screenshot page 8 and page 9
 */
declare(strict_types=1);
require_once __DIR__ . '/../bootstrap.php';
require_login();

$db = db();
$user = current_user();
$canEdit = $user['role']['can_edit'] ?? false;

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_post();
    $input = request_input();
    $action = $input['action'] ?? '';

    if ($action === 'save') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $title = trim($input['title'] ?? '');
        $leadDir = trim($input['lead_directorate'] ?? '');
        $risk = $input['risk_level'] ?? 'Medium';
        $tier = $input['priority_tier'] ?? 'High';
        $progress = (int)($input['progress_pct'] ?? 0);
        $budgetAlloc = (float)($input['allocated_budget'] ?? 0);
        $budgetUtil = (float)($input['utilized_budget'] ?? 0);
        $leadOfficer = trim($input['lead_officer'] ?? '');
        $teamName = trim($input['team_name'] ?? '');
        $startDate = $input['start_date'] ?? date('Y-m-d');
        $targetDate = $input['target_date'] ?? date('Y-m-d', strtotime('+1 year'));
        $status = $input['status'] ?? 'In Progress';
        $desc = trim($input['description'] ?? '');

        if ($title === '') json_response(['error' => 'Title is required.'], 422);

        if ($id > 0) {
            $stmt = $db->prepare("UPDATE flagships SET title=?, description=?, lead_directorate=?, progress_pct=?, risk_level=?, priority_tier=?, allocated_budget=?, utilized_budget=?, lead_officer=?, team_name=?, start_date=?, target_date=?, status=? WHERE id=?");
            $stmt->execute([$title, $desc, $leadDir, $progress, $risk, $tier, $budgetAlloc, $budgetUtil, $leadOfficer, $teamName, $startDate, $targetDate, $status, $id]);
            log_activity('update', $user['id'], "Updated flagship: {$title}", $id, 'flagships');
        } else {
            $stmt = $db->prepare("INSERT INTO flagships (title, description, lead_directorate, progress_pct, risk_level, priority_tier, allocated_budget, utilized_budget, lead_officer, team_name, start_date, target_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $desc, $leadDir, $progress, $risk, $tier, $budgetAlloc, $budgetUtil, $leadOfficer, $teamName, $startDate, $targetDate, $status, $user['id']]);
            $id = (int)$db->lastInsertId();
            log_activity('create', $user['id'], "Created flagship: {$title}", $id, 'flagships');
        }
        json_response(['success' => true, 'message' => 'Flagship initiative saved successfully.']);
    }

    if ($action === 'delete') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $id = (int)($input['id'] ?? 0);
        $db->prepare("UPDATE projects SET flagship_id = NULL WHERE flagship_id = ?")->execute([$id]);
        $db->prepare("DELETE FROM flagships WHERE id=?")->execute([$id]);
        log_activity('delete', $user['id'], "Deleted flagship ID: {$id}", $id, 'flagships');
        json_response(['success' => true, 'message' => 'Flagship initiative deleted.']);
    }

    if ($action === 'link_project') {
        if (!$canEdit) json_response(['error' => 'Permission denied.'], 403);
        $flagshipId = (int)($input['flagship_id'] ?? 0);
        $projectId = (int)($input['project_id'] ?? 0);
        $db->prepare("UPDATE projects SET flagship_id = ? WHERE id = ?")->execute([$flagshipId, $projectId]);
        json_response(['success' => true, 'message' => 'Project linked to flagship successfully.']);
    }

    json_response(['error' => 'Invalid action.'], 400);
}

// Fetch flagships
$flagships = $db->query("SELECT * FROM flagships ORDER BY id ASC")->fetchAll();

// Detail view check
$viewId = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$detailFlagship = null;
$linkedProjects = [];
if ($viewId > 0) {
    $stmt = $db->prepare("SELECT * FROM flagships WHERE id = ?");
    $stmt->execute([$viewId]);
    $detailFlagship = $stmt->fetch();
    if ($detailFlagship) {
        $pStmt = $db->prepare("SELECT * FROM projects WHERE flagship_id = ? ORDER BY id DESC");
        $pStmt->execute([$viewId]);
        $linkedProjects = $pStmt->fetchAll();
    }
}

function flagship_form(?array $r = null): string {
    $r = $r ?? [];
    return modal_form('', [
        ['name' => 'title', 'label' => 'Flagship Title', 'required' => true, 'value' => $r['title'] ?? '', 'full' => true],
        ['name' => 'lead_directorate', 'label' => 'Lead Directorate / SAGA', 'required' => true, 'value' => $r['lead_directorate'] ?? ''],
        ['name' => 'priority_tier', 'label' => 'Priority Tier', 'type' => 'select', 'value' => $r['priority_tier'] ?? 'High', 'options' => ['Critical' => 'Critical', 'High' => 'High', 'Medium' => 'Medium', 'Low' => 'Low']],
        ['name' => 'risk_level', 'label' => 'Risk Level', 'type' => 'select', 'value' => $r['risk_level'] ?? 'Medium', 'options' => ['Low' => 'Low Risk', 'Medium' => 'Medium Risk', 'High' => 'High Risk', 'Severe' => 'Severe Risk']],
        ['name' => 'progress_pct', 'label' => 'Current Progress (%)', 'type' => 'number', 'value' => $r['progress_pct'] ?? 0],
        ['name' => 'allocated_budget', 'label' => 'Allocated Budget (KES)', 'type' => 'number', 'value' => $r['allocated_budget'] ?? 0],
        ['name' => 'utilized_budget', 'label' => 'Utilized Budget (KES)', 'type' => 'number', 'value' => $r['utilized_budget'] ?? 0],
        ['name' => 'lead_officer', 'label' => 'Lead Officer', 'value' => $r['lead_officer'] ?? ''],
        ['name' => 'team_name', 'label' => 'Implementation Team', 'value' => $r['team_name'] ?? ''],
        ['name' => 'start_date', 'label' => 'Start Date', 'type' => 'date', 'value' => $r['start_date'] ?? date('Y-m-d')],
        ['name' => 'target_date', 'label' => 'Target Completion Date', 'type' => 'date', 'value' => $r['target_date'] ?? date('Y-m-d', strtotime('+1 year'))],
        ['name' => 'status', 'label' => 'Status', 'type' => 'select', 'value' => $r['status'] ?? 'In Progress', 'options' => ['Planning' => 'Planning', 'In Progress' => 'In Progress', 'Completed' => 'Completed', 'On Hold' => 'On Hold', 'Delayed' => 'Delayed']],
        ['name' => 'description', 'label' => 'Strategic Objectives & Scope', 'type' => 'textarea', 'value' => $r['description'] ?? '', 'full' => true],
    ], 'Save Flagship', isset($r['id']) ? (int)$r['id'] : null);
}

$renderContent = function() use ($flagships, $detailFlagship, $linkedProjects, $canEdit) {
    if ($detailFlagship):
        // Single Flagship Detail View (matching screenshot page 8)
        $diff = strtotime($detailFlagship['target_date']) - time();
        $daysOverdue = ($diff < 0) ? abs((int)round($diff / 86400)) : 0;
        $alloc = (float)$detailFlagship['allocated_budget'];
        $util = (float)$detailFlagship['utilized_budget'];
        $pctUtil = ($alloc > 0) ? round(($util / $alloc) * 100, 1) : 0;
    ?>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <span class="text-uppercase small fw-bold text-muted">Priority Flagship Initiative</span>
                <h3 class="fw-bold mb-0 text-dark"><?= e($detailFlagship['title']) ?></h3>
            </div>
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>modules/flagships.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back to Flagships
                </a>
                <?php if ($canEdit): ?>
                    <button class="btn btn-primary btn-sm" onclick="window.PPSDOMS.openModal('Edit Flagship', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(flagship_form($detailFlagship), ENT_QUOTES, 'UTF-8') ?>">
                        <i class="fa-solid fa-pen-to-square me-1"></i> Edit Flagship
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-12 col-md-8">
                <div class="card border-0 shadow-sm p-3 h-100 bg-white">
                    <h6 class="fw-bold text-secondary mb-2 small text-uppercase">Overall Progress</h6>
                    <div class="d-flex align-items-center gap-3">
                        <div class="progress flex-grow-1" style="height: 18px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: <?= (int)$detailFlagship['progress_pct'] ?>%;">
                                <?= (int)$detailFlagship['progress_pct'] ?>%
                            </div>
                        </div>
                        <span class="fw-bold text-primary"><?= (int)$detailFlagship['progress_pct'] ?>%</span>
                    </div>
                    <p class="small text-muted mt-2 mb-0"><?= e($detailFlagship['description']) ?></p>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card border-0 shadow-sm p-3 h-100 bg-white text-center">
                    <h6 class="fw-bold text-secondary mb-2 small text-uppercase">Risk Assessment</h6>
                    <div class="d-flex justify-content-center gap-2 my-2">
                        <span class="rounded-circle d-inline-block" style="width: 24px; height: 24px; background-color: <?= in_array($detailFlagship['risk_level'], ['Low', 'Medium', 'High', 'Severe']) ? '#dc3545' : '#e0e0e0' ?>;"></span>
                        <span class="rounded-circle d-inline-block" style="width: 24px; height: 24px; background-color: <?= in_array($detailFlagship['risk_level'], ['Medium', 'High', 'Severe']) ? '#fd7e14' : '#e0e0e0' ?>;"></span>
                        <span class="rounded-circle d-inline-block" style="width: 24px; height: 24px; background-color: <?= in_array($detailFlagship['risk_level'], ['High', 'Severe']) ? '#ffc107' : '#e0e0e0' ?>;"></span>
                    </div>
                    <h5 class="fw-bold text-danger mb-0"><?= e($detailFlagship['risk_level']) ?> Risk</h5>
                </div>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-12 col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white h-100">
                    <div class="text-uppercase small fw-bold text-secondary mb-1">Budget Performance</div>
                    <div class="small text-muted">Allocated: <strong><?= format_kes($alloc) ?></strong></div>
                    <div class="small text-muted">Utilized: <strong><?= format_kes($util) ?></strong></div>
                    <div class="mt-2 fw-bold text-primary"><?= $pctUtil ?>% Utilized</div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white h-100">
                    <div class="text-uppercase small fw-bold text-secondary mb-1">Timeline Variance</div>
                    <div class="small text-muted">Start: <strong><?= format_date($detailFlagship['start_date']) ?></strong></div>
                    <div class="small text-muted">Due: <strong><?= format_date($detailFlagship['target_date']) ?></strong></div>
                    <div class="mt-2 fw-bold <?= $daysOverdue > 0 ? 'text-danger' : 'text-success' ?>">
                        <?= $daysOverdue > 0 ? "{$daysOverdue} Days Overdue" : 'On Track' ?>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white h-100">
                    <div class="text-uppercase small fw-bold text-secondary mb-1">Stakeholders</div>
                    <div class="small text-muted">Lead: <strong><?= e($detailFlagship['lead_officer'] ?: 'Dr. Rose Njeru') ?></strong></div>
                    <div class="small text-muted">Team: <strong><?= e($detailFlagship['team_name'] ?: 'Directorate Steering Committee') ?></strong></div>
                    <div class="mt-2 small text-primary"><i class="fa-solid fa-users me-1"></i> <?= e($detailFlagship['lead_directorate']) ?></div>
                </div>
            </div>
        </div>

        <!-- Linked Projects Section -->
        <div class="card border-0 shadow-sm bg-white mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0 text-primary"><i class="fa-solid fa-link me-2"></i> Linked Projects</h6>
                <?php if ($canEdit): ?>
                    <a href="<?= BASE_URL ?>modules/projects.php" class="btn btn-sm btn-outline-primary">
                        <i class="fa-solid fa-plus me-1"></i> Link Project
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 0.85rem;">
                        <thead class="table-light">
                            <tr>
                                <th>Code</th>
                                <th>Project Title</th>
                                <th>Budget</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($linkedProjects)): ?>
                                <tr><td colspan="5" class="text-center py-3 text-muted">No projects currently linked to this flagship.</td></tr>
                            <?php else: ?>
                                <?php foreach ($linkedProjects as $lp): ?>
                                    <tr>
                                        <td class="fw-bold"><?= e($lp['project_code']) ?></td>
                                        <td><?= e($lp['title']) ?></td>
                                        <td><?= format_kes($lp['total_budget']) ?></td>
                                        <td><?= badge_cell($lp['status']) ?></td>
                                        <td>
                                            <a href="<?= BASE_URL ?>modules/projects.php?id=<?= $lp['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- Flagships Grid / List (Matching screenshot page 9) -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="fa-solid fa-flag text-primary"></i> Priority Flagships
            </h4>
            <?php if ($canEdit): ?>
                <button class="btn btn-success btn-sm px-3 fw-bold" onclick="window.PPSDOMS.openModal('New Priority Flagship', this.getAttribute('data-form'))" data-form="<?= htmlspecialchars(flagship_form(), ENT_QUOTES, 'UTF-8') ?>">
                    <i class="fa-solid fa-plus me-1"></i> Add Flagship
                </button>
            <?php endif; ?>
        </div>

        <div class="row g-4">
            <?php foreach ($flagships as $f): ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card border-0 shadow-sm h-100 bg-white p-3" style="border-top: 4px solid #0d47a1 !important;">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge bg-danger text-uppercase fw-bold"><?= e($f['priority_tier']) ?></span>
                            <span class="badge bg-light text-dark border"><?= e($f['risk_level']) ?> Risk</span>
                        </div>
                        <h5 class="fw-bold text-dark mt-2 mb-1" style="font-size: 1.05rem;">
                            <a href="<?= BASE_URL ?>modules/flagships.php?view=<?= $f['id'] ?>" class="text-dark text-decoration-none hover-primary">
                                <?= e($f['title']) ?>
                            </a>
                        </h5>
                        <p class="small text-muted mb-3 text-truncate" style="max-height: 40px;"><?= e($f['description']) ?></p>
                        
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between small fw-bold mb-1">
                                <span>Progress</span>
                                <span class="text-primary"><?= (int)$f['progress_pct'] ?>%</span>
                            </div>
                            <div class="progress mb-3" style="height: 8px;">
                                <div class="progress-bar bg-primary" style="width: <?= (int)$f['progress_pct'] ?>%;"></div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                <span class="small text-muted"><i class="fa-solid fa-calendar-days me-1"></i> Due: <?= date('M Y', strtotime($f['target_date'])) ?></span>
                                <div class="d-flex gap-1 align-items-center">
                                    <span class="badge bg-primary"><?= e($f['status']) ?></span>
                                    <a href="<?= BASE_URL ?>modules/flagships.php?view=<?= $f['id'] ?>" class="btn btn-sm btn-outline-secondary py-0 px-2" title="View Details"><i class="fa-solid fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php
};

render_page('Priority Flagships', $renderContent, ['active' => 'flagships']);
