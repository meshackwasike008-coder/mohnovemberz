<?php
/**
 * Root Bridge: Action Points
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/actions.php';
