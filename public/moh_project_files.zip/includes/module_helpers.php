<?php
/**
 * Reusable scaffolding helpers for CRUD modules, badges, and modals.
 */
declare(strict_types=1);

function badge_cell($status): string {
    $s = strtoupper(trim((string)($status ?? '')));
    $badgeClasses = [
        'ON TRACK' => 'badge-ontrack',
        'COMPLETED' => 'badge-ontrack',
        'ACTIVE' => 'badge-ontrack',
        'APPROVED' => 'badge-ontrack',
        'CHECKED IN' => 'badge-ontrack',
        'NOT STARTED' => 'badge-notstarted',
        'IN PROGRESS' => 'badge-inprogress',
        'DELAYED' => 'badge-delayed',
        'STALLED' => 'badge-stalled',
        'SEVERE' => 'badge-stalled',
        'CRITICAL' => 'badge-stalled',
        'OVERDUE' => 'badge-stalled',
        'CANCELLED' => 'badge-cancelled',
        'CLOSED' => 'badge-cancelled',
        'PENDING' => 'badge-pending',
        'PLANNING' => 'badge-pending',
        'MEDIUM' => 'badge-pending',
    ];
    $cls = $badgeClasses[$s] ?? 'badge-inprogress';
    return '<span class="status-badge ' . $cls . '">' . e($status ?? 'Unknown') . '</span>';
}

function edit_btn(string $title, string $formHtml): string {
    $safeHtml = htmlspecialchars($formHtml, ENT_QUOTES, 'UTF-8');
    return '<button type="button" class="btn btn-sm btn-outline-primary me-1" title="' . e($title) . '" onclick="window.PPSDOMS.openModal(\'' . e($title) . '\', this.getAttribute(\'data-form\'))" data-form="' . $safeHtml . '"><i class="fa-solid fa-pen-to-square"></i></button>';
}

function delete_btn(string $actionUrl, int $id): string {
    return '<button type="button" class="btn btn-sm btn-outline-danger" title="Delete" onclick="if(confirm(\'Are you sure you want to delete this record?\')){ const fd = new FormData(); fd.append(\'action\', \'delete\'); fd.append(\'id\', \'' . $id . '\'); fd.append(\'csrf_token\', window.PPSDOMS.csrf()); const targetUrl = \'' . e($actionUrl) . '\' || window.location.href; fetch(targetUrl, {method:\'POST\', headers:{\'X-Requested-With\':\'XMLHttpRequest\'}, body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload(); else alert(d.error||d.message);}).catch(e=>alert(e.message||e)); }"><i class="fa-solid fa-trash"></i></button>';
}

function modal_form(string $actionUrl = '', array $fields = [], string $submitLabel = 'Save Changes', ?int $id = null): string {
    $actionAttr = ($actionUrl !== '') ? ' action="' . e($actionUrl) . '"' : ' action=""';
    $out = '<form method="POST"' . $actionAttr . ' enctype="multipart/form-data" data-ajax class="p-2">';
    $out .= csrf_field();
    $out .= '<input type="hidden" name="action" value="save">';
    if ($id !== null) {
        $out .= '<input type="hidden" name="id" value="' . (int)$id . '">';
    }

    $out .= '<div class="row g-3">';
    foreach ($fields as $f) {
        $full = !empty($f['full']);
        $col = $full ? 'col-12' : 'col-md-6';
        $type = $f['type'] ?? 'text';
        $name = $f['name'];
        $label = $f['label'];
        $val = $f['value'] ?? '';
        $req = !empty($f['required']) ? 'required' : '';

        $out .= '<div class="' . $col . '">';
        $out .= '<label class="form-label fw-bold small mb-1">' . e($label) . ($req ? ' <span class="text-danger">*</span>' : '') . '</label>';

        if ($type === 'select') {
            $out .= '<select name="' . e($name) . '" class="form-select form-select-sm" ' . $req . '>';
            foreach ($f['options'] ?? [] as $k => $optLabel) {
                $sel = ($val == $k) ? 'selected' : '';
                $out .= '<option value="' . e((string)$k) . '" ' . $sel . '>' . e((string)$optLabel) . '</option>';
            }
            $out .= '</select>';
        } elseif ($type === 'textarea') {
            $out .= '<textarea name="' . e($name) . '" rows="' . ($f['rows'] ?? 3) . '" class="form-control form-control-sm" ' . $req . '>' . e((string)$val) . '</textarea>';
        } elseif ($type === 'file') {
            $accept = !empty($f['accept']) ? ' accept="' . e($f['accept']) . '"' : '';
            $out .= '<input type="file" name="' . e($name) . '" class="form-control form-control-sm" ' . $accept . ' ' . $req . '>';
            if (!empty($f['hint'])) {
                $out .= '<div class="form-text small text-muted" style="font-size:0.75rem;">' . e($f['hint']) . '</div>';
            }
        } else {
            $out .= '<input type="' . e($type) . '" name="' . e($name) . '" value="' . e((string)$val) . '" class="form-control form-control-sm" ' . $req . '>';
        }
        $out .= '</div>';
    }
    $out .= '</div>';

    $out .= '<div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">';
    $out .= '<button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>';
    $out .= '<button type="submit" class="btn btn-primary btn-sm px-4 fw-bold">' . e($submitLabel) . '</button>';
    $out .= '</div>';
    $out .= '</form>';

    return $out;
}
