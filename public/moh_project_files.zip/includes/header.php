<?php
/**
 * Shared Header Template
 * Exact UX/UI matching MOH State Department for Medical Services Screenshots.
 */
declare(strict_types=1);
$currentUser = current_user();
$modules = modules();
$activeModule = $pageConfig['active'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageConfig['title'] ?? 'PP-SDOMS') ?> | State Department for Medical Services</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <!-- CSRF Token Meta -->
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    
    <style>
        :root {
            --primary-navy: #0a2558;
            --primary-blue: #0d47a1;
            --accent-blue: #4169e1;
            --light-blue: #e3f2fd;
            --paper: #f4f7fb;
        }
        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--paper);
            color: #212529;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-header {
            background: linear-gradient(135deg, #0a2356 0%, #0d47a1 100%);
            color: #ffffff;
            padding: 12px 24px;
            border-bottom: 2px solid #08214d;
        }
        .header-brand {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .coat-of-arms {
            width: 58px;
            height: 58px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }
        .brand-title {
            font-size: 1.25rem;
            font-weight: 800;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            line-height: 1.15;
            margin: 0;
            color: #ffffff;
        }
        .brand-subtitle {
            font-size: 0.85rem;
            font-weight: 500;
            color: #90caf9;
            margin: 0;
            letter-spacing: 0.02em;
        }
        .header-right {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .notif-btn {
            position: relative;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.2);
            color: #ffffff;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.25);
            color: #ffffff;
        }
        .notif-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background-color: #dc3545;
            color: #ffffff;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 10px;
            border: 2px solid #0a2356;
        }
        .user-pill {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(255,255,255,0.12);
            padding: 4px 14px 4px 6px;
            border-radius: 30px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
            border: 1.5px solid #90caf9;
        }
        .user-meta-name {
            font-size: 0.85rem;
            font-weight: 700;
            line-height: 1.1;
            color: #ffffff;
        }
        .user-meta-role {
            font-size: 0.72rem;
            color: #bbdefb;
            font-weight: 500;
        }
        .btn-logout {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.4);
            color: #ffcdd2;
            padding: 6px 14px;
            border-radius: 6px;
            font-size: 0.82rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-logout:hover {
            background: #dc3545;
            color: #ffffff;
            border-color: #dc3545;
        }
        
        /* Top Horizontal Nav Bar */
        .top-navbar {
            background: #0d47a1;
            padding: 0 24px;
            border-bottom: 3px solid #1565c0;
            overflow-x: auto;
            white-space: nowrap;
        }
        .top-nav-list {
            display: flex;
            align-items: center;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .top-nav-link {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 12px 14px;
            font-size: 0.78rem;
            font-weight: 700;
            color: #ffffff;
            text-decoration: none;
            letter-spacing: 0.04em;
            border-bottom: 3px solid transparent;
            margin-bottom: -3px;
            transition: all 0.15s ease-in-out;
            text-transform: uppercase;
        }
        .top-nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            border-bottom-color: #90caf9;
        }
        .top-nav-link.active {
            color: #ffffff;
            background: rgba(255,255,255,0.18);
            border-bottom-color: #ffeb3b;
        }

        /* Core Values Marquee */
        .marquee-bar {
            background: #1976d2;
            color: #ffffff;
            font-size: 0.85rem;
            font-weight: 700;
            font-style: italic;
            padding: 6px 0;
            letter-spacing: 0.04em;
            border-bottom: 1px solid #1565c0;
            box-shadow: inset 0 -1px 3px rgba(0,0,0,0.1);
        }

        /* Content Container */
        .content-wrapper {
            flex: 1;
            padding: 24px;
        }

        /* Status colors and badges */
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .badge-ontrack { background-color: #28a745; color: #fff; }
        .badge-completed { background-color: #000000; color: #fff; }
        .badge-notstarted { background-color: #212529; color: #fff; }
        .badge-delayed { background-color: #d63384; color: #fff; }
        .badge-stalled { background-color: #dc3545; color: #fff; }
        .badge-cancelled { background-color: #6c757d; color: #fff; }
        .badge-inprogress { background-color: #0d6efd; color: #fff; }
        .badge-pending { background-color: #ffc107; color: #212529; }
        .badge-approved { background-color: #198754; color: #fff; }

        /* Blue Quick Access Cards matching screenshot */
        .quick-access-card {
            background: #0d47a1;
            color: #ffffff;
            border-radius: 8px;
            padding: 28px 20px;
            text-align: center;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.2s ease-in-out;
            box-shadow: 0 4px 12px rgba(13, 71, 161, 0.15);
            border: 1px solid #1565c0;
            height: 100%;
        }
        .quick-access-card:hover {
            background: #0a3880;
            color: #ffffff;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(13, 71, 161, 0.25);
        }
        .quick-access-card i {
            font-size: 2.2rem;
            color: #90caf9;
        }
        .quick-access-title {
            font-size: 1.05rem;
            font-weight: 700;
            margin: 0;
        }
        .quick-access-desc {
            font-size: 0.78rem;
            color: #e3f2fd;
            margin: 0;
        }

        /* Footer */
        .main-footer {
            background: #111827;
            color: #9ca3af;
            padding: 16px 24px;
            font-size: 0.8rem;
            border-top: 1px solid #1f2937;
        }
        .footer-social a {
            color: #90caf9;
            margin-left: 12px;
            font-size: 1rem;
            transition: color 0.15s;
        }
        .footer-social a:hover {
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Header -->
<header class="main-header">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div class="header-brand">
            <img src="<?= BASE_URL ?>public/assets/images/kenya_coat_arms.png" onerror="this.src='/src/assets/images/kenya_coat_arms_1790239737101.jpg'" alt="Kenya Coat of Arms" class="coat-of-arms">
            <div>
                <h1 class="brand-title">STATE DEPARTMENT FOR MEDICAL SERVICES</h1>
                <p class="brand-subtitle">Performance Management Dashboard</p>
            </div>
        </div>
        <div class="header-right">
            <!-- Notification Dropdown -->
            <div class="dropdown">
                <button class="notif-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="System Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <span class="notif-badge">5</span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="width: 320px; font-size: 0.82rem;">
                    <li class="dropdown-header fw-bold text-uppercase py-2 bg-light">Actionable Notifications (5)</li>
                    <li><a class="dropdown-item py-2" href="<?= BASE_URL ?>modules/reports.php"><i class="fa-solid fa-file-invoice text-warning me-2"></i> Report REP-20260203-1604 pending approval</a></li>
                    <li><a class="dropdown-item py-2" href="<?= BASE_URL ?>modules/actions.php"><i class="fa-solid fa-triangle-exclamation text-danger me-2"></i> Action Point APT-001 is Stalled</a></li>
                    <li><a class="dropdown-item py-2" href="<?= BASE_URL ?>modules/events.php"><i class="fa-solid fa-calendar text-info me-2"></i> KNH Modern Burns ICU Commissioning</a></li>
                    <li><a class="dropdown-item py-2" href="<?= BASE_URL ?>modules/pc.php"><i class="fa-solid fa-chart-line text-success me-2"></i> Q3 PC Targets ready for Directorate review</a></li>
                    <li><a class="dropdown-item py-2" href="<?= BASE_URL ?>modules/visitors.php"><i class="fa-solid fa-id-badge text-primary me-2"></i> Dr. Sarah Ndwiga (KEMRI) currently checked in</a></li>
                </ul>
            </div>

            <!-- Current User Info -->
            <div class="user-pill text-white">
                <img src="<?= BASE_URL ?>public/assets/images/avatar.png" onerror="this.src='/src/assets/images/avatar_system_admin_1790239749304.jpg'" alt="Avatar" class="user-avatar">
                <div class="d-none d-md-block text-start">
                    <div class="user-meta-name">Logged in as <?= e($currentUser['full_name'] ?? 'System Administrator') ?></div>
                    <div class="user-meta-role">[<?= e($currentUser['role']['name'] ?? 'System Admin') ?>]</div>
                </div>
            </div>

            <!-- Logout -->
            <a href="<?= BASE_URL ?>logout.php" class="btn-logout" title="Sign out of the system">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span class="d-none d-sm-inline">Logout</span>
            </a>
        </div>
    </div>
</header>

<!-- Horizontal Top Navigation Menu -->
<nav class="top-navbar">
    <ul class="top-nav-list">
        <?php foreach ($modules as $m): ?>
            <li>
                <a href="<?= BASE_URL . $m['file'] ?>" class="top-nav-link <?= ($activeModule === $m['slug']) ? 'active' : '' ?>">
                    <?= e($m['name']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</nav>

<!-- Core Values Marquee -->
<div class="marquee-bar text-center">
    <marquee behavior="scroll" direction="left" scrollamount="6">
        CORE VALUES: Integrity, Professionalism, Accountability, Ethics, Teamwork, Delivery, Impact. &nbsp;&bull;&nbsp; Dedicated to Universal Health Coverage (UHC) and Quality Healthcare for All Kenyans. &nbsp;&bull;&nbsp; State Department for Medical Services.
    </marquee>
</div>

<!-- Main View Wrapper -->
<main class="content-wrapper">
