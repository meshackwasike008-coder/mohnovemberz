<?php
/**
 * Core utility functions: Session, Auth, RBAC, CSRF, Audit, Sanitization.
 */
declare(strict_types=1);

// Initialize secure session
function start_session_secure(): void {
    if (session_status() === PHP_SESSION_NONE) {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['SERVER_PORT'] ?? '') == 443)
            || (strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
            || (str_contains(strtolower($_SERVER['HTTP_CF_VISITOR'] ?? ''), 'https'));
        
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        if ($isHttps) {
            ini_set('session.cookie_secure', '1');
        }

        session_start();

        // Regenerate session ID periodically
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = time();
        } elseif (time() - $_SESSION['last_regeneration'] > 3600) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

// Authentication check
function require_login(): void {
    start_session_secure();
    if (empty($_SESSION['user_id'])) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            http_response_code(401);
            echo json_encode(['error' => 'Session expired. Please log in again.']);
            exit;
        }
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}

// Permission check
function require_permission(string $flag): void {
    require_login();
    $user = current_user();
    if (empty($user['role'][$flag])) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized access.']);
            exit;
        }
        http_response_code(403);
        die('Access Denied: You do not have sufficient permissions for this operation.');
    }
}

// Get current user details and permissions
function current_user(): array {
    start_session_secure();
    if (empty($_SESSION['user_id'])) {
        return [];
    }

    if (isset($_SESSION['cached_user']) && is_array($_SESSION['cached_user'])) {
        return $_SESSION['cached_user'];
    }

    $db = db();
    $stmt = $db->prepare("
        SELECT u.*, r.name as role_name, r.can_upload, r.can_edit, r.can_approve_tasks, r.can_download, r.is_admin 
        FROM users u 
        LEFT JOIN roles r ON u.role_id = r.id 
        WHERE u.id = ? AND u.is_active = 1
    ");
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }

    $isAdmin = (bool)($user['is_admin'] ?? false);
    $user['role'] = [
        'name' => $user['role_name'] ?? 'Officer',
        'can_upload' => (bool)($user['can_upload'] ?? false) || $isAdmin,
        'can_edit' => (bool)($user['can_edit'] ?? false) || $isAdmin,
        'can_approve_tasks' => (bool)($user['can_approve_tasks'] ?? false) || $isAdmin,
        'can_download' => (bool)($user['can_download'] ?? false) || $isAdmin,
        'is_admin' => $isAdmin,
    ];

    $_SESSION['cached_user'] = $user;
    return $user;
}

// Attempt user login
function attempt_login(string $email, string $password): array {
    start_session_secure();
    $db = db();

    $stmt = $db->prepare("
        SELECT u.*, r.name as role_name, r.can_upload, r.can_edit, r.can_approve_tasks, r.can_download, r.is_admin 
        FROM users u 
        LEFT JOIN roles r ON u.role_id = r.id 
        WHERE u.email = ?
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    $ip = client_ip();

    if (!$user || !(bool)$user['is_active']) {
        log_activity('login_failed', null, "Failed login attempt for email: {$email}", null, 'auth', $ip);
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }

    if ($user['failed_login_attempts'] >= 5) {
        log_activity('login_locked', (int)$user['id'], "Account locked after 5 failed login attempts: {$email}", (int)$user['id'], 'auth', $ip);
        return ['success' => false, 'message' => 'Account is temporarily locked due to consecutive failed attempts. Contact system administrator.'];
    }

    if (!password_verify($password, $user['password_hash'])) {
        $attempts = (int)$user['failed_login_attempts'] + 1;
        $db->prepare("UPDATE users SET failed_login_attempts = ? WHERE id = ?")->execute([$attempts, $user['id']]);
        log_activity('login_failed', (int)$user['id'], "Incorrect password for user ID: {$user['id']}", (int)$user['id'], 'auth', $ip);
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }

    // Success
    $db->prepare("UPDATE users SET failed_login_attempts = 0, last_login = NOW() WHERE id = ?")->execute([$user['id']]);
    $_SESSION['user_id'] = (int)$user['id'];
    unset($_SESSION['cached_user']);

    log_activity('login_success', (int)$user['id'], "User logged in: {$user['full_name']} ({$user['email']})", (int)$user['id'], 'auth', $ip);

    return ['success' => true, 'user' => current_user()];
}

// Client IP detection (safe proxy traversal)
function client_ip(): string {
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $ips = explode(',', $_SERVER[$k]);
            $ip = trim($ips[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '127.0.0.1';
}

// CSRF Protection
function csrf_token(): string {
    start_session_secure();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function csrf_verify(): bool {
    start_session_secure();
    $token = $_POST['csrf_token'] 
        ?? $_SERVER['HTTP_X_CSRF_TOKEN'] 
        ?? $_SERVER['HTTP_X_XSRF_TOKEN']
        ?? $_GET['csrf_token'] 
        ?? '';
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals((string)$_SESSION['csrf_token'], (string)$token);
}

function require_post(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Method Not Allowed. Must be a POST request.']);
        exit;
    }
    if (!csrf_verify()) {
        http_response_code(419);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false,
            'error' => 'Security token expired (CSRF). Please refresh the page to obtain a fresh token.'
        ]);
        exit;
    }
}

// Centralized Audit Logging
function log_activity(string $action, ?int $userId, string $description, ?int $entityId = null, string $module = 'general', ?string $ip = null): void {
    try {
        $db = db();
        $user = current_user();
        $username = $user['full_name'] ?? 'System / Anonymous';
        $uid = $userId ?? ($user['id'] ?? null);
        $clientIp = $ip ?: client_ip();
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

        $stmt = $db->prepare("
            INSERT INTO audit_logs (user_id, username, action, module, entity_id, description, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$uid, $username, $action, $module, $entityId, $description, $clientIp, $ua]);
    } catch (Throwable $e) {
        error_log('Audit log failure: ' . $e->getMessage());
    }
}

// Helper: Escape HTML (mixed/scalar safe)
function e($str): string {
    if ($str === null) return '';
    if (is_scalar($str)) return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
    if (is_object($str) && method_exists($str, '__toString')) return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
    return '';
}

// Helper: Format KES Currency
function format_kes($val): string {
    $num = (float)($val ?? 0);
    return 'KES ' . number_format($num, 2);
}

// Helper: Format date
function format_date($date, string $format = 'd M Y'): string {
    if (!$date) return '-';
    $ts = is_numeric($date) ? (int)$date : strtotime((string)$date);
    return $ts ? date($format, $ts) : (string)$date;
}


// Read JSON input or fallback to $_POST
function request_input(): array {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json')) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if (is_array($data)) return $data;
    }
    return $_POST;
}

// JSON Output response
function json_response(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

// Navigation items manifest
function modules(): array {
    $u = current_user();
    $items = [
        ['slug' => 'dashboard', 'name' => 'DASHBOARD', 'file' => 'dashboard.php'],
        ['slug' => 'flagships', 'name' => 'PRIORITY FLAGSHIPS', 'file' => 'modules/flagships.php'],
        ['slug' => 'events', 'name' => 'ACTIVITIES AND EVENTS', 'file' => 'modules/events.php'],
        ['slug' => 'actions', 'name' => 'ACTION POINTS TRACKER', 'file' => 'modules/actions.php'],
        ['slug' => 'projects', 'name' => 'PROJECTS AND PROGRAMMES', 'file' => 'modules/projects.php'],
        ['slug' => 'visitors', 'name' => 'VISITORS', 'file' => 'modules/visitors.php'],
        ['slug' => 'reports', 'name' => 'REPORTS', 'file' => 'modules/reports.php'],
        ['slug' => 'diary', 'name' => 'DIARY', 'file' => 'modules/diary.php'],
        ['slug' => 'pc', 'name' => 'PERFORMANCE CONTRACT', 'file' => 'modules/pc.php'],
        ['slug' => 'mail', 'name' => 'MAIL MANAGEMENT', 'file' => 'modules/mail.php'],
        ['slug' => 'users', 'name' => 'USERS', 'file' => 'modules/users.php'],
    ];

    if (!empty($u['role']['is_admin'])) {
        $items[] = ['slug' => 'audit_logs', 'name' => 'AUDIT LOGS', 'file' => 'modules/audit_logs.php'];
    }

    $items[] = ['slug' => 'backup', 'name' => 'CPANEL & BACKUP', 'file' => 'admin/backup.php'];

    return $items;
}

// PHP 8 Backwards Compatibility Polyfills
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return '' === $needle || false !== strpos($haystack, $needle);
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return '' === $needle || 0 === strncmp($haystack, $needle, strlen($needle));
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return '' === $needle || (strlen($needle) <= strlen($haystack) && 0 === substr_compare($haystack, $needle, -strlen($needle)));
    }
}

