<?php
/**
 * View wrapper functions
 */
declare(strict_types=1);

function render_page(string $title, callable $contentRenderer, array $pageConfig = []): void {
    $pageConfig['title'] = $title;
    require_once INCLUDES_DIR . '/header.php';
    $contentRenderer();
    require_once INCLUDES_DIR . '/footer.php';
}

/**
 * Alias for render_page to guarantee backward compatibility
 */
function layout(string $title, callable $contentRenderer, array $pageConfig = []): void {
    render_page($title, $contentRenderer, $pageConfig);
}

function render_standalone(string $title, callable $contentRenderer): void {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= e($title) ?> | State Department for Medical Services</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
        <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    </head>
    <body class="bg-light">
        <?php $contentRenderer(); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
}
