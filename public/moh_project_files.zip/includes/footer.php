<?php
/**
 * Shared Footer Template
 */
declare(strict_types=1);
?>
</main>

<!-- Footer -->
<footer class="main-footer">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <div>
            <strong>&copy; 2026 STATE DEPARTMENT FOR MEDICAL SERVICES.</strong><br class="d-sm-none">
            <span class="ms-sm-3">Website: <a href="https://www.health.go.ke" target="_blank" class="text-light text-decoration-none">www.health.go.ke</a></span>
            <span class="ms-3">Email: <a href="mailto:info@health.go.ke" class="text-light text-decoration-none">info@health.go.ke</a></span>
        </div>
        <div class="footer-social d-flex align-items-center">
            <span class="me-2 text-muted">Connect with us on Social Media:</span>
            <a href="#" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
            <a href="#" title="Twitter / X"><i class="fa-brands fa-x-twitter"></i></a>
            <a href="#" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
            <a href="#" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
            <a href="#" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
        </div>
    </div>
</footer>

<!-- Shared Dynamic Modal Container -->
<div class="modal fade" id="appModal" tabindex="-1" aria-labelledby="appModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fs-6 fw-bold" id="appModalLabel">Modal Title</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="appModalBody">
                <!-- Injected content -->
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js 4 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<!-- Global App Script -->
<script>
window.PPSDOMS = {
    csrf: function() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    },
    openModal: function(title, htmlContent) {
        document.getElementById('appModalLabel').textContent = title;
        document.getElementById('appModalBody').innerHTML = htmlContent;
        const modalEl = document.getElementById('appModal');
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    },
    closeModal: function() {
        const modalEl = document.getElementById('appModal');
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();
    },
    notice: function(msg, type = 'success') {
        alert(msg);
    }
};

// Auto attach AJAX handler to forms with data-ajax
document.addEventListener('submit', function(e) {
    const form = e.target.closest('form[data-ajax]');
    if (!form) return;
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Processing...';
    }

    const formData = new FormData(form);
    
    // Ensure CSRF token is present in formData
    const csrfVal = window.PPSDOMS.csrf();
    if (csrfVal && !formData.get('csrf_token')) {
        formData.append('csrf_token', csrfVal);
    }

    // Determine target URL safely:
    // If action attribute is empty, relative, or absent, submit directly to the current page
    const rawAction = form.getAttribute('action');
    let targetUrl = window.location.href;
    if (rawAction && rawAction.trim() !== '' && rawAction !== '#' && rawAction !== 'about:blank') {
        try {
            targetUrl = new URL(rawAction, window.location.href).href;
        } catch (_) {
            targetUrl = window.location.href;
        }
    }

    fetch(targetUrl, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': csrfVal
        },
        body: formData
    })
    .then(async function(res) {
        const text = await res.text();
        let data = null;
        try {
            data = JSON.parse(text);
        } catch (jsonErr) {
            console.error('Non-JSON server response:', text);
            // Clean up HTML tags if server returned an HTML error page
            const cleanText = text.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim();
            throw new Error(cleanText.substring(0, 200) || ('Server returned HTTP status ' + res.status));
        }
        return { ok: res.ok, status: res.status, data: data };
    })
    .then(function(result) {
        const data = result.data;
        if (result.ok && data && (data.success || data.status === 'success')) {
            window.PPSDOMS.closeModal();
            location.reload();
        } else {
            const msg = (data && (data.error || data.message)) ? (data.error || data.message) : ('Request failed (HTTP ' + result.status + ')');
            alert(msg);
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            }
        }
    })
    .catch(function(err) {
        console.error('Form submission failure:', err);
        alert(err.message || 'Network or server communication error. Please check your connection.');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    });
});
</script>
</body>
</html>
