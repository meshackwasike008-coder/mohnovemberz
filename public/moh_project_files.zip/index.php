<?php
/**
 * Login Page
 */
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
start_session_secure();

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrf_verify()) {
        $error = 'Security verification failed (CSRF). Please refresh and try again.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $res = attempt_login($email, $password);
        if ($res['success']) {
            header('Location: ' . BASE_URL . 'dashboard.php');
            exit;
        } else {
            $error = $res['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | State Department for Medical Services</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0a2558 0%, #0d47a1 50%, #1565c0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 16px 36px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 440px;
            overflow: hidden;
        }
        .login-header {
            background: #0d47a1;
            color: #ffffff;
            padding: 28px 24px;
            text-align: center;
        }
        .coat-of-arms {
            width: 72px;
            height: 72px;
            object-fit: contain;
            margin-bottom: 12px;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header">
        <img src="<?= BASE_URL ?>public/assets/images/kenya_coat_arms.png" onerror="this.src='/src/assets/images/kenya_coat_arms_1790239737101.jpg'" alt="Kenya Coat of Arms" class="coat-of-arms">
        <h5 class="fw-bold text-uppercase mb-1 tracking-wider" style="font-size: 1rem; letter-spacing: 0.05em;">State Department for Medical Services</h5>
        <p class="small text-light mb-0" style="opacity: 0.9;">Project Performance & Operational Management System (PP-SDOMS)</p>
    </div>
    <div class="p-4">
        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?= BASE_URL ?>index.php">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label small fw-bold text-secondary">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-envelope"></i></span>
                    <input type="email" name="email" value="admin@health.go.ke" required class="form-control" placeholder="name@health.go.ke">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold text-secondary">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" name="password" value="ChangeMe@2026" required class="form-control" placeholder="••••••••">
                </div>
            </div>

            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-primary fw-bold py-2" style="background-color: #0d47a1; border-color: #0d47a1;">
                    Sign In to Dashboard
                </button>
            </div>
        </form>

        <div class="mt-4 pt-3 border-top text-center text-muted small">
            <div><strong>Default Admin:</strong> admin@health.go.ke</div>
            <div><strong>Default Password:</strong> ChangeMe@2026</div>
        </div>
    </div>
</div>

</body>
</html>
