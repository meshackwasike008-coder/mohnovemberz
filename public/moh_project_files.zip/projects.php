<?php
/**
 * Root Bridge: Projects & Programmes
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/projects.php';
