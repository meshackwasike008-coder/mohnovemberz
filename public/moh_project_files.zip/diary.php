<?php
/**
 * Root Bridge: Diary & Project Planner
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/diary.php';
