<?php
/**
 * Root Bridge: Reports & System Data
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/reports.php';
