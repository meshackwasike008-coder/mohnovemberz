<?php
/**
 * Logout Page
 */
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
start_session_secure();

if (!empty($_SESSION['user_id'])) {
    log_activity('logout', (int)$_SESSION['user_id'], 'User logged out', (int)$_SESSION['user_id'], 'auth');
}

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

header('Location: ' . BASE_URL . 'index.php');
exit;
