<?php
/**
 * Root Bridge: User Management
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/users.php';
