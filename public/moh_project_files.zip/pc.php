<?php
/**
 * Root Bridge: Performance Contract
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/pc.php';
