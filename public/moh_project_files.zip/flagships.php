<?php
/**
 * Root Bridge: Priority Flagships
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/flagships.php';
