-- ==============================================================================
-- Project Performance, Service Delivery & Operational Management System (PP-SDOMS)
-- Ministry of Health — State Department for Medical Services
-- Database: mohsdms / chasonet_moh
-- MySQL 8.0+ / MariaDB 10.6+ Compatible
-- ==============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- Table structure for `roles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `can_upload` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_approve_tasks` tinyint(1) NOT NULL DEFAULT 0,
  `can_download` tinyint(1) NOT NULL DEFAULT 1,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




-- --------------------------------------------------------
-- Table structure for `roles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `can_upload` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_approve_tasks` tinyint(1) NOT NULL DEFAULT 0,
  `can_download` tinyint(1) NOT NULL DEFAULT 1,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `description`, `can_upload`, `can_edit`, `can_approve_tasks`, `can_download`, `is_admin`) VALUES
(1, 'System Admin', 'Full system access, configuration, and database backups', 1, 1, 1, 1, 1),
(2, 'Principal Secretary', 'Executive oversight of all department modules and approvals', 1, 1, 1, 1, 0),
(3, 'Directorate Head', 'Manages directorate projects, KPIs, and operational activities', 1, 1, 1, 1, 0),
(4, 'SAGA CEO', 'Heads a Semi-Autonomous Government Agency', 1, 1, 1, 1, 0),
(5, 'Project Manager', 'Manages assigned projects, Gantt milestones, and action points', 1, 1, 0, 1, 0),
(6, 'Officer', 'Standard data entry, records filing, and reporting', 1, 1, 0, 1, 0);

-- --------------------------------------------------------
-- Table structure for `directorates`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `directorates`;
CREATE TABLE `directorates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(20) NOT NULL,
  `head` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `directorates` (`id`, `name`, `code`, `head`, `description`) VALUES
(1, 'Directorate for Curative Services', 'CS', 'Dr. Peter Mwangi', 'Curative health and tertiary care services'),
(2, 'Directorate for Family Health', 'FH', 'Dr. Jane Kimani', 'Reproductive, maternal, newborn, child and adolescent health'),
(3, 'Directorate for Health Products and Technologies', 'HPT', 'Dr. Fredrick Ochieng', 'Pharmaceuticals, medical supplies and cold-chain supply chain'),
(4, 'Directorate for Policy, Digital Health and Innovations', 'PDHI', 'Eng. Kiprono Koech', 'E-Health, Digital Health Superhighway, m-Health, and data platforms'),
(5, 'Directorate for Kenya National Blood Tissues & Transfusion Services', 'KNBTTS', 'Dr. Angela Waweru', 'Blood safety, DAMU-KE, and human organ transplants');

-- --------------------------------------------------------
-- Table structure for `sagas`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sagas`;
CREATE TABLE `sagas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sagas` (`id`, `name`, `code`, `description`, `logo`) VALUES
(1, 'Kenya Medical Research Institute (KEMRI)', 'KEMRI', 'Medical research and vaccine innovation hub', 'assets/uploads/kemri.png'),
(2, 'Kenya Medical Supplies Authority (KEMSA)', 'KEMSA', 'Strategic medical logistics and supply chain', 'assets/uploads/kemsa-logo.png'),
(3, 'Kenyatta National Hospital (KNH)', 'KNH', 'National referral and specialized teaching hospital', 'assets/uploads/Kenya National Hospital.png'),
(4, 'Moi Teaching and Referral Hospital (MTRH)', 'MTRH', 'Western Kenya multi-specialty referral facility', 'assets/uploads/Moi Teaching and Referral Hospital.png'),
(5, 'Mathari National Teaching and Referral Hospital (MNTRH)', 'MNTRH', 'National specialized psychiatric and mental health hospital', 'assets/uploads/Mathari National Teaching.jpg'),
(6, 'Kenyatta University Teaching, Referral & Research Hospital (KUTRRH)', 'KUTRRH', 'National oncology, research and specialized care hospital', 'assets/uploads/KUTRRH.png'),
(7, 'Mwai Kibaki Referral Hospital (MKRH)', 'MKRH', 'Mt. Kenya regional annex hospital for specialized surgery', 'assets/uploads/MKRH.png'),
(8, 'Jaramogi Oginga Odinga Teaching and Referral Hospital (JOOTRH)', 'JOOTRH', 'Lake Basin regional referral and research hospital', 'assets/uploads/JOOTRH logo.png'),
(9, 'National Cancer Institute Kenya (NCIK)', 'NCIK', 'Cancer prevention, registration and early detection authority', 'assets/uploads/NCI-KENYA-LOGO.png'),
(10, 'National Syndemic Diseases Control Council (NSDCC)', 'NSDCC', 'Syndemic disease response, HIV, TB and viral hepatitis', 'assets/uploads/NSDCC.jpg'),
(11, 'Kenya National Blood Transfusion Service (KNBTS)', 'KNBTS', 'Safe blood and component services across all counties', 'assets/uploads/KNBTS.png'),
(12, 'National Spinal Injury Referral Hospital (NSIRH)', 'NSIRH', 'Specialized spinal rehabilitation and surgical care', 'assets/uploads/NSIRH.png');

-- --------------------------------------------------------
-- Table structure for `departments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departments` (`id`, `name`, `description`) VALUES
(1, 'Administration', 'General administrative functions and executive secretariat'),
(2, 'Finance & Planning', 'Budget coordination, exchequer allocations and accounting'),
(3, 'Human Resources', 'Personnel management and specialized health workforce capacity'),
(4, 'Operations & Logistics', 'Field inspections, logistics and facility maintenance'),
(5, 'ICT & Digital Health', 'Digital superhighway, HMIS, infrastructure and cybersecurity'),
(6, 'Legal & Regulatory', 'Compliance, statutory regulations and gazettements'),
(7, 'Communications & Public Affairs', 'Stakeholder engagement, media and public advisories');

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT 6,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Officer',
  `department` varchar(70) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `failed_login_attempts` int(11) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default password is 'ChangeMe@2026' hashed with bcrypt
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password_hash`, `full_name`, `role`, `department`, `phone`, `is_active`) VALUES
(1, 1, 'admin', 'admin@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'System Admin', 'ICT & Digital Health', '+254700000001', 1),
(2, 2, 'ps_medical', 'ps@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Harry Kimtai, CBS', 'Principal Secretary', 'Administration', '+254700000002', 1),
(3, 3, 'dir_curative', 'curative@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Peter Mwangi', 'Directorate Head', 'Curative Services', '+254700000003', 1),
(4, 3, 'dir_family', 'familyhealth@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Jane Kimani', 'Directorate Head', 'Family Health', '+254700000004', 1),
(5, 4, 'ceo_knh', 'ceo@knh.or.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Evanson Kamuri', 'SAGA CEO', 'Operations', '+254700000005', 1),
(6, 4, 'ceo_mtrh', 'ceo@mtrh.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. Philip Kirwa', 'SAGA CEO', 'Operations', '+254700000006', 1),
(7, 5, 'pm_infra', 'pm.infra@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Eng. Brian Johnson', 'Project Manager', 'Finance & Planning', '+254700000007', 1),
(8, 6, 'officer_records', 'records@health.go.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Emily Davis', 'Officer', 'Administration', '+254700000008', 1);

-- --------------------------------------------------------
-- Table structure for `flagships` (Priority Flagships)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `flagships`;
CREATE TABLE `flagships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `lead_directorate` varchar(150) NOT NULL,
  `progress_pct` int(11) NOT NULL DEFAULT 0,
  `risk_level` enum('Low','Medium','High','Severe') NOT NULL DEFAULT 'Medium',
  `priority_tier` enum('Critical','High','Medium','Low') NOT NULL DEFAULT 'High',
  `allocated_budget` decimal(15,2) DEFAULT 0.00,
  `utilized_budget` decimal(15,2) DEFAULT 0.00,
  `lead_officer` varchar(100) DEFAULT NULL,
  `team_name` varchar(100) DEFAULT NULL,
  `start_date` date NOT NULL,
  `target_date` date NOT NULL,
  `status` enum('Planning','In Progress','On Hold','Completed','Delayed') NOT NULL DEFAULT 'In Progress',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_flagship_risk` (`risk_level`),
  KEY `idx_flagship_priority` (`priority_tier`),
  KEY `idx_flagship_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `flagships` (`id`, `title`, `description`, `lead_directorate`, `progress_pct`, `risk_level`, `priority_tier`, `allocated_budget`, `utilized_budget`, `lead_officer`, `team_name`, `start_date`, `target_date`, `status`, `created_by`) VALUES
(1, 'Universal Health Coverage (UHC) Rollout', 'Nationwide implementation of the digital health superhighway, community health promoter digitization and Primary Care Networks.', 'Directorate for Policy, Digital Health and Innovations', 45, 'Medium', 'Critical', 45000000000.00, 18500000000.00, 'Dr. Timothy Wafula', 'Team UHC Delivery', '2023-07-01', '2026-12-31', 'In Progress', 1),
(2, 'Establishment of Regional Cancer Centres', 'Operationalizing comprehensive oncology diagnostic, radiotherapy and chemotherapy hubs in Kisii, Meru, Garissa and Nyeri.', 'National Cancer Institute Kenya (NCIK)', 25, 'High', 'Critical', 8000000000.00, 2140000000.00, 'Dr. Rose Njeru', 'Team Oncology', '2021-01-01', '2027-06-30', 'In Progress', 1),
(3, 'HIV Epidemic Control through NASCOP', 'Achieve 95-95-95 UNAIDS targets through universal access to ART, PMTCT elimination, and transitioning to local sustainable financing.', 'National Syndemic Diseases Control Council (NSDCC)', 94, 'Medium', 'Critical', 37641000000.00, 31500000000.00, 'Dr. Ruth Masha', 'NASCOP Steering Unit', '2021-07-01', '2026-12-31', 'In Progress', 1),
(4, 'Expansion of KNH Burns and Specialized Surgical Unit', 'Construction, equipping and staffing of modern 150-bed specialized Burns and Pediatric Care Centre with dedicated ICUs and surgical suites.', 'Kenyatta National Hospital (KNH)', 43, 'Low', 'High', 5459000000.00, 2350000000.00, 'Dr. Patrick Mwamburi', 'KNH Project Team', '2018-03-03', '2026-06-30', 'In Progress', 1),
(5, 'National Health Products Security & Local Manufacturing', 'Strategic buffer stock enhancement, KEMSA modernization, and establishing local human vaccine manufacturing via BIOVAX Institute.', 'Directorate for Health Products and Technologies', 35, 'High', 'High', 16400000000.00, 4800000000.00, 'Dr. Fredrick Ochieng', 'BIOVAX Taskforce', '2022-01-01', '2028-06-30', 'In Progress', 1);

-- --------------------------------------------------------
-- Table structure for `projects`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_code` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `remarks` text NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `type` enum('Project','Programme') DEFAULT 'Project',
  `category` enum('Directorate','Saga') DEFAULT 'Directorate',
  `directorate_id` int(11) DEFAULT NULL,
  `saga_id` int(11) DEFAULT NULL,
  `flagship_id` int(11) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('Planning','In Progress','Completed','On Hold','Cancelled','Delayed','Overdue') DEFAULT 'Planning',
  `progress_status` varchar(10) NOT NULL DEFAULT '0%',
  `total_budget` decimal(15,2) DEFAULT 0.00,
  `funds_disbursed` decimal(15,2) DEFAULT 0.00,
  `funds_utilized` decimal(15,2) DEFAULT 0.00,
  `progress_calculation_mode` enum('kpi_derived','manual') DEFAULT 'kpi_derived',
  `linked_sub_kpi_codes` varchar(255) DEFAULT 'C4.1,A3',
  `milestones_completed` int(11) DEFAULT 2,
  `milestones_total` int(11) DEFAULT 3,
  `tasks_on_track` int(11) DEFAULT 0,
  `tasks_total` int(11) DEFAULT 1,
  `gantt_task_name` varchar(255) DEFAULT 'Improve Viral Load Suppression Rate',
  `project_manager_id` int(11) DEFAULT NULL,
  `finance_officer_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `project_code` (`project_code`),
  KEY `directorate_id` (`directorate_id`),
  KEY `saga_id` (`saga_id`),
  KEY `flagship_id` (`flagship_id`),
  CONSTRAINT `fk_proj_dir` FOREIGN KEY (`directorate_id`) REFERENCES `directorates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_proj_saga` FOREIGN KEY (`saga_id`) REFERENCES `sagas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_proj_flg` FOREIGN KEY (`flagship_id`) REFERENCES `flagships` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `projects` (`id`, `project_code`, `title`, `description`, `remarks`, `location`, `type`, `category`, `directorate_id`, `saga_id`, `flagship_id`, `start_date`, `end_date`, `status`, `progress_status`, `total_budget`, `funds_disbursed`, `funds_utilized`, `progress_calculation_mode`, `linked_sub_kpi_codes`, `milestones_completed`, `milestones_total`, `tasks_on_track`, `tasks_total`, `gantt_task_name`, `created_by`) VALUES
(9, 'NASCOP-2026-001', 'National AIDS and STI Control Program (NASCOP)', 'National program for HIV/AIDS and STI prevention, treatment, and control. Key indicators include: People Living with HIV, On ART, and With Viral Load Suppression.\n\nNational program for HIV/AIDS and STI prevention, treatment, and control. Key indicators include: People Living with HIV, On ART, and With Viral Load Suppression.', 'Demo programme for Directorate of Family Health showing key HIV indicators. Targets: 100% coverage for PLHIV, 95% on ART, 95% viral load suppression.', 'Countrywide', 'Programme', 'Directorate', 1, NULL, 1, '2026-01-01', '2028-12-31', 'In Progress', '94%', 500000000.00, 350000000.00, 310000000.00, 'kpi_derived', 'C4.1,A3', 2, 3, 0, 1, 'Improve Viral Load Suppression Rate', 1),
(132, '1082100100', 'KNH Burns and Pediatrics Centre', 'Specialized burns management and pediatric inpatient facility', 'Funds essential to equip Burns centre having done slabs 1st through 4th floor.', 'Nairobi County', 'Project', 'Saga', NULL, 3, 4, '2018-03-03', '2026-06-30', 'In Progress', '43%', 5459000000.00, 2800000000.00, 2350000000.00, 'kpi_derived', 'C3.1,C3.3', 2, 3, 0, 1, 'Equip Burns ICU Suites', 1),
(133, '1082101100', 'Cancer & Chronic Disease Management Centre – MTRH', 'Multi-disciplinary oncology and chronic ailment facility for Western Kenya', 'Civil works progressing with bunker construction underway.', 'Uasin Gishu County', 'Project', 'Saga', NULL, 4, 2, '2013-01-07', '2028-06-30', 'In Progress', '38%', 1843000000.00, 920000000.00, 810000000.00, 'kpi_derived', 'C3.4,A3', 2, 3, 0, 1, 'Construct Oncology Bunkers', 1),
(134, '1082101400', 'Expansion and Equipping of ICU-MTRH', 'Expanding critical care bed capacity with state-of-the-art life support systems', 'ICU beds complete with cardiac monitors, suction and defibrillators delivered.', 'Uasin Gishu County', 'Project', 'Saga', NULL, 4, 1, '2015-07-01', '2026-12-01', 'In Progress', '65%', 439000000.00, 310000000.00, 285000000.00, 'kpi_derived', 'C3.1,A3', 2, 3, 0, 1, 'Procure ICU Life Support Systems', 1),
(135, '1082101200', 'Construction and Equipping Children Hospital- MTRH', 'Dedicated tertiary pediatric hospital including neonatal and pediatric ICU', 'Procuring medical equipment for Pediatric Burns Unit and surgical theatres.', 'Uasin Gishu County', 'Project', 'Saga', NULL, 4, 1, '2014-01-01', '2027-06-30', 'In Progress', '53%', 1080000000.00, 650000000.00, 572000000.00, 'kpi_derived', 'C3.3,A3', 2, 3, 0, 1, 'Equip Pediatric Operating Theaters', 1),
(136, '1082102400', 'Refurbishment and Replacement of Obsolete Equipment - KNH', 'Comprehensive overhaul of diagnostic imaging and clinical infrastructure at KNH', 'Replacement of MRI and CT systems completed in Phase 1.', 'Nairobi County', 'Project', 'Saga', NULL, 3, 4, '2021-01-07', '2027-06-30', 'In Progress', '29%', 8059000000.00, 2900000000.00, 2337000000.00, 'kpi_derived', 'D1,A3', 2, 3, 0, 1, 'Replace MRI & CT Scanning Systems', 1),
(137, '1082102500', 'Expansion of Comprehensive Cancer Centre - KUTRRH', 'Strengthening LINAC bunkers, PET-CT scanners and inpatient chemotherapy wards', 'Bunker 3 commissioning pending regulatory inspection by KNRA.', 'Nairobi County', 'Project', 'Saga', NULL, 6, 2, '2022-01-01', '2025-12-31', 'In Progress', '23%', 750000000.00, 320000000.00, 172500000.00, 'kpi_derived', 'C3.4,A3', 2, 3, 0, 1, 'Commission Third LINAC Bunker', 1),
(138, '1082100700', 'Renovation/Equipping Buildings - Mathari Hospital', 'Modern outpatient mental health department and forensic psychiatric unit', 'Completion of modern outpatient wing and rehabilitation workshops.', 'Nairobi County', 'Project', 'Saga', NULL, 5, 1, '2019-07-30', '2029-06-30', 'In Progress', '29%', 2950000000.00, 1100000000.00, 855000000.00, 'kpi_derived', 'B1,A3', 2, 3, 0, 1, 'Complete Outpatient Psychiatric Wing', 1),
(139, '1082100800', 'Perimeter Wall & Equipping at National Spinal Injury Hospital', 'Security enclosure, rehabilitation wards and robotic physiotherapy suites', 'Drainage and gate completed; physiotherapy equipment delivered.', 'Nairobi County', 'Project', 'Saga', NULL, 12, 1, '2014-07-30', '2027-06-30', 'In Progress', '22%', 1200000000.00, 420000000.00, 264000000.00, 'kpi_derived', 'D1,A3', 2, 3, 0, 1, 'Robotic Physiotherapy Suite Setup', 1),
(140, '1082101300', 'Equipping Maternity Unit (Mother & Baby Hospital - MTRH)', 'Delivery rooms, neonatal intensive care units and high dependency beds', 'Equipment delivered and installed in 4 delivery suites.', 'Uasin Gishu County', 'Project', 'Saga', NULL, 4, 1, '2014-07-01', '2026-06-01', 'In Progress', '43%', 350000000.00, 200000000.00, 150000000.00, 'kpi_derived', 'B1,A3', 2, 3, 0, 1, 'Install NICU Delivery Suites', 1),
(141, '1082101800', 'Strengthening of Cancer Management at KNH', 'LINAC radiotherapy system acquisition and specialized surgical oncology suite', 'Phase 2 finishes underway.', 'Nairobi County', 'Project', 'Saga', NULL, 3, 2, '2018-08-23', '2028-06-09', 'In Progress', '19%', 3656000000.00, 950000000.00, 694000000.00, 'kpi_derived', 'C3.4,A3', 2, 3, 0, 1, 'Deliver Surgical Oncology Suites', 1),
(144, '1082108600', 'Infrastructural Upgrade - JOOTRH', 'Hematology BMT centre, 50-bed ICU, Cath Lab Phase II and modern theatres', 'Site handover done; architectural working drawings approved.', 'Kisumu County', 'Project', 'Saga', NULL, 8, 1, '2025-07-01', '2030-06-30', 'In Progress', '5%', 6987000000.00, 500000000.00, 350000000.00, 'kpi_derived', 'C3.1,A3', 2, 3, 0, 1, 'Complete Cath Lab Phase II Civil Works', 1),
(145, '1082100300', 'East Africa Centre of Excellence for Urology & Nephrology', 'Regional tertiary referral, renal transplant and training complex', 'Civil structure 98% completed, external works finalizing.', 'Nairobi County', 'Project', 'Directorate', 1, NULL, 1, '2014-12-17', '2025-06-30', 'Completed', '91%', 3674000000.00, 3674000000.00, 3343000000.00, 'kpi_derived', 'C3.2,A3', 2, 3, 0, 1, 'Finalize Nephrology Complex Finishes', 1),
(146, '1082109900', 'National Equipment Service Programme (NESP)', 'Fee-for-service PPP medical equipment arrangement for all Level 4 & 5 hospitals', 'Transitioning from legacy MES to sustainable output-based PPP model.', 'Countrywide', 'Programme', 'Directorate', 1, NULL, 1, '2025-07-01', '2032-06-30', 'In Progress', '12%', 150000000000.00, 18000000000.00, 18000000000.00, 'kpi_derived', 'D1,A3', 2, 3, 0, 1, 'Sign County PPP Service MoUs', 1),
(147, '1082100500', 'Managed Equipment Service (MES) Contract Extension', 'Servicing and maintaining specialized diagnostic radiology across 98 hospitals', 'Settling pending bills and transition roadmap.', 'Countrywide', 'Programme', 'Directorate', 1, NULL, 1, '2015-10-07', '2028-10-07', 'In Progress', '73%', 79502000000.00, 61000000000.00, 58036000000.00, 'kpi_derived', 'D1,A3', 2, 3, 0, 1, 'Service Radiology Equipment in 98 Hospitals', 1),
(148, '1082106000', 'Acquisition of Specialized Medical Equipment CHP Kits', 'Kits and digital smartphones for 100,000 community health promoters countrywide', 'Kits procured and distributed to all 47 counties.', 'Countrywide', 'Programme', 'Directorate', 4, NULL, 1, '2024-07-01', '2028-06-30', 'In Progress', '25%', 26000000000.00, 7500000000.00, 6500000000.00, 'kpi_derived', 'C1.3,A3', 2, 3, 0, 1, 'Deliver Smartphones & Kits to 47 Counties', 1),
(149, '1082102100', 'Infrastructural Support to Kigumo Hospital', 'Modern Accident & Emergency centre, radiology, labs and surgical ward upgrade', 'A&E center construction 70% complete.', 'Muranga County', 'Project', 'Directorate', 1, NULL, 1, '2020-10-10', '2026-06-30', 'In Progress', '65%', 770000000.00, 540000000.00, 500500000.00, 'kpi_derived', 'B1,A3', 2, 3, 0, 1, 'Complete A&E Center Civil Construction', 1),
(152, '1082104300', 'Primary Health Care in Devolved Context', 'Level II and III facility readiness and Primary Care Network (PCN) operationalization', '45 Primary Care Networks operationalized across 28 counties.', 'Various Counties', 'Programme', 'Directorate', 2, NULL, 1, '2021-07-01', '2027-06-30', 'In Progress', '61%', 2935000000.00, 1950000000.00, 1790000000.00, 'kpi_derived', 'C1.1,A3', 2, 3, 0, 1, 'Operationalize 150 Primary Care Networks', 1),
(161, '1082100200', 'National Commodities Storage Center (KEMSA) Phase 2', 'Automated pharmaceutical warehouse and central distribution hub in Embakasi', 'Automated racking system installation in progress.', 'Nairobi County', 'Project', 'Saga', NULL, 2, 5, '2018-01-26', '2027-12-30', 'In Progress', '55%', 9572000000.00, 5800000000.00, 5264000000.00, 'kpi_derived', 'C2.1,A3', 2, 3, 0, 1, 'Install Automated High-Bay Racking', 1),
(162, '1082107703', 'Special Global Fund HIV Grant NFM3 - NASCOP', 'Commodity procurement of ARVs, viral load reagents and test kits', 'Maintaining buffer stocks at national level.', 'Countrywide', 'Programme', 'Saga', NULL, 10, 3, '2021-07-01', '2028-06-30', 'In Progress', '46%', 37641000000.00, 18500000000.00, 17314000000.00, 'kpi_derived', 'C4.1,A3', 2, 3, 0, 1, 'Commodity Buffer Security for ARVs', 1),
(166, '1082101000', 'Establishing Regional Cancer Centres (Meru, Bungoma, Marsabit)', 'Civil construction and oncology bunker installation in peripheral counties', 'Meru and Bungoma centers structurally complete.', 'Meru & Bungoma', 'Project', 'Saga', NULL, 9, 2, '2016-07-01', '2029-06-30', 'In Progress', '20%', 8000000000.00, 1900000000.00, 1600000000.00, 'kpi_derived', 'C3.4,A3', 2, 3, 0, 1, 'Commission Meru & Bungoma Bunkers', 1),
(175, '1082103000', 'Digital Health Platform - BETA', 'National HMIS integration, e-prescriptions and unified patient registry', 'Taifa Care deployed to 60 Level 4 & 5 hospitals.', 'Countrywide', 'Programme', 'Directorate', 4, NULL, 1, '2023-07-01', '2030-06-30', 'In Progress', '18%', 10000000000.00, 2400000000.00, 1800000000.00, 'kpi_derived', 'C1.2,B2', 2, 3, 0, 1, 'Integrate Taifa Care HIE Across Level 4-6', 1),
(176, '1082104400', 'Human Vaccine Production (BIOVAX)', 'Refurbishment of fill-and-finish cleanroom and formulation facility in Embakasi', 'GMP audit by WHO consultants conducted.', 'Nairobi County', 'Project', 'Saga', NULL, 1, 5, '2021-01-07', '2030-06-30', 'In Progress', '10%', 6400000000.00, 800000000.00, 640000000.00, 'kpi_derived', 'C2.2,A3', 2, 3, 0, 1, 'WHO GMP Cleanroom Certification', 1),
(181, '1082100600', 'Linda Mama Maternal Health Programme', 'Universal free maternity, ANC, skilled delivery and post-natal care for mothers', 'Migrating to Social Health Authority (SHA) maternal benefits package.', 'Countrywide', 'Programme', 'Directorate', 2, NULL, 1, '2013-07-10', '2028-07-10', 'In Progress', '67%', 70088000000.00, 52000000000.00, 46958000000.00, 'kpi_derived', 'B1,A3', 2, 3, 0, 1, 'Transition Maternal Claims to SHA', 1);

-- --------------------------------------------------------
-- Table structure for `action_points`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `action_points`;
CREATE TABLE `action_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `meeting_title` varchar(255) NOT NULL,
  `issue` text NOT NULL,
  `person_responsible` varchar(255) NOT NULL,
  `timeline` varchar(100) NOT NULL,
  `status` enum('ON TRACK','NOT STARTED','DELAYED','STALLED','COMPLETED','CANCELLED') NOT NULL DEFAULT 'NOT STARTED',
  `action` text NOT NULL,
  `resolution_notes` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ref_no` (`ref_no`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `action_points` (`id`, `ref_no`, `date`, `meeting_title`, `issue`, `person_responsible`, `timeline`, `status`, `action`, `resolution_notes`, `assigned_to`, `approved_by`, `approved_at`, `created_by`) VALUES
(1, 'NASCOP-APT-202602', '2026-01-25', 'NASCOP Quarterly Review Meeting', 'Viral load suppression at 94%, below 95% target in high-burden counties', 'NASCOP Program Manager', '2026-03-31', 'ON TRACK', 'Implement targeted adherence counseling and community support programs', 'Scale up viral load sample courier networks in ASAL counties.', 4, 2, '2026-02-03 15:11:00', 1),
(2, 'APT-20260120-327', '2026-01-20', 'Awareness Campaign Review', 'Create awareness on HIV testing and self-test kit distribution', 'Dan Mugo', '2026-02-28', 'NOT STARTED', 'Finalize mass media spot campaign and social mobilization tools', 'Pending procurement approval for printing materials.', 8, NULL, NULL, 1),
(3, 'APT-010', '2025-03-05', 'Risk Assessment Workshop', 'Address identified cyber security vulnerabilities in Taifa Care server', 'Jennifer Taylor', '10 days', 'DELAYED', 'Security patch deployment and penetration re-test', 'Vulnerability mitigated in staging environment; production scheduled for weekend maintenance.', 7, NULL, NULL, 1),
(4, 'APT-009', '2025-03-01', 'Financial Audit Meeting', 'Review quarterly expense reports and reconcile exchequer releases', 'James Miller', '2 days', 'COMPLETED', 'Report review and submit documentation to National Treasury', 'Reconciliation approved by Chief Finance Officer on March 3.', 5, 2, '2025-03-03 11:20:00', 1),
(5, 'APT-008', '2025-02-25', 'Strategic Planning Session', 'Implement new workflow processes for medical equipment service approval', 'Maria Garcia', '3 weeks', 'NOT STARTED', 'Process documentation and Directorate validation workshop', 'Awaiting PS approval of the revised circular.', 3, NULL, NULL, 1),
(6, 'APT-007', '2025-02-20', 'Quality Assurance Review', 'Update security protocols and access controls at KEMSA Embakasi store', 'David Wilson', '1 week', 'ON TRACK', 'Documentation update and physical security audit', 'Biometric turnstiles inspected and operational.', 7, NULL, NULL, 1),
(7, 'APT-006', '2025-02-15', 'Client Progress Meeting', 'Deliver Phase 1 prototype of Blood Transfusion Damu-KE App', 'Lisa Wang', '5 days', 'DELAYED', 'Prototype development and user acceptance testing', 'Delayed due to API integration with national citizen registry e-Citizen.', 7, NULL, NULL, 1),
(8, 'APT-005', '2025-02-10', 'Technical Review Board', 'Resolve server compatibility issues on LINAC radiation treatment stations', 'Robert Brown', '1 week', 'STALLED', 'Vendor coordination with Elekta engineers', 'Hardware part import delayed at customs in Mombasa.', 5, NULL, NULL, 1),
(9, 'APT-004', '2025-02-01', 'Stakeholder Consultation', 'Market research initiative for local medical gloves production', 'Emily Davis', '2 weeks', 'CANCELLED', 'Data collection replaced by UNIDO joint industrial study', 'Merged into UNIDO local manufacturing roadmap.', 8, 1, '2025-02-05 09:00:00', 1),
(10, 'APT-003', '2025-01-25', 'Team Progress Update', 'Complete user acceptance testing for KNH Burns ICU monitors', 'Mike Chen', '3 days', 'COMPLETED', 'Testing Phase completed with clinical staff sign-off', 'Tested by Head of Anesthesia and Certified Fit for Use.', 5, 2, '2025-01-28 14:00:00', 1),
(11, 'APT-002', '2025-01-20', 'Budget Review Session', 'Secure vendor quotations for equipment at Mathari hospital modern wing', 'Sarah Johnson', '1 week', 'ON TRACK', 'Vendor coordination and market price survey', 'Three compliant quotations received and forwarded to evaluation committee.', 7, NULL, NULL, 1),
(12, 'APT-001', '2025-01-15', 'SAGAs CEO Meeting with PS-SDMS', 'Pediatric Oncology Centre at MTRH: secure dedicated funding allocation', 'PS-SDMS, CEO MTRH', '4 weeks', 'STALLED', 'Treasury engagement for supplementary budget line item', 'Meeting with Principal Secretary National Treasury pending confirmation.', 2, NULL, NULL, 1),
(13, '1', '2025-01-01', 'KNH Executive Inspection', 'KNH bed capacity and patient congestion in emergency surgical admissions', 'Patrick Mwamburi', '2 weeks', 'NOT STARTED', 'Requisition raised for 50 additional overflow recovery beds', 'Awaiting delivery of approved beds from approved framework contract.', 5, NULL, NULL, 1);

-- --------------------------------------------------------
-- Table structure for `events` & `activities`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `event_type` enum('Field Visit','Ministerial Event','Executive Inspection','Meeting','Training','Other') NOT NULL DEFAULT 'Meeting',
  `event_date` date NOT NULL,
  `event_time` time DEFAULT '09:00:00',
  `location` varchar(200) DEFAULT NULL,
  `host` varchar(150) DEFAULT NULL,
  `attendees` text DEFAULT NULL,
  `status` enum('Upcoming','Ongoing','Completed','Cancelled') DEFAULT 'Upcoming',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `event_date` (`event_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `events` (`id`, `title`, `description`, `event_type`, `event_date`, `event_time`, `location`, `host`, `attendees`, `status`, `created_by`) VALUES
(1, 'Commissioning of KNH Modern Burns ICU', 'Official ribbon-cutting and technical handover of the specialized Burns unit.', 'Ministerial Event', '2026-04-15', '10:00:00', 'Kenyatta National Hospital, Nairobi', 'Cabinet Secretary & PS', 'PS-SDMS, CEO KNH, Health Parliamentary Committee, Media', 'Upcoming', 1),
(2, 'JOOTRH Radiotherapy Bunker Inspection', 'High-level inspection of ongoing structural works and radiation shielding at JOOTRH.', 'Field Visit', '2026-03-10', '09:30:00', 'JOOTRH, Kisumu', 'Principal Secretary', 'PS-SDMS, Governor Kisumu, CEO JOOTRH, Lead Radiation Physicist', 'Upcoming', 1),
(3, 'National Health Products Supply Chain Review', 'Quarterly consultative forum with County Health CECs and KEMSA leadership.', 'Meeting', '2026-03-24', '08:30:00', 'Safari Park Hotel, Nairobi', 'Director HPT', 'County CECs, KEMSA Board, Development Partners, Pharmacists Council', 'Upcoming', 1),
(4, 'Community Health Promoters Digitalization Review', 'Assessment of mobile phone sync rates, e-CHIS reporting and stipend disbursements.', 'Executive Inspection', '2026-02-28', '11:00:00', 'Nakuru County Referral Hospital', 'Principal Secretary', 'PS-SDMS, Nakuru Health Leadership, UNICEF Rep, WHO Rep', 'Completed', 1),
(5, 'World Tuberculosis Day Commemoration', 'National advocacy drive, screening camps and launch of shortened preventive regimen.', 'Ministerial Event', '2026-03-24', '09:00:00', 'Machakos Grounds', 'Cabinet Secretary', 'MOH Leadership, County Governors, USAID, Stop TB Partnership', 'Upcoming', 1);

-- --------------------------------------------------------
-- Table structure for `meetings` (Meeting Minutes)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `meetings`;
CREATE TABLE `meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `financier` varchar(200) DEFAULT 'Local & Donors',
  `financier_type` enum('Local','Foreign','Both') DEFAULT 'Both',
  `venue` varchar(200) DEFAULT 'Afya House, Boardroom 1',
  `attendees` text DEFAULT NULL,
  `agenda` text DEFAULT NULL,
  `decisions` text DEFAULT NULL,
  `document` varchar(500) DEFAULT NULL,
  `created_by` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `meetings` (`id`, `date`, `title`, `description`, `financier`, `financier_type`, `venue`, `attendees`, `agenda`, `decisions`, `document`) VALUES
(1, '2026-01-25', 'NASCOP Quarterly Review Meeting', 'Review of HIV indicator progress, transition financing roadmap and commodity supply security for ARVs.', 'The Global Fund (Foreign)', 'Foreign', 'Afya House, 6th Floor Boardroom', 'PS-SDMS, Head NASCOP, Global Fund Portfolio Manager, KEMSA CEO', '1. Q2 Viral Load suppression review\n2. ARV stock levels\n3. Transition budget co-financing', 'Agreed to allocate KES 1.2B supplementary budget for ARV buffer stocks. Accelerate Damu-KE integration.', 'meeting_minutes_nascop_2026.pdf'),
(2, '2026-01-20', 'Cancer Awareness Status & Regional Centers Meeting', 'Reviewing establishment milestones for oncology units in Meru and Garissa.', 'Local Exchequer & World Bank', 'Both', 'KUTRRH Executive Boardroom', 'CEO NCIK, CEO KUTRRH, Director Curative Services, Treasury Analyst', '1. Progress on radiation bunkers\n2. Nuclear regulatory licensing\n3. Oncologist deployment', 'Meru bunker approved for commissioning in May 2026. Fast-track IAEA safety clearance.', 'cancer_awareness_status_meeting.pdf'),
(3, '2026-01-05', 'Kisumu Hospital Project Deliverables Meeting', 'Harmonization of infrastructural deliverables and equipment procurement timelines for JOOTRH.', 'Exchequer / AfDB', 'Both', 'Kisumu County Headquarters', 'Governor Kisumu, PS-SDMS, JOOTRH Board Chair, Ministry Chief Engineer', '1. JOOTRH BMT Center construction schedule\n2. Equipment specifications\n3. Contractor pending payments', 'Interim certificate of KES 120M approved for immediate exchequer release to avoid contractor demobilization.', 'kisumu_hospital_deliverables_minutes.pdf'),
(4, '2026-01-02', 'Maternal Hospital Construction Meeting', 'Contractor review session for Maternal & Newborn wing upgrading.', 'VAMED-Finland (Foreign)', 'Foreign', 'Afya House Conference Hall B', 'Director Family Health, Finish Embassy Health Attaché, Project Engineer', '1. Shipping schedule for neonatal incubators\n2. Civil works completion\n3. Training of pediatric nurses', 'Consignment cleared through Mombasa port; installation starts next week.', 'maternal_hospital_construction_meeting.pdf'),
(5, '2025-12-22', 'Annual General Meeting 2025 - State Department', 'Annual departmental performance evaluation, audit responses and budget execution review.', 'Ministry of Health (Local)', 'Local', 'Kenya School of Government, Lower Kabete', 'CS, PS-SDMS, All Directorate Heads, All SAGA CEOs, Senior Registrars', '1. FY 2025/26 Mid-term Budget Review\n2. Performance Contract Evaluations\n3. Auditor General queries clearance', 'All SAGAs directed to submit clean audit trial balances by Jan 15.', 'annual_general_meeting_2025.pdf');

-- --------------------------------------------------------
-- Table structure for `reports` (Reports & System Data Approval Pipeline)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `module` varchar(100) NOT NULL DEFAULT 'Projects',
  `project_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `report_date` date NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size_kb` int(11) DEFAULT 1024,
  `visibility` enum('Public','Restricted','Confidential') NOT NULL DEFAULT 'Restricted',
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `uploaded_by` int(11) NOT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `review_comment` text DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `status` (`status`),
  KEY `visibility` (`visibility`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reports` (`id`, `report_code`, `title`, `module`, `project_id`, `description`, `report_date`, `file_path`, `file_name`, `file_size_kb`, `visibility`, `status`, `uploaded_by`, `reviewed_by`, `review_comment`, `reviewed_at`) VALUES
(1, 'REP-20260203-1604', 'NASCOP Quarterly HIV Indicators Report', 'Projects & Programmes', 162, 'Quarterly report showing progress on key HIV indicators, viral load suppression and transition financing.', '2026-03-31', 'reports/rep_nascop_q3_hiv.pdf', 'NASCOP_Q3_HIV_Indicators.pdf', 3450, 'Restricted', 'Pending', 1, NULL, NULL, NULL),
(2, 'REP-20260109-7639', 'HIV Grant Report (KEN-H-TNT-4147)', 'Finance & Grants', 164, 'Financial execution and procurement absorption report submitted to Global Fund Secretariat.', '2026-01-09', 'reports/rep_globalfund_financial.pdf', 'Global_Fund_Grant_Q2_Audit.pdf', 2180, 'Restricted', 'Approved', 1, 2, 'Financials verified and certified compliant with Grant Agreement covenants.', '2026-01-15 10:30:00'),
(3, 'REP-20260109-5077', 'Medical Equipment Report - Kigumo Hospital', 'Projects & Programmes', 149, 'Inspection report of newly installed diagnostic radiological equipment at Kigumo Level 4 Hospital.', '2026-01-09', 'reports/rep_kigumo_equipment.pdf', 'Kigumo_Equipment_Inspection_Report.pdf', 1840, 'Public', 'Pending', 1, NULL, NULL, NULL),
(4, 'REP-20260109-2733', 'Cancer Center Evaluation Report - Phase 1', 'Priority Flagships', 166, 'Comprehensive assessment of civil construction quality and bunker shielding at Meru and Marsabit.', '2026-01-09', 'reports/rep_cancer_eval_phase1.pdf', 'Regional_Cancer_Centres_Evaluation.pdf', 5420, 'Restricted', 'Pending', 1, NULL, NULL, NULL),
(5, 'REP-20260109-6038', 'Cancer Center Evaluation Report - KUTRRH', 'Projects & Programmes', 137, 'Techno-economic evaluation of PET-CT scanner throughput and cyclotron radiopharmaceutical synthesis.', '2026-01-09', 'reports/rep_kutrrh_cancer_eval.pdf', 'KUTRRH_PET_CT_Report.pdf', 4120, 'Public', 'Approved', 1, 2, 'Approved. Submit executive summary to Cabinet Secretary.', '2026-01-12 16:45:00'),
(6, 'REP-20260109-4505', 'Disability Awareness 2025 Report', 'Executive Policy', 139, 'Annual evaluation of assistive device provision and rehabilitation services for spinal injury patients.', '2026-01-07', 'reports/rep_disability_2025.pdf', 'National_Spinal_Injury_Annual_Report.pdf', 2980, 'Public', 'Approved', 1, 3, 'Approved for publication on ministerial web portal.', '2026-01-10 14:15:00'),
(7, 'REP-20260109-5640', 'Linda Mama 2025 Progress Report', 'Directorates', 181, 'Detailed breakdown of 1.2M successful facility-based deliveries and neonatal health outcomes.', '2026-01-06', 'reports/rep_lindamama_2025.pdf', 'Linda_Mama_Annual_Review.pdf', 3890, 'Public', 'Approved', 1, 2, 'Approved with commendation for reducing maternal mortality by 12%.', '2026-01-08 11:20:00'),
(8, 'REP-20260109-4823', 'Q4 Financial Analysis - Linda Mama Programme', 'Finance & Grants', 181, 'Reconciliation of hospital reimbursement claims and pending bills submitted to NHIF/SHA.', '2026-01-08', 'reports/rep_lindamama_q4_finance.pdf', 'Q4_Financial_Analysis_Linda_Mama.pdf', 1560, 'Confidential', 'Pending', 1, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Table structure for `diary`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `diary`;
CREATE TABLE `diary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `entry_date` date NOT NULL,
  `entry_time` time DEFAULT '09:00:00',
  `category` enum('Meeting','Task','Deadline','Event','General') DEFAULT 'General',
  `priority` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `entry_date` (`entry_date`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `diary` (`id`, `title`, `content`, `entry_date`, `entry_time`, `category`, `priority`, `created_by`) VALUES
(1, 'Meeting with National Treasury on Health Grants', 'Consultation with Budget Controller on cash flow releases for Global Fund and NESP projects.', '2026-03-02', '10:00:00', 'Meeting', 'Critical', 1),
(2, 'Submission Deadline: Quarterly PC Targets', 'Deadline for all 5 Directorates and 12 SAGAs to upload validated Q3 Performance Contract achievements.', '2026-03-31', '17:00:00', 'Deadline', 'High', 1),
(3, 'Field Inspection: KEMRI Kombewa Laboratory', 'Technical inspection team visits newly installed biosafety level 3 pediatric infectious disease lab in Kisumu.', '2026-03-15', '09:00:00', 'Task', 'Medium', 1),
(4, 'Executive Briefing with Health Committee', 'Parliamentary session to respond to queries on Linda Mama transitions and Social Health Authority roll-out.', '2026-03-19', '14:30:00', 'Meeting', 'High', 1),
(5, 'World Oral Health Day Launch', 'National campaign launch on mercury-free dental health policy in Nairobi schools.', '2026-03-20', '08:30:00', 'Event', 'Low', 1);

-- --------------------------------------------------------
-- Table structure for `performance_contracts` (PC Module)
-- Populated from the attached PDF
-- --------------------------------------------------------
DROP TABLE IF EXISTS `performance_contracts`;
CREATE TABLE `performance_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL DEFAULT 'A1',
  `category` varchar(100) NOT NULL DEFAULT 'Core Mandate',
  `parent_kpi_name` varchar(255) DEFAULT NULL,
  `parent_kpi_code` varchar(20) DEFAULT NULL,
  `category_weight` decimal(5,2) DEFAULT 10.00,
  `sub_kpi_weight` decimal(5,2) DEFAULT 2.00,
  `delivery_unit` varchar(150) NOT NULL,
  `programme` varchar(150) NOT NULL,
  `sub_programme` varchar(150) DEFAULT NULL,
  `key_outputs` text NOT NULL,
  `kpi_name` text NOT NULL,
  `baseline_score` varchar(50) DEFAULT NULL,
  `target_2025_26` varchar(50) DEFAULT NULL,
  `actual_2025_26` varchar(50) DEFAULT NULL,
  `target_baseline_2026_27` varchar(50) DEFAULT NULL,
  `target_2027_28` varchar(50) DEFAULT NULL,
  `target_2028_29` varchar(50) DEFAULT NULL,
  `target_2029_30` varchar(50) DEFAULT NULL,
  `q1_score` decimal(5,2) DEFAULT 0.00,
  `q2_score` decimal(5,2) DEFAULT 0.00,
  `q3_score` decimal(5,2) DEFAULT 0.00,
  `q4_score` decimal(5,2) DEFAULT 0.00,
  `weight` decimal(5,2) DEFAULT 5.00,
  `current_achievement` decimal(5,2) DEFAULT 0.00,
  `variance_comment` text DEFAULT NULL,
  `status` enum('Draft','Submitted','Reviewed','Approved') DEFAULT 'Approved',
  `financial_year` varchar(20) DEFAULT '2026/2027',
  `created_by` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pc_code` (`code`),
  KEY `idx_pc_category` (`category`),
  KEY `idx_pc_unit` (`delivery_unit`),
  KEY `idx_pc_fy` (`financial_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `performance_contracts` (`id`, `code`, `category`, `parent_kpi_name`, `parent_kpi_code`, `category_weight`, `sub_kpi_weight`, `delivery_unit`, `programme`, `key_outputs`, `kpi_name`, `baseline_score`, `target_2025_26`, `actual_2025_26`, `target_baseline_2026_27`, `target_2027_28`, `q1_score`, `q2_score`, `q3_score`, `q4_score`, `weight`, `current_achievement`, `variance_comment`, `status`, `financial_year`) VALUES
(1, 'A1', 'Financial Stewardship', 'Financial Stewardship & Fiscal Discipline', 'A', 10, 2, 'Directorate of Finance & Accounts', 'Programme 5: General Administration & Financial Services', '100% absorption of exchequer releases for GoK development & recurrent votes', 'Absorption of Allocated Funds (GoK)', '96.94%', '100%', '96.94%', '100%', '100%', 96, 97, 98, 98.5, 2, 97.4, 'GoK exchequer releases timely; absorption accelerated in development expenditure votes.', 'Approved', '2026/2027'),
(2, 'A2', 'Financial Stewardship', 'Financial Stewardship & Fiscal Discipline', 'A', 10, 2, 'SAGAs & National Referral Facilities (KNH, MTRH, KUTRRH)', 'Programme 5: General Administration & Financial Services', 'Internal revenue collection generated and absorbed in line with PFM Act', 'Appropriation-In-Aid (A-in-A) Collection & Absorption', '94.50%', '100%', '94.50%', '100%', '100%', 92, 94, 95.5, 96, 2, 94.4, 'Revenue streams automated through digital payment gateway integration with e-Citizen.', 'Approved', '2026/2027'),
(3, 'A3', 'Financial Stewardship', 'Financial Stewardship & Fiscal Discipline', 'A', 10, 3, 'Directorate of Planning & External Health Financing', 'Programme 5: General Administration & Financial Services', '100% absorption of multilateral and bilateral partner health allocations', 'Absorption of Externally Mobilized Funds (Donor & Partner Grants)', '88.20%', '100%', '88.20%', '100%', '100%', 85, 87, 90, 92, 3, 88.5, 'Grant drawdown accelerated; procurement plans aligned with Global Fund NFM3 cycle.', 'Approved', '2026/2027'),
(4, 'A4', 'Financial Stewardship', 'Financial Stewardship & Fiscal Discipline', 'A', 10, 3, 'Finance & Accounts, Procurement Division', 'Programme 5: General Administration & Financial Services', 'Progressive reduction and clearance of eligible verified supplier & contractor pending bills', 'Pending Bills Ratio & Historical Debt Settlement', '91.00%', '100%', '91.00%', '100%', '100%', 88, 90, 92.5, 94, 3, 91.1, 'Dedicated first-in-first-out pending bills liquidation matrix deployed with National Treasury.', 'Approved', '2026/2027'),
(5, 'B1', 'Service Delivery', 'Service Delivery & Public Engagement', 'B', 10, 5, 'Directorate of Administration & Public Communications', 'Programme 5: General Administration & Financial Services', 'Full compliance with published service response timelines and citizen charter standards', 'Implementation of Citizen Service Delivery Charter', '95.00%', '100%', '95.00%', '100%', '100%', 94, 96, 98, 98.5, 5, 96.6, 'Customer feedback desks operationalized at Afya House and regional referral hospital entrances.', 'Approved', '2026/2027'),
(6, 'B2', 'Service Delivery', 'Service Delivery & Public Engagement', 'B', 10, 5, 'Directorate of Health Informatics & Digital Health', 'Programme 5: General Administration & Financial Services', '100% onboarding of ministerial licensing, permits, and correspondence to e-Citizen', 'Digitalization of Government Services & End-to-End Automation', '80.00%', '100%', '80.00%', '100%', '100%', 82, 86, 90, 92.5, 5, 87.6, 'Electronic document management system integrated with GOK e-Citizen portal and Taifa Care.', 'Approved', '2026/2027'),
(7, 'C1.1', 'Core Mandate', 'Universal Health Coverage & Primary Health Care Networks', 'C1', 60, 5, 'Primary Healthcare Directorate', 'Programme 2: Primary Health Care', 'Established and fully operational Primary Care Networks connecting Level 2/3 to Level 4 hubs', 'Operationalization of Primary Care Networks (PCNs)', '45 PCNs', '150 PCNs', '120 PCNs', '315 PCNs', '315 PCNs', 70, 74, 78, 82, 5, 76, '185 PCNs currently operational; county health team sensitization underway in high-burden counties.', 'Approved', '2026/2027'),
(8, 'C1.2', 'Core Mandate', 'Universal Health Coverage & Primary Health Care Networks', 'C1', 60, 5, 'Directorate of Health Informatics & Digital Health', 'Programme 2: Primary Health Care', 'Deployment of standardized enterprise EHR software across Level 4, 5, and 6 referral facilities', 'Afya Care UHC Digitization & Electronic Health Records (EHR)', '60 facilities', '80 facilities', '68 facilities', '100% Facilities', '100% Facilities', 60, 65, 68, 70, 5, 65.8, 'National Health Information Exchange (HIE) integration progressing with SHA claims system.', 'Approved', '2026/2027'),
(9, 'C1.3', 'Core Mandate', 'Universal Health Coverage & Primary Health Care Networks', 'C1', 60, 5, 'Community Health Directorate', 'Programme 2: Primary Health Care', '100,000 equipped, trained and digitized Community Health Promoters reporting on e-CHIS', 'Community Health Promoters (CHP) Kits & Digital Registry', '80,000 Promoters', '100,000 Promoters', '98,500 Promoters', '100,000 Promoters', '100,000 Promoters', 90, 92, 94, 95, 5, 92.8, 'Diagnostic kits and smartphones distributed across 47 counties; stipends paid on time.', 'Approved', '2026/2027'),
(10, 'C2.1', 'Core Mandate', 'Access to Health Products & Technologies (HPT)', 'C2', 60, 6, 'Kenya Medical Supplies Authority (KEMSA)', 'Programme 3: Medical Commodities Security', 'Timely order fulfillment and turnaround reduction for health facilities nationwide', 'Percentage Order Fill Rate for Essential Health Packages (KEMSA)', '81.0%', '85.0%', '81.0%', '90.0%', '95.0%', 84, 89, 93, 95.2, 6, 90.3, 'Turnaround cut from 23 to 10 days; Kisumu and Mombasa regional distribution hubs active.', 'Approved', '2026/2027'),
(11, 'C2.2', 'Core Mandate', 'Access to Health Products & Technologies (HPT)', 'C2', 60, 5, 'Directorate of Health Products and Technologies (HPT)', 'Programme 3: Medical Commodities Security', 'Zero stockouts of critical tracer medicines, EPI vaccines, and emergency trauma kits', 'Buffer Stock Availability of Vital Commodities & Vaccines', '85.0%', '90.0%', '87.0%', '95.0%', '98.0%', 80, 84, 86, 88, 5, 84.5, 'National vaccine security fund maintained; buffer stocks at 6 months threshold.', 'Approved', '2026/2027'),
(12, 'C2.3', 'Core Mandate', 'Access to Health Products & Technologies (HPT)', 'C2', 60, 4, 'Directorate of Health Products and Technologies (HPT)', 'Programme 3: Medical Commodities Security', 'Promulgation of national essential medicine list and medical device standard regulations', 'Percentage Completion of National HPT Policies & Formulary Guidelines', '40.0%', '60.0%', '60.0%', '100.0%', '100.0%', 90, 95, 98, 100, 4, 95.8, 'Public stakeholder consultation finalized; awaiting cabinet policy memorandum approval.', 'Approved', '2026/2027'),
(13, 'C3.1', 'Core Mandate', 'Specialized Healthcare Services & Referral Facilities', 'C3', 60, 4, 'Kenyatta National Hospital & KUTRRH', 'Programme 1: National Referral Facilities', 'Specialized adult and pediatric cardiothoracic and open-heart surgical interventions', 'Number of Heart and Cardiothoracic Surgeries Conducted', '630 Surgeries', '784 Surgeries', '630 Surgeries', '850 Surgeries', '920 Surgeries', 88, 90, 92, 94, 4, 91, 'Surgical suites operating double shifts to reduce national cardiothoracic waitlist.', 'Approved', '2026/2027'),
(14, 'C3.2', 'Core Mandate', 'Specialized Healthcare Services & Referral Facilities', 'C3', 60, 4, 'Kenyatta National Hospital Renal Center & MTRH', 'Programme 1: National Referral Facilities', 'Living donor renal transplants and post-operative immunosuppression management', 'Number of Kidney Transplants Conducted', '22 Transplants', '24 Transplants', '22 Transplants', '30 Transplants', '36 Transplants', 85, 90, 95, 95, 4, 91.3, 'Tissue matching laboratories calibrated with Kenya Tissue and Transplant Authority.', 'Approved', '2026/2027'),
(15, 'C3.3', 'Core Mandate', 'Specialized Healthcare Services & Referral Facilities', 'C3', 60, 4, 'KNH, MTRH, JOOTRH', 'Programme 1: National Referral Facilities', 'Endoscopic, laparoscopic, and keyhole surgeries reducing patient average stay', 'Number of Minimally Invasive & Laparoscopic Surgeries', '13,370 Surgeries', '13,916 Surgeries', '13,370 Surgeries', '14,400 Surgeries', '15,200 Surgeries', 92, 95, 98, 98, 4, 95.8, 'Modern theater laparoscopic towers delivered to MTRH and JOOTRH referral facilities.', 'Approved', '2026/2027'),
(16, 'C3.4', 'Core Mandate', 'Specialized Healthcare Services & Referral Facilities', 'C3', 60, 3, 'KUTRRH Oncology Center & Regional Cancer Centers', 'Programme 1: National Referral Facilities', 'High-precision robotic stereotactic radiosurgery and cancer radiotherapy sessions', 'Oncology CyberKnife, PET-CT and Radiotherapy Sessions', '12,685 Sessions', '48,846 Sessions', '12,685 Sessions', '48,000 Sessions', '52,000 Sessions', 82, 86, 90, 92, 3, 87.5, 'Regional bunker commissioning in Garissa and Nakuru expanding oncology coverage.', 'Approved', '2026/2027'),
(17, 'C4.1', 'Core Mandate', 'Communicable & Non-Communicable Disease Control', 'C4', 60, 8, 'NASCOP & NSDCC', 'Programme 4: Communicable Disease Control', '95-95-95 UNAIDS targets: sustained antiretroviral therapy and viral suppression', 'People Living with HIV Currently Receiving Sustained ART', '1,310,000 Clients', '1,325,522 Clients', '1,310,000 Clients', '1,350,000 Clients', '1,380,000 Clients', 96, 97, 98, 98.8, 8, 97.5, 'Viral load suppression sustained at 96.2% across all 47 counties.', 'Approved', '2026/2027'),
(18, 'C4.2', 'Core Mandate', 'Communicable & Non-Communicable Disease Control', 'C4', 60, 7, 'Kenya National Blood Transfusion Service (KNBTS)', 'Programme 4: Communicable Disease Control', 'Safe, screened voluntary blood units mobilized and distributed to county blood banks', 'Units of Whole Blood Collected and Screened via Damu-KE', '312,000 Units', '350,000 Units', '312,000 Units', '400,000 Units', '450,000 Units', 80, 85, 88, 89.1, 7, 85.5, 'School donation drives and Damu-KE mobile app mobilization launched nationwide.', 'Approved', '2026/2027'),
(19, 'D1', 'Cross-Cutting', 'Cross-Cutting & Institutional Strengthening', 'D', 20, 5, 'Directorate of Health Infrastructure & Referral Facilities', 'Programme 5: General Administration & Infrastructure', '98% equipment uptime across national referral and Level 4/5 hospitals', 'Asset Management & Medical Equipment Maintenance (NESP/MES)', '73.0%', '80.0%', '73.0%', '100.0%', '100.0%', 82, 85, 88, 90, 5, 86.3, 'Preventive maintenance schedule active; biomedical engineers stationed regionally.', 'Approved', '2026/2027'),
(20, 'D2', 'Cross-Cutting', 'Cross-Cutting & Institutional Strengthening', 'D', 20, 5, 'Internal Audit Directorate & Ministerial Ethics Committee', 'Programme 5: General Administration & Infrastructure', '100% implementation of Auditor General recommendations and EACC compliance', 'Corruption Prevention, Ethical Standards & Statutory Audits', '90.0%', '100.0%', '90.0%', '100.0%', '100.0%', 90, 92, 95, 96, 5, 93.3, 'Quarterly internal audits conducted across all directorates and SAGAs.', 'Approved', '2026/2027'),
(21, 'D3', 'Cross-Cutting', 'Cross-Cutting & Institutional Strengthening', 'D', 20, 5, 'Public Complaints Committee & Public Communications', 'Programme 5: General Administration & Infrastructure', 'Timely investigation, resolution, and reporting of citizen grievances within 14 days', 'Resolution of Public Complaints (CAJ Ombudsman Guidelines)', '92.0%', '100.0%', '92.0%', '100.0%', '100.0%', 92, 94, 97, 98, 5, 95.3, '98% of lodged complaints investigated and resolved within statutory limit.', 'Approved', '2026/2027'),
(22, 'D4', 'Cross-Cutting', 'Cross-Cutting & Institutional Strengthening', 'D', 20, 5, 'Human Resource Management & Social Inclusion Directorate', 'Programme 5: General Administration & Infrastructure', '5% progressive recruitment of PWDs, 30% AGPO procurement compliance, and gender parity', 'National Cohesion, Disability & Gender Mainstreaming', '85.0%', '100.0%', '85.0%', '100.0%', '100.0%', 88, 90, 92, 94, 5, 91, 'AGPO youth and women access to ministerial tenders monitored monthly.', 'Approved', '2026/2027');

-- --------------------------------------------------------
-- Table structure for `visitors`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `visitors`;
CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_name` varchar(150) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `purpose` text NOT NULL,
  `host_name` varchar(150) NOT NULL,
  `host_department` varchar(100) NOT NULL,
  `badge_number` varchar(50) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime DEFAULT NULL,
  `status` enum('Checked In','Checked Out') NOT NULL DEFAULT 'Checked In',
  `created_by` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vis_status` (`status`),
  KEY `idx_vis_badge` (`badge_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `visitors` (`id`, `visitor_name`, `id_number`, `phone`, `email`, `organization`, `purpose`, `host_name`, `host_department`, `badge_number`, `check_in`, `check_out`, `status`) VALUES
(1, 'Erick Agutu', '25962998', '0757642930', 'agootoo@gmail.com', 'Syntech Digital', 'Project Proposal Submittance for Health Management System', 'Dr. Harry Kimtai, CBS', 'Administration', 'V-042', '2026-02-10 09:30:00', '2026-02-10 11:45:00', 'Checked Out'),
(2, 'Dr. Sarah Ndwiga', '31284712', '0722334455', 'sndwiga@kemri.go.ke', 'KEMRI Vaccine Division', 'Joint clinical trial roadmap with Director Curative Services', 'Dr. Peter Mwangi', 'Curative Services', 'V-019', '2026-03-24 08:45:00', NULL, 'Checked In'),
(3, 'Mark Omondi', '29871142', '0711448822', 'momondi@who.int', 'World Health Organization', 'Cold-chain audit documentation briefing', 'Dr. Fredrick Ochieng', 'Health Products & Technologies', 'V-088', '2026-03-24 09:15:00', NULL, 'Checked In'),
(4, 'Grace Mutua', '27445511', '0733882211', 'gmutua@usaid.gov', 'USAID Global Health', 'Review of Family Health bilateral grants', 'Dr. Jane Kimani', 'Family Health', 'V-104', '2026-03-23 14:00:00', '2026-03-23 16:30:00', 'Checked Out');

-- --------------------------------------------------------
-- Table structure for `mail_records`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `mail_records`;
CREATE TABLE `mail_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracking_number` varchar(100) NOT NULL,
  `direction` enum('Incoming','Outgoing') NOT NULL DEFAULT 'Incoming',
  `sender_name` varchar(200) NOT NULL,
  `sender_address` text DEFAULT NULL,
  `recipient_name` varchar(200) NOT NULL,
  `recipient_department` varchar(100) DEFAULT NULL,
  `mail_type` enum('Letter','Document','Invoice','Circular','Notice','Package') DEFAULT 'Document',
  `priority` enum('Low','Normal','High','Urgent') DEFAULT 'Normal',
  `subject` text NOT NULL,
  `received_date` datetime NOT NULL,
  `received_by` varchar(100) NOT NULL,
  `scanned_file_path` varchar(500) DEFAULT NULL,
  `status` enum('Received','Pending Dispatch','Dispatched','Archived','Returned') DEFAULT 'Received',
  `created_by` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_number` (`tracking_number`),
  KEY `status` (`status`),
  KEY `direction` (`direction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mail_records` (`id`, `tracking_number`, `direction`, `sender_name`, `sender_address`, `recipient_name`, `recipient_department`, `mail_type`, `priority`, `subject`, `received_date`, `received_by`, `scanned_file_path`, `status`) VALUES
(1, 'MOH/ADM/2026/0412', 'Incoming', 'The National Treasury', 'Treasury Building, Harambee Ave', 'Principal Secretary - SDMS', 'Administration', 'Circular', 'Urgent', 'Exchequer Release Schedule for Q3 FY 2025/2026 Development Vote', '2026-02-18 10:15:00', 'Emily Davis', 'mail/circular_treasury_q3.pdf', 'Received'),
(2, 'MOH/SDMS/OUT/2026/089', 'Outgoing', 'Principal Secretary - SDMS', 'Afya House, Cathedral Rd', 'Chief Executive Officer, KEMSA', 'External - SAGA', 'Letter', 'High', 'Directive on Immediate Distribution of Essential Tracer Oncology Medicines', '2026-02-22 14:30:00', 'Emily Davis', 'mail/directive_kemsa_oncology.pdf', 'Dispatched'),
(3, 'MOH/ADM/2026/0415', 'Incoming', 'World Health Organization (AFRO)', 'UN Complex, Gigiri, Nairobi', 'Head, National Vaccines and Immunization Program', 'Family Health', 'Document', 'Normal', 'Technical Guidance on Introduction of Novel Hexavalent Pediatric Vaccine', '2026-03-01 11:20:00', 'Emily Davis', 'mail/who_vaccine_guidance.pdf', 'Received');

-- --------------------------------------------------------
-- Table structure for `audit_logs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) DEFAULT '127.0.0.1',
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_module` (`module`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `username`, `action`, `module`, `entity_id`, `description`, `ip_address`, `user_agent`) VALUES
(1, 1, 'System Administrator', 'login_success', 'auth', 1, 'User admin logged in successfully', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(2, 1, 'System Administrator', 'create', 'projects', 146, 'Created new Project: National Equipment Service Programme (NESP)', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(3, 2, 'Principal Secretary', 'approve', 'reports', 2, 'Approved Report #2: HIV Grant Report (KEN-H-TNT-4147)', '102.219.208.5', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0)'),
(4, 1, 'System Administrator', 'update', 'action_points', 1, 'Updated action point #1: Viral load suppression target', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(5, 1, 'System Administrator', 'create', 'flagships', 1, 'Configured UHC Rollout flagship milestone and risk rating', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(6, 2, 'Principal Secretary', 'approve', 'action_points', 4, 'Marked Action Point #4 as COMPLETED with resolution notes', '102.219.208.5', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0)'),
(7, 1, 'System Administrator', 'backup', 'admin', 1, 'Generated full SQL snapshot backup: ppsdms_backup_2026-03-24_01-48.sql', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(8, 1, 'System Administrator', 'update', 'pc', 1, 'Updated KNH Heart Surgeries Q4 achievement scores to 91.00%', '196.201.214.18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');

-- --------------------------------------------------------
-- Table structure for `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','danger') DEFAULT 'info',
  `link_module` varchar(50) DEFAULT 'dashboard',
  `link_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `link_module`, `link_id`, `is_read`) VALUES
(1, 1, 'Pending Report Approval', 'NASCOP Quarterly HIV Indicators Report (REP-20260203-1604) requires review.', 'warning', 'reports', 1, 0),
(2, 1, 'Stalled Action Point', 'Action Point APT-001 (Pediatric Oncology funding at MTRH) is STALLED and overdue.', 'danger', 'actions', 12, 0),
(3, 1, 'Upcoming Ministerial Event', 'Commissioning of KNH Burns ICU scheduled for next month.', 'info', 'events', 1, 0),
(4, 1, 'Performance Contract Review', 'Q3 Performance Contract submissions are ready for Directorate validation.', 'success', 'pc', 1, 0),
(5, 1, 'Visitor Checked In', 'Dr. Sarah Ndwiga from KEMRI is currently checked in at Afya House (Badge V-019).', 'info', 'visitors', 2, 0);

-- --------------------------------------------------------
-- Table structure for `settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `org_name` varchar(200) NOT NULL DEFAULT 'Ministry of Health — State Department for Medical Services',
  `app_title` varchar(150) NOT NULL DEFAULT 'PP-SDOMS Performance Management Dashboard',
  `backup_path` varchar(255) NOT NULL DEFAULT 'backups/',
  `https_enforced` tinyint(1) NOT NULL DEFAULT 1,
  `max_upload_mb` int(11) NOT NULL DEFAULT 20,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `org_name`, `app_title`, `backup_path`, `https_enforced`, `max_upload_mb`) VALUES
(1, 'Ministry of Health — State Department for Medical Services', 'PP-SDOMS Performance Management Dashboard', 'backups/', 1, 20);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
