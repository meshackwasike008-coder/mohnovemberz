<?php
/**
 * Root Bridge: Key Activities & Events
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/events.php';
