<?php
/**
 * Root Bridge: Visitors Logbook
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/visitors.php';
