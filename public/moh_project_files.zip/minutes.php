<?php
/**
 * Root Bridge: Meeting Minutes
 */
declare(strict_types=1);
require_once __DIR__ . '/modules/minutes.php';
