<?php
/**
 * Executive Dashboard
 */
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
require_login();

$db = db();

// Query summary statistics
$stats = [
    'flagships' => (int)$db->query("SELECT COUNT(*) FROM flagships")->fetchColumn(),
    'projects' => (int)$db->query("SELECT COUNT(*) FROM projects")->fetchColumn(),
    'active_projects' => (int)$db->query("SELECT COUNT(*) FROM projects WHERE status = 'In Progress'")->fetchColumn(),
    'total_budget' => (float)$db->query("SELECT SUM(total_budget) FROM projects")->fetchColumn(),
    'open_actions' => (int)$db->query("SELECT COUNT(*) FROM action_points WHERE status NOT IN ('COMPLETED', 'CANCELLED')")->fetchColumn(),
    'pending_reports' => (int)$db->query("SELECT COUNT(*) FROM reports WHERE status = 'Pending'")->fetchColumn(),
    'upcoming_events' => (int)$db->query("SELECT COUNT(*) FROM events WHERE status = 'Upcoming'")->fetchColumn(),
    'active_visitors' => (int)$db->query("SELECT COUNT(*) FROM visitors WHERE status = 'Checked In'")->fetchColumn(),
];

// Project status distribution
$statusRows = $db->query("SELECT status, COUNT(*) as cnt FROM projects GROUP BY status")->fetchAll();
$statusLabels = array_column($statusRows, 'status');
$statusCounts = array_map('intval', array_column($statusRows, 'cnt'));

// Flagship risk distribution
$riskRows = $db->query("SELECT risk_level, COUNT(*) as cnt FROM flagships GROUP BY risk_level")->fetchAll();
$riskLabels = array_column($riskRows, 'risk_level');
$riskCounts = array_map('intval', array_column($riskRows, 'cnt'));

// 6 Most Recent Action Points
$recentActions = $db->query("SELECT * FROM action_points ORDER BY id DESC LIMIT 6")->fetchAll();

// 8 Most Recent Audit Logs
$recentAudits = $db->query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 8")->fetchAll();

$renderContent = function() use ($stats, $statusLabels, $statusCounts, $riskLabels, $riskCounts, $recentActions, $recentAudits) {
?>
<div class="container-fluid px-0">
    
    <!-- Title Banner -->
    <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(90deg, #1976d2 0%, #0d47a1 100%); color: #fff;">
        <div class="card-body p-3 px-4 d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold text-uppercase tracking-wider" style="font-size: 1.15rem; letter-spacing: 0.05em;">
                <i class="fa-solid fa-gauge-high me-2"></i> Performance Management Dashboard
            </h4>
            <span class="badge bg-light text-primary fw-bold px-3 py-2">
                FY 2025/2026 Active Quarter
            </span>
        </div>
    </div>

    <!-- Quick Access Section (Exact layout matching screenshot page 4) -->
    <div class="mb-4">
        <h6 class="text-uppercase fw-bold text-secondary mb-3 small d-flex align-items-center gap-2">
            <i class="fa-solid fa-table-cells-large text-primary"></i> Quick Access
        </h6>
        <div class="row g-3">
            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/flagships.php" class="quick-access-card">
                    <i class="fa-solid fa-list-check"></i>
                    <div>
                        <div class="quick-access-title">Priority Flagships</div>
                        <div class="quick-access-desc">Track Priority Flagships</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/projects.php" class="quick-access-card">
                    <i class="fa-solid fa-diagram-project"></i>
                    <div>
                        <div class="quick-access-title">Projects &amp; Programmes</div>
                        <div class="quick-access-desc">Manage all projects and programmes</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/events.php" class="quick-access-card">
                    <i class="fa-solid fa-calendar-check"></i>
                    <div>
                        <div class="quick-access-title">Upcoming Key Activities</div>
                        <div class="quick-access-desc">Manage activities and events</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/actions.php" class="quick-access-card">
                    <i class="fa-solid fa-bullseye"></i>
                    <div>
                        <div class="quick-access-title">Action Points Tracker</div>
                        <div class="quick-access-desc">View Action Points</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/minutes.php" class="quick-access-card">
                    <i class="fa-solid fa-file-signature"></i>
                    <div>
                        <div class="quick-access-title">Meeting Minutes</div>
                        <div class="quick-access-desc">View local and foreign financiers</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/visitors.php" class="quick-access-card">
                    <i class="fa-solid fa-id-card-clip"></i>
                    <div>
                        <div class="quick-access-title">Visitors</div>
                        <div class="quick-access-desc">View Visitor Records</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/reports.php" class="quick-access-card">
                    <i class="fa-solid fa-folder-open"></i>
                    <div>
                        <div class="quick-access-title">Reports</div>
                        <div class="quick-access-desc">View System Data</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/mail.php" class="quick-access-card">
                    <i class="fa-solid fa-envelope-open-text"></i>
                    <div>
                        <div class="quick-access-title">Mail Management</div>
                        <div class="quick-access-desc">View Mail Records</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/diary.php" class="quick-access-card">
                    <i class="fa-solid fa-book-journal-whills"></i>
                    <div>
                        <div class="quick-access-title">Diary</div>
                        <div class="quick-access-desc">View Diary Entries</div>
                    </div>
                </a>
            </div>

            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= BASE_URL ?>modules/pc.php" class="quick-access-card">
                    <i class="fa-solid fa-award"></i>
                    <div>
                        <div class="quick-access-title">Performance Contract</div>
                        <div class="quick-access-desc">View KPI Targets &amp; Scores</div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- Executive Metrics Row -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-3 bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-bold text-uppercase">Total Project Portfolio</div>
                        <h3 class="fw-bold mb-0 text-primary"><?= $stats['projects'] ?></h3>
                        <div class="small text-success mt-1"><i class="fa-solid fa-circle-check"></i> <?= $stats['active_projects'] ?> In Progress</div>
                    </div>
                    <div class="p-3 rounded-circle bg-light text-primary fs-3">
                        <i class="fa-solid fa-diagram-project"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-3 bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-bold text-uppercase">Allocated Budget</div>
                        <h4 class="fw-bold mb-0 text-dark"><?= format_kes($stats['total_budget']) ?></h4>
                        <div class="small text-muted mt-1">Exchequer &amp; Grants</div>
                    </div>
                    <div class="p-3 rounded-circle bg-light text-success fs-3">
                        <i class="fa-solid fa-money-bill-wave"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-3 bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-bold text-uppercase">Open Action Items</div>
                        <h3 class="fw-bold mb-0 text-danger"><?= $stats['open_actions'] ?></h3>
                        <div class="small text-muted mt-1">Field visits &amp; executive</div>
                    </div>
                    <div class="p-3 rounded-circle bg-light text-danger fs-3">
                        <i class="fa-solid fa-list-check"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-3 bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-bold text-uppercase">Reports Pending Approval</div>
                        <h3 class="fw-bold mb-0 text-warning"><?= $stats['pending_reports'] ?></h3>
                        <div class="small text-muted mt-1">Requires executive review</div>
                    </div>
                    <div class="p-3 rounded-circle bg-light text-warning fs-3">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100 bg-white">
                <div class="card-header bg-white py-3 fw-bold border-bottom">
                    <i class="fa-solid fa-chart-pie text-primary me-2"></i> Project Status Distribution
                </div>
                <div class="card-body p-3 d-flex align-items-center justify-content-center" style="min-height: 260px;">
                    <canvas id="chartProjectStatus" style="max-height: 240px;"></canvas>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100 bg-white">
                <div class="card-header bg-white py-3 fw-bold border-bottom">
                    <i class="fa-solid fa-shield-halved text-danger me-2"></i> Priority Flagship Risk Levels
                </div>
                <div class="card-body p-3 d-flex align-items-center justify-content-center" style="min-height: 260px;">
                    <canvas id="chartRiskLevels" style="max-height: 240px;"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Points & Audit Log Row -->
    <div class="row g-3">
        <div class="col-12 col-lg-7">
            <div class="card border-0 shadow-sm bg-white">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                    <div class="fw-bold"><i class="fa-solid fa-thumbtack text-primary me-2"></i> Recent Action Points</div>
                    <a href="<?= BASE_URL ?>modules/actions.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" style="font-size: 0.82rem;">
                            <thead class="table-light">
                                <tr>
                                    <th>Ref No</th>
                                    <th>Issue</th>
                                    <th>Responsible</th>
                                    <th>Deadline</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentActions as $ap): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= e($ap['ref_no']) ?></td>
                                        <td class="text-truncate" style="max-width: 180px;"><?= e($ap['issue']) ?></td>
                                        <td><?= e($ap['person_responsible']) ?></td>
                                        <td><?= e($ap['timeline']) ?></td>
                                        <td><?= badge_cell($ap['status']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-5">
            <div class="card border-0 shadow-sm bg-white">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                    <div class="fw-bold"><i class="fa-solid fa-fingerprint text-secondary me-2"></i> Live Audit Trail</div>
                    <span class="badge bg-light text-dark">Recent System Events</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive" style="max-height: 320px;">
                        <table class="table table-sm table-striped align-middle mb-0" style="font-size: 0.76rem;">
                            <thead>
                                <tr>
                                    <th>Action</th>
                                    <th>User</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentAudits as $log): ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-secondary"><?= e($log['action']) ?></span>
                                            <div class="text-truncate text-muted" style="max-width: 180px;"><?= e($log['description']) ?></div>
                                        </td>
                                        <td class="fw-semibold"><?= e($log['username']) ?></td>
                                        <td class="text-muted"><?= date('H:i d/m', strtotime($log['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
window.addEventListener('load', function() {
    // Project Status Doughnut Chart
    new Chart(document.getElementById('chartProjectStatus'), {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($statusLabels) ?>,
            datasets: [{
                data: <?= json_encode($statusCounts) ?>,
                backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6c757d', '#0dcaf0']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });

    // Risk Levels Bar Chart
    new Chart(document.getElementById('chartRiskLevels'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($riskLabels) ?>,
            datasets: [{
                label: 'Flagships Count',
                data: <?= json_encode($riskCounts) ?>,
                backgroundColor: ['#198754', '#ffc107', '#fd7e14', '#dc3545']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });
});
</script>
<?php
};

render_page('Executive Dashboard', $renderContent, ['active' => 'dashboard']);
